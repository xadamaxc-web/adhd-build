create table if not exists reminders (
  id serial primary key,
  user_id text not null,
  thought_id integer not null references thoughts(id) on delete cascade,
  fire_at timestamptz not null,
  fired boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists reminders_fire_idx on reminders (fired, fire_at);
create index if not exists reminders_user_idx on reminders (user_id, fire_at);
