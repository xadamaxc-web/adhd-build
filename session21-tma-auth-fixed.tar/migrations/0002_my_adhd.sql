-- My ADHD core schema (users, capture, accounts, AI artifacts, admin, flags)

create table if not exists users (
  id serial primary key,
  user_id text not null unique,
  telegram_id text unique,
  username text,
  first_name text,
  last_name text,
  language_code text,
  is_premium boolean not null default false,
  is_banned boolean not null default false,
  quiet_hours_start text,
  quiet_hours_end text,
  last_active_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists users_telegram_id_idx on users (telegram_id);
create index if not exists users_last_active_idx on users (last_active_at);

create table if not exists thoughts (
  id serial primary key,
  user_id text not null,
  content text not null default '',
  content_type text not null default 'text',
  voice_path text,
  status text not null default 'raw',
  next_step text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists thoughts_user_status_idx on thoughts (user_id, status, created_at desc);

create table if not exists accounts (
  id serial primary key,
  user_id text not null,
  provider text not null,
  label text not null,
  unlocks_at timestamptz not null,
  cooldown_hours integer not null default 5,
  notified integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists accounts_user_unlocks_idx on accounts (user_id, unlocks_at);
create index if not exists accounts_notify_idx on accounts (unlocks_at, notified);

create table if not exists idea_plays (
  id serial primary key,
  thought_id integer not null references thoughts(id) on delete cascade,
  user_id text not null,
  questions_json text not null default '[]',
  answers_json text,
  generated_prompt text,
  created_at timestamptz not null default now()
);
create index if not exists idea_plays_thought_idx on idea_plays (thought_id, created_at desc);

create table if not exists idea_plans (
  id serial primary key,
  thought_id integer not null references thoughts(id) on delete cascade,
  user_id text not null,
  general_prompt text,
  sessions_json text not null default '[]',
  created_at timestamptz not null default now()
);
create index if not exists idea_plans_thought_idx on idea_plans (thought_id, created_at desc);

create table if not exists progress_logs (
  id serial primary key,
  thought_id integer not null references thoughts(id) on delete cascade,
  user_id text not null,
  content text not null,
  context text,
  created_at timestamptz not null default now()
);
create index if not exists progress_logs_thought_idx on progress_logs (thought_id, created_at desc);

create table if not exists admins (
  id serial primary key,
  telegram_id text not null unique,
  user_id text,
  role text not null default 'support',
  created_at timestamptz not null default now()
);

create table if not exists logs (
  id serial primary key,
  type text not null,
  message text not null,
  meta_json text,
  created_at timestamptz not null default now()
);
create index if not exists logs_type_created_idx on logs (type, created_at desc);

create table if not exists feature_flags (
  key text primary key,
  enabled boolean not null default true,
  updated_at timestamptz not null default now()
);

create table if not exists triggers (
  key text primary key,
  enabled boolean not null default true,
  frequency_hours integer not null default 24,
  last_run_at timestamptz,
  last_error text,
  created_at timestamptz not null default now()
);

create table if not exists settings (
  key text primary key,
  value text not null default '',
  updated_at timestamptz not null default now()
);

insert into feature_flags (key, enabled) values
  ('capture', true),
  ('gold_trash', true),
  ('weekly_review', true),
  ('accounts', true),
  ('unlock_ping', true),
  ('play', true),
  ('free', true),
  ('progress', true),
  ('voice', true),
  ('workspace', true),
  ('admin', true),
  ('adsgram', false),
  ('donate', true),
  ('stars', false)
on conflict (key) do nothing;

insert into triggers (key, enabled, frequency_hours) values
  ('unlock_ping', true, 0),
  ('weekly_review', true, 168),
  ('idle_nudge', true, 168),
  ('progress_check', true, 336),
  ('admin_broadcast', true, 0),
  ('system_alert', true, 0),
  ('api_health', true, 0),
  ('clean_logs', true, 24)
on conflict (key) do nothing;

insert into settings (key, value) values
  ('donate_link', ''),
  ('tma_url', ''),
  ('owner_telegram_id', '')
on conflict (key) do nothing;
