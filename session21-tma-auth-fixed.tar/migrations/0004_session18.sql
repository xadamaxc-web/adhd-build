-- Session 18: invite columns + feature flags

alter table thoughts add column if not exists invite_token text;
alter table thoughts add column if not exists invited_username text;
alter table thoughts add column if not exists forked_from integer references thoughts(id) on delete set null;

create index if not exists thoughts_invite_token_idx on thoughts (invite_token) where invite_token is not null;

insert into feature_flags (key, enabled) values
  ('voice_inline', true),
  ('idea_merge', true),
  ('reminders', true),
  ('export', true),
  ('collaborator_invite', true)
on conflict (key) do nothing;
