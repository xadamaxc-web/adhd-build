#!/usr/bin/env bash
# Backup embedded PGLite data dir if present; otherwise note Neon (external).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/backups"
mkdir -p "$DEST"
DATE="$(date +%Y-%m-%d)"
# PGLite stores under node process data; also copy any local .db
SRC=""
if [ -f "$ROOT/data/myadhd.db" ]; then
  SRC="$ROOT/data/myadhd.db"
elif [ -f "$ROOT/myadhd.db" ]; then
  SRC="$ROOT/myadhd.db"
fi
OUT="$DEST/myadhd-$DATE.db"
if [ -n "$SRC" ]; then
  cp "$SRC" "$OUT"
  echo "Backed up $SRC -> $OUT"
else
  # Placeholder marker when using Neon / in-memory PGLite
  echo "No local SQLite file; using platform DB. Timestamp: $DATE" > "$OUT.note"
  echo "Wrote $OUT.note (no local db file)"
fi
# Keep last 7 dated backups
ls -1t "$DEST"/myadhd-*.db 2>/dev/null | tail -n +8 | xargs -r rm -f
ls -1t "$DEST"/myadhd-*.db.note 2>/dev/null | tail -n +8 | xargs -r rm -f
