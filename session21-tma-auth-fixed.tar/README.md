# My ADHD

Capture now. Sort later.

Personal ADHD idea inbox with Telegram bot, swipe review, unlock timers, Play/Free AI sessions, progress logs, and owner admin tools.

## Stack

- TanStack Start + React + Vite
- Postgres (Neon in production, PGLite in preview)
- Telegram Bot + Mini App
- Free AI chain: Groq → Cloudflare → Gemini → OpenRouter (optional xAI last)

## Environment

Copy `.env.example` and fill:

| Variable | Required | Purpose |
|----------|----------|---------|
| `BOT_TOKEN` | yes (bot) | Telegram bot token |
| `BOT_USERNAME` | for invites | e.g. `MyADHDBot` |
| `OWNER_TELEGRAM_ID` | recommended | Owner alerts + admin bootstrap |
| `TMA_URL` | Mini App | HTTPS URL of the deployed app |
| `SECRET` | recommended | App secret |
| `PORT` | no | Default `8080` |
| `DATABASE_URL` | production | Neon Postgres URL |
| `GROQ_API_KEY` | recommended | Chat + Whisper STT |
| `CF_ACCOUNT_ID` / `CF_API_TOKEN` | optional | Cloudflare Workers AI |
| `GEMINI_API_KEY` | optional | Gemini chat + audio fallback |
| `OPENROUTER_API_KEY` | optional | Free model rotation |
| `XAI_API_KEY` | optional | Last-resort chat |

## Deploy (Railway / Fly.io)

1. Create a Postgres database (or use Neon) and set `DATABASE_URL`.
2. Set env vars from the table above.
3. Build: `npm install && npm run build`
4. Start: `npm run start` or the platform’s Node start command on port `PORT`.
5. Migrations apply on boot / via `npm run db:migrate`.

### Webhook

```bash
curl "https://api.telegram.org/bot$BOT_TOKEN/setWebhook" \
  -d "url=https://YOUR_DOMAIN/webhook/telegram"
```

### BotFather

1. Create bot → copy token → `BOT_TOKEN`.
2. `/setdomain` for the Mini App host.
3. Menu button is set automatically on boot when `TMA_URL` is present (`Open My ADHD` → `?startapp=record`).

## Backup

```bash
# daily 03:00
0 3 * * * bash /path/to/app/scripts/backup.sh
```

Keeps the last 7 `backups/myadhd-YYYY-MM-DD.db` files.

## Home screen shortcut

Open the Mini App in Telegram → browser menu → **Add to Home Screen** (iOS/Android). Use the same HTTPS `TMA_URL`.

## Key commands

| Command | Action |
|---------|--------|
| (text/voice) | Capture to raw inbox |
| `/inbox` `/gold` `/review` | Counts / review entry |
| `/used <provider> <label> <time>` | Free-tier timer |
| `/remind <id> <time>` | Custom reminder |
| `/export` | Markdown export of gold ideas |

## Feature flags

Admin → Flags: `export`, `reminders`, `idea_merge`, `collaborator_invite`, `voice_inline`, …
