import { useCallback, useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { RoomNav } from "@/components/room-nav";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  listMyThoughts,
  setThoughtNextStepFn,
  setThoughtStatus,
} from "@/lib/adhd/thoughts-client";
import type { ThoughtRow } from "@/lib/adhd/types";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/review")({ component: ReviewPage });

type Phase =
  | { kind: "loading" }
  | { kind: "card"; thought: ThoughtRow }
  | { kind: "next_step"; thought: ThoughtRow }
  | { kind: "done"; kept: number; trashed: number }
  | { kind: "empty" };

function ReviewPage() {
  const { user, isPending } = useCurrentUserState();
  const [queue, setQueue] = useState<ThoughtRow[]>([]);
  const [phase, setPhase] = useState<Phase>({ kind: "loading" });
  const [kept, setKept] = useState(0);
  const [trashed, setTrashed] = useState(0);
  const [nextStep, setNextStep] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const showNext = useCallback((list: ThoughtRow[], k: number, t: number) => {
    if (list.length === 0) {
      setPhase({ kind: "done", kept: k, trashed: t });
      return;
    }
    setPhase({ kind: "card", thought: list[0]! });
  }, []);

  const load = useCallback(async () => {
    setPhase({ kind: "loading" });
    setError(null);
    try {
      const rows = await listMyThoughts({ data: { status: "gold" } });
      setQueue(rows);
      setKept(0);
      setTrashed(0);
      if (rows.length === 0) setPhase({ kind: "empty" });
      else setPhase({ kind: "card", thought: rows[0]! });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load gold");
      setPhase({ kind: "empty" });
    }
  }, []);

  useEffect(() => {
    if (user) void load();
  }, [user, load]);

  async function keepAsGold() {
    if (phase.kind !== "card") return;
    setNextStep(phase.thought.next_step ?? "");
    setPhase({ kind: "next_step", thought: phase.thought });
  }

  async function saveNextStep() {
    if (phase.kind !== "next_step" || busy) return;
    setBusy(true);
    try {
      await setThoughtNextStepFn({
        data: { id: phase.thought.id, nextStep: nextStep.trim() || null },
      });
      const rest = queue.slice(1);
      const k = kept + 1;
      setKept(k);
      setQueue(rest);
      setNextStep("");
      showNext(rest, k, trashed);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save");
    } finally {
      setBusy(false);
    }
  }

  async function moveToTrash() {
    if (phase.kind !== "card" || busy) return;
    setBusy(true);
    try {
      await setThoughtStatus({ data: { id: phase.thought.id, status: "trash" } });
      const rest = queue.slice(1);
      const t = trashed + 1;
      setTrashed(t);
      setQueue(rest);
      showNext(rest, kept, t);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not trash");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6 sm:py-12">
        <div className="flex items-center gap-3">
          <Button asChild variant="secondary" size="sm">
            <Link to="/">
              <ArrowLeft className="size-3.5" />
              Inbox
            </Link>
          </Button>
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
              Weekly review
            </p>
            <h1 className="font-display text-2xl font-medium tracking-tight sm:text-3xl">
              Gold pile
            </h1>
          </div>
        </div>
        <RoomNav />
        {isPending || phase.kind === "loading" ? (
          <Skeleton className="mx-auto h-64 w-full max-w-md rounded-xl" />
        ) : !user ? (
          <RedirectToSignIn />
        ) : (
          <div className="mx-auto max-w-md space-y-4">
            {error && <p className="text-sm text-danger">{error}</p>}
            {phase.kind === "empty" && (
              <Card className="border-dashed">
                <CardContent className="py-10 text-center text-sm text-muted-foreground">
                  No gold ideas to review. Swipe some raw thoughts first.
                </CardContent>
              </Card>
            )}
            {phase.kind === "card" && (
              <>
                <p className="text-xs text-muted-foreground">
                  {queue.length} remaining · kept {kept} · trashed {trashed}
                </p>
                <Card>
                  <CardHeader>
                    <Badge variant="ok" className="w-fit">gold</Badge>
                    <CardTitle className="text-base font-normal leading-relaxed whitespace-pre-wrap">
                      {phase.thought.content}
                    </CardTitle>
                    {phase.thought.next_step && (
                      <CardDescription>Next: {phase.thought.next_step}</CardDescription>
                    )}
                  </CardHeader>
                  <CardContent className="flex flex-wrap gap-2">
                    <Button type="button" disabled={busy} onClick={() => void keepAsGold()}>
                      Keep as Gold
                    </Button>
                    <Button type="button" variant="secondary" disabled={busy} onClick={() => void moveToTrash()}>
                      Move to Trash
                    </Button>
                  </CardContent>
                </Card>
              </>
            )}
            {phase.kind === "next_step" && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Next step</CardTitle>
                  <CardDescription className="whitespace-pre-wrap">
                    {phase.thought.content}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <textarea
                    value={nextStep}
                    onChange={(e) => setNextStep(e.target.value)}
                    rows={3}
                    placeholder="One concrete next action…"
                    className="w-full resize-none rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                  <Button type="button" disabled={busy} onClick={() => void saveNextStep()}>
                    {busy ? "Saving…" : "Save & next"}
                  </Button>
                </CardContent>
              </Card>
            )}
            {phase.kind === "done" && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Review complete</CardTitle>
                  <CardDescription>
                    {phase.kept} kept, {phase.trashed} trashed.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  <Button type="button" variant="secondary" onClick={() => void load()}>
                    Review again
                  </Button>
                  <Button asChild>
                    <Link to="/">Back to inbox</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </main>
    </AppShell>
  );
}
