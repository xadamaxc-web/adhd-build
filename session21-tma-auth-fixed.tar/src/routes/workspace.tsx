import { useCallback, useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Brain } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { RoomNav } from "@/components/room-nav";
import { BrainMap } from "@/components/brain-map";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { listMyThoughts } from "@/lib/adhd/thoughts-client";
import type { ThoughtRow } from "@/lib/adhd/types";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/workspace")({ component: WorkspacePage });

function WorkspacePage() {
  const { user, isPending } = useCurrentUserState();
  const [thoughts, setThoughts] = useState<ThoughtRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      // map shows raw + gold (not trash)
      const [raw, gold] = await Promise.all([
        listMyThoughts({ data: { status: "raw" } }),
        listMyThoughts({ data: { status: "gold" } }),
      ]);
      setThoughts([...gold, ...raw]);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load thoughts");
    }
  }, []);

  useEffect(() => {
    if (user) load();
  }, [user, load]);

  const goldCount = thoughts?.filter((t) => t.status === "gold").length ?? 0;
  const rawCount = thoughts?.filter((t) => t.status === "raw").length ?? 0;

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6 sm:py-12">
        <div className="mb-8 flex flex-wrap items-center gap-3">
          <Button asChild variant="secondary" size="sm">
            <Link to="/">
              <ArrowLeft className="size-3.5" />
              Inbox
            </Link>
          </Button>
          <div className="flex-1">
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
              Session 7 · Workspace
            </p>
            <h1 className="font-display text-2xl font-medium tracking-tight sm:text-3xl">
              Brain map
            </h1>
          </div>
          {thoughts && (
            <p className="text-xs text-muted-foreground">
              <span className="text-ok">{goldCount} gold</span>
              <span className="mx-1.5">·</span>
              {rawCount} raw
            </p>
          )}
        
        </div>

        <RoomNav />

        <p className="mb-6 max-w-xl text-sm text-muted-foreground">
          High-concentration ideas (gold) sit closer to the center. Raw thoughts
          orbit farther out. Capture more, swipe gold, and watch the map tighten.
        </p>

        {isPending ? (
          <Skeleton className="mx-auto aspect-square w-full max-w-lg rounded-xl" />
        ) : !user ? (
          <RedirectToSignIn />
        ) : error ? (
          <div className="rounded-xl border border-border bg-card p-6 text-center">
            <p className="text-sm text-muted-foreground">{error}</p>
            <Button type="button" className="mt-4" onClick={load}>
              Retry
            </Button>
          </div>
        ) : thoughts === null ? (
          <Skeleton className="mx-auto aspect-square w-full max-w-lg rounded-xl" />
        ) : (
          <BrainMap thoughts={thoughts} />
        )}

        <div className="mt-8 flex flex-wrap gap-2">
          <Button asChild variant="secondary" size="sm">
            <Link to="/review">Swipe review</Link>
          </Button>
          <Button asChild variant="secondary" size="sm">
            <Link to="/accounts">Accounts</Link>
          </Button>
        </div>
      </main>
    </AppShell>
  );
}
