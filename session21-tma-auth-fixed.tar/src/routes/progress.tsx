import { useCallback, useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Clock } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { RoomNav } from "@/components/room-nav";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  addProgress,
  listMyProgress,
} from "@/lib/adhd/progress-client";
import type { ProgressLogRow } from "@/lib/adhd/progress";
import { listMyThoughts } from "@/lib/adhd/thoughts-client";
import { previewText } from "@/lib/adhd/format";
import type { ThoughtRow } from "@/lib/adhd/types";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/progress")({ component: ProgressPage });

function ProgressPage() {
  const { user, isPending } = useCurrentUserState();
  const [gold, setGold] = useState<ThoughtRow[] | null>(null);
  const [logs, setLogs] = useState<ProgressLogRow[]>([]);
  const [selected, setSelected] = useState<ThoughtRow | null>(null);
  const [note, setNote] = useState("");
  const [nextStep, setNextStep] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [g, p] = await Promise.all([
        listMyThoughts({ data: { status: "gold" } }),
        listMyProgress(),
      ]);
      setGold(g);
      setLogs(p);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load");
    }
  }, []);

  useEffect(() => {
    if (user) load();
  }, [user, load]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!selected || !note.trim() || busy) return;
    setBusy(true);
    try {
      await addProgress({
        data: {
          thoughtId: selected.id,
          content: note.trim(),
          nextStep: nextStep.trim() || undefined,
        },
      });
      setNote("");
      setNextStep("");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save");
    } finally {
      setBusy(false);
    }
  }

  const thoughtMap = new Map((gold ?? []).map((t) => [t.id, t]));

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6 sm:py-12">
        <div className="flex items-center gap-3">
          <Button asChild variant="secondary" size="sm">
            <Link to="/">
              <ArrowLeft className="size-3.5" />
              Inbox
            </Link>
          </Button>
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
              Session 9 · Progress
            </p>
            <h1 className="font-display text-2xl font-medium tracking-tight sm:text-3xl">
              Log progress
            </h1>
          </div>
        </div>

        <RoomNav />

        {isPending ? (
          <Skeleton className="h-48 rounded-xl" />
        ) : !user ? (
          <RedirectToSignIn />
        ) : (
          <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
            <section className="space-y-3">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="size-4" strokeWidth={1.75} />
                <h2 className="font-display text-lg font-medium tracking-tight text-foreground">
                  Add a note
                </h2>
              </div>

              {error && (
                <p className="text-sm text-danger">{error}</p>
              )}

              {gold === null ? (
                <Skeleton className="h-32 rounded-xl" />
              ) : gold.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="py-8 text-center text-sm text-muted-foreground">
                    No gold ideas yet. Swipe some first.
                  </CardContent>
                </Card>
              ) : (
                <form onSubmit={submit} className="space-y-3">
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-wider text-muted-foreground">
                      Idea
                    </label>
                    <select
                      value={selected?.id ?? ""}
                      onChange={(e) => {
                        const id = Number(e.target.value);
                        setSelected(gold.find((t) => t.id === id) ?? null);
                      }}
                      className="w-full rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                      required
                    >
                      <option value="">Choose a gold idea…</option>
                      {gold.map((t) => (
                        <option key={t.id} value={t.id}>
                          {previewText(t.content, 60)}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-wider text-muted-foreground">
                      What happened?
                    </label>
                    <textarea
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      rows={3}
                      required
                      placeholder="Ship one small step, a blocker, a win…"
                      className="w-full resize-none rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-wider text-muted-foreground">
                      Next step (optional)
                    </label>
                    <input
                      value={nextStep}
                      onChange={(e) => setNextStep(e.target.value)}
                      placeholder="One concrete next action"
                      className="w-full rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                    />
                  </div>
                  <Button type="submit" disabled={busy || !selected || !note.trim()}>
                    {busy ? "Saving…" : "Log progress"}
                  </Button>
                </form>
              )}
            </section>

            <section className="space-y-3">
              <h2 className="font-display text-lg font-medium tracking-tight">
                Recent
              </h2>
              {logs.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="py-8 text-center text-sm text-muted-foreground">
                    No progress notes yet.
                  </CardContent>
                </Card>
              ) : (
                <ul className="space-y-2">
                  {logs.map((l) => {
                    const t = thoughtMap.get(l.thought_id);
                    return (
                      <li key={l.id}>
                        <Card>
                          <CardHeader className="p-4 pb-2">
                            <div className="flex flex-wrap items-center gap-2">
                              <Badge variant="ok">gold</Badge>
                              <span className="font-mono text-xs text-muted-foreground">
                                {new Date(l.created_at).toLocaleString()}
                              </span>
                            </div>
                            {t && (
                              <CardDescription className="mt-1">
                                {previewText(t.content, 80)}
                              </CardDescription>
                            )}
                          </CardHeader>
                          <CardContent className="p-4 pt-0">
                            <p className="text-sm leading-relaxed whitespace-pre-wrap">
                              {l.content}
                            </p>
                          </CardContent>
                        </Card>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>
          </div>
        )}
      </main>
    </AppShell>
  );
}
