import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { RoomNav } from "@/components/room-nav";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { getMe } from "@/lib/adhd/me";
import { saveQuietHours } from "@/lib/adhd/progress-client";
import type { UserRow } from "@/lib/adhd/types";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const { user, isPending } = useCurrentUserState();
  const [me, setMe] = useState<UserRow | null>(null);
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    getMe()
      .then((row) => {
        setMe(row);
        setStart(row.quiet_hours_start ?? "");
        setEnd(row.quiet_hours_end ?? "");
      })
      .catch(() => setMsg("Could not load profile"));
  }, [user]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setMsg(null);
    try {
      const row = await saveQuietHours({
        data: {
          start: start.trim() || null,
          end: end.trim() || null,
        },
      });
      setMe(row);
      setMsg("Saved.");
    } catch (err) {
      setMsg(err instanceof Error ? err.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6 sm:py-12">
        <div className="flex items-center gap-3">
          <Button asChild variant="secondary" size="sm">
            <Link to="/">
              <ArrowLeft className="size-3.5" />
              Inbox
            </Link>
          </Button>
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
              Session 9 · Settings
            </p>
            <h1 className="font-display text-2xl font-medium tracking-tight sm:text-3xl">
              Preferences
            </h1>
          </div>
        </div>

        <RoomNav />

        {isPending ? (
          <Skeleton className="h-40 rounded-xl" />
        ) : !user ? (
          <RedirectToSignIn />
        ) : !me ? (
          <Skeleton className="h-40 rounded-xl" />
        ) : (
          <Card className="max-w-lg">
            <CardHeader>
              <CardTitle className="text-base">Quiet hours</CardTitle>
              <CardDescription>
                Optional window when the bot stays quiet (local time, HH:MM).
                Leave blank to turn off.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={save} className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-xs uppercase tracking-wider text-muted-foreground">
                      Start
                    </label>
                    <input
                      type="time"
                      value={start}
                      onChange={(e) => setStart(e.target.value)}
                      className="w-full rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs uppercase tracking-wider text-muted-foreground">
                      End
                    </label>
                    <input
                      type="time"
                      value={end}
                      onChange={(e) => setEnd(e.target.value)}
                      className="w-full rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                    />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Button type="submit" disabled={busy}>
                    {busy ? "Saving…" : "Save"}
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    disabled={busy}
                    onClick={() => {
                      setStart("");
                      setEnd("");
                    }}
                  >
                    Clear
                  </Button>
                  {msg && (
                    <span className="text-sm text-muted-foreground">{msg}</span>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>
        )}
      </main>
    </AppShell>
  );
}
