import { useCallback, useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Brain,
  CircleAlert,
  KeyRound,
  Lightbulb,
  Lock,
  Sparkles,
  Star,
  Trash2,
  Inbox,
} from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { getHealth } from "@/lib/adhd/health";
import { getMe } from "@/lib/adhd/me";
import {
  captureThought,
  listMyThoughts,
  setThoughtStatus,
  mergeThoughts,
} from "@/lib/adhd/thoughts-client";
import type { HealthPayload, ThoughtRow, UserRow } from "@/lib/adhd/types";
import { GROK_PROVIDERS, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { RoomNav } from "@/components/room-nav";
import { VoiceCapture } from "@/components/voice-capture";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const { user, isPending } = useCurrentUserState();

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
        {isPending ? <HomeSkeleton /> : user ? <SignedInHome /> : <Landing />}
      </main>
    </AppShell>
  );
}

function Landing() {
  return (
    <div className="grid gap-12 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
      <div className="max-w-xl">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
          My ADHD · Complete
        </p>
        <h1 className="mt-4 font-display text-4xl font-medium leading-[1.12] tracking-tight sm:text-5xl">
          Capture now.
          <br />
          Sort later.
        </h1>
        <p className="mt-5 max-w-md text-base leading-relaxed text-muted-foreground">
          An inbox for ideas that arrive faster than you can organize them.
          Dump a thought. Leave it raw. Come back when your mind is quiet.
        </p>
        <div className="mt-8 flex w-full max-w-sm flex-col gap-2">
          {GROK_PROVIDERS.map((p) => (
            <Button
              key={p.providerId}
              type="button"
              variant={p.providerId === "google" ? "default" : "secondary"}
              onClick={() => signIn(p.providerId, { callbackURL: "/" })}
            >
              Continue with {p.label}
            </Button>
          ))}
        </div>
      </div>
      <ComingNext />
    </div>
  );
}

function SignedInHome() {
  const [me, setMe] = useState<UserRow | null>(null);
  const [health, setHealth] = useState<HealthPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [thoughts, setThoughts] = useState<ThoughtRow[]>([]);
  const [draft, setDraft] = useState("");
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState<"raw" | "gold" | "all">("raw");
  const [mergePick, setMergePick] = useState<number | null>(null);
  const [mergeBusy, setMergeBusy] = useState(false);

  const loadThoughts = useCallback(async () => {
    try {
      const rows = await listMyThoughts({
        data: filter === "all" ? undefined : { status: filter },
      });
      setThoughts(rows);
    } catch {
      // keep existing list on error
    }
  }, [filter]);

  useEffect(() => {
    let alive = true;
    Promise.all([getMe(), getHealth()])
      .then(([row, payload]) => {
        if (!alive) return;
        setMe(row);
        setHealth(payload);
      })
      .catch((err) => {
        if (!alive) return;
        setError(err instanceof Error ? err.message : "Could not load your profile");
      });
    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (me) loadThoughts();
  }, [me, loadThoughts]);

  async function handleCapture(e: React.FormEvent) {
    e.preventDefault();
    const content = draft.trim();
    if (!content || saving) return;
    setSaving(true);
    try {
      await captureThought({ data: { content } });
      setDraft("");
      await loadThoughts();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save thought");
    } finally {
      setSaving(false);
    }
  }

  async function doMerge(idB: number) {
    if (!mergePick || mergePick === idB || mergeBusy) return;
    setMergeBusy(true);
    try {
      const res = await mergeThoughts({ data: { idA: mergePick, idB } });
      if (!res.ok) {
        setError(res.error);
      } else {
        setMergePick(null);
        await loadThoughts();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Merge failed");
    } finally {
      setMergeBusy(false);
    }
  }

  async function markStatus(id: number, status: "gold" | "trash" | "raw") {
    try {
      await setThoughtStatus({ data: { id, status } });
      await loadThoughts();
    } catch {
      // ignore
    }
  }

  if (error && !me) {
    return (
      <Card className="max-w-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CircleAlert className="size-5 text-danger" />
            Profile unavailable
          </CardTitle>
          <CardDescription>{error}</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (!me || !health) return <HomeSkeleton />;

  const display = me.first_name || me.username || "there";

  return (
    <div className="space-y-10">
      <RoomNav />
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
          My ADHD · Complete
        </p>
        <h1 className="mt-3 font-display text-4xl font-medium tracking-tight">
          Hello, {display}.
        </h1>
        <p className="mt-3 max-w-lg text-muted-foreground">
          Dump a thought below. Leave it raw. Mark gold or trash when you are
          All four rooms are live.
        </p>
      </div>

      {/* Capture + Inbox — Ideas room */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Inbox className="size-4" strokeWidth={1.75} />
            <h2 className="font-display text-xl font-medium tracking-tight text-foreground">
              Ideas
            </h2>
          </div>
          <Button asChild size="sm" variant="secondary">
            <Link to="/review">Start swipe review</Link>
          </Button>
          <Button asChild size="sm" variant="secondary">
            <Link to="/accounts">Accounts</Link>
          </Button>
          <Button asChild size="sm" variant="secondary">
            <Link to="/workspace">Workspace</Link>
          </Button>
          <Button asChild size="sm" variant="secondary">
            <Link to="/play">Play</Link>
          </Button>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Capture</CardTitle>
            <CardDescription>
              Type or record. No tags, no folders — just dump it.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCapture} className="space-y-3">
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="A thought, a half-idea, a link, a rant…"
                rows={3}
                className="w-full resize-none rounded-lg border border-border bg-card-elevated px-3 py-2.5 text-sm leading-relaxed text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
              <div className="flex flex-wrap items-center justify-between gap-3">
                <p className="text-xs text-muted-foreground">
                  {draft.trim().length > 0
                    ? `${draft.trim().length} chars`
                    : "Raw inbox · sort later"}
                </p>
                <div className="flex items-center gap-2">
                  <VoiceCapture
                    disabled={saving}
                    onCaptured={() => {
                      void loadThoughts();
                    }}
                  />
                  <Button type="submit" disabled={!draft.trim() || saving} size="sm">
                    {saving ? "Saving…" : "Capture"}
                  </Button>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>

        <div className="flex flex-wrap items-center gap-2">
          {(
            [
              ["raw", "Raw"],
              ["gold", "Gold"],
              ["all", "All"],
            ] as const
          ).map(([key, label]) => (
            <Button
              key={key}
              type="button"
              size="sm"
              variant={filter === key ? "default" : "secondary"}
              onClick={() => setFilter(key)}
            >
              {label}
            </Button>
          ))}
        </div>

        {thoughts.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-10 text-center text-sm text-muted-foreground">
              {filter === "raw"
                ? "Inbox is empty. Capture something above."
                : filter === "gold"
                  ? "No gold yet. Mark a raw thought with the star."
                  : "Nothing here yet."}
            </CardContent>
          </Card>
        ) : (
          <ul className="space-y-2">
            {thoughts.map((t) => (
              <li key={t.id}>
                <Card className="overflow-hidden">
                  <CardContent className="flex items-start gap-3 p-4">
                    <div className="min-w-0 flex-1">
                      <p className="whitespace-pre-wrap text-sm leading-relaxed">
                        {t.content}
                      </p>
                      <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        <Badge variant={t.status === "gold" ? "ok" : "wait"}>
                          {t.status}
                        </Badge>
                        <span className="font-mono">
                          {new Date(t.created_at).toLocaleString()}
                        </span>
                        {t.content_type === "voice" && (
                          <span className="italic">voice</span>
                        )}
                      </div>
                    </div>
                    <div className="flex shrink-0 gap-1">
                      {t.status === "raw" && (
                        <Button
                          type="button"
                          size="sm"
                          variant={mergePick === t.id ? "default" : "secondary"}
                          title="Merge with another"
                          disabled={mergeBusy}
                          onClick={() => {
                            if (mergePick == null) setMergePick(t.id);
                            else if (mergePick === t.id) setMergePick(null);
                            else void doMerge(t.id);
                          }}
                        >
                          {mergePick == null
                            ? "Merge"
                            : mergePick === t.id
                              ? "Cancel"
                              : "With this"}
                        </Button>
                      )}
                      {t.status !== "gold" && (
                        <Button
                          type="button"
                          size="sm"
                          variant="secondary"
                          title="Mark gold"
                          onClick={() => markStatus(t.id, "gold")}
                        >
                          <Star className="size-3.5" />
                        </Button>
                      )}
                      {t.status !== "trash" && (
                        <Button
                          type="button"
                          size="sm"
                          variant="secondary"
                          title="Trash"
                          onClick={() => markStatus(t.id, "trash")}
                        >
                          <Trash2 className="size-3.5" />
                        </Button>
                      )}
                      {t.status !== "raw" && (
                        <Button
                          type="button"
                          size="sm"
                          variant="secondary"
                          title="Back to raw"
                          onClick={() => markStatus(t.id, "raw")}
                        >
                          Raw
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </li>
            ))}
          </ul>
        )}
      </section>

      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Your record</CardTitle>
            <CardDescription>Protected profile row.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3 font-mono text-sm">
            <Row
              label="Name"
              value={[me.first_name, me.last_name].filter(Boolean).join(" ") || "—"}
            />
            <Row label="Handle" value={me.username ? `@${me.username}` : "—"} />
            <Row label="Telegram" value={me.telegram_id ?? "Not linked"} />
            <Row label="Quiet hours" value={formatQuiet(me)} />
          </CardContent>
        </Card>

        <SystemStatus health={health} />
      </div>

      <ComingNext />
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4 border-b border-border/80 py-2 last:border-0">
      <span className="font-sans text-xs uppercase tracking-wider text-muted-foreground">
        {label}
      </span>
      <span className="text-right text-foreground">{value}</span>
    </div>
  );
}

function formatQuiet(me: UserRow): string {
  if (!me.quiet_hours_start || !me.quiet_hours_end) return "Off";
  return `${me.quiet_hours_start} – ${me.quiet_hours_end}`;
}

function SystemStatus({ health }: { health: HealthPayload }) {
  const items = [
    { label: "Database", ok: health.db.ok, detail: health.db.source },
    { label: "Sign-in", ok: health.auth.enabled, detail: health.auth.enabled ? "on" : "off" },
    {
      label: "Telegram",
      ok: true,
      detail: health.telegram.botConfigured ? "bot token set" : "webhook ready, token unset",
    },
    { label: "AI", ok: health.ai.ready, detail: health.ai.ready ? "xAI ready" : "no key · degraded" },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>System</CardTitle>
        <CardDescription>Health probe at /health.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {items.map((item) => (
          <div key={item.label} className="flex items-center justify-between gap-3">
            <div>
              <p className="text-sm font-medium">{item.label}</p>
              <p className="font-mono text-xs text-muted-foreground">{item.detail}</p>
            </div>
            <Badge variant={item.ok ? "ok" : "wait"}>{item.ok ? "Ready" : "Later"}</Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function ComingNext() {
  const items = [
    {
      icon: Lightbulb,
      title: "Ideas",
      body: "Live — capture, list, and swipe-sort the raw pile.",
      live: true,
    },
    {
      icon: Brain,
      title: "Workspace",
      body: "Live — brain map with gold at the center, raw on the rim.",
      live: true,
    },
    {
      icon: KeyRound,
      title: "Accounts",
      body: "Live — free-tier unlock timers for Claude, Grok, and more.",
      live: true,
    },
    {
      icon: Sparkles,
      title: "Play / Free",
      body: "Live — clarifying questions, then session-sized prompts via Grok.",
      live: true,
    },
  ];

  return (
    <div>
      <div className="mb-4 flex items-end justify-between gap-4">
        <h2 className="font-display text-xl font-medium tracking-tight">The four rooms</h2>
        <Link
          to="/admin"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <Lock className="size-3.5" />
          Admin
        </Link>
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {items.map((item) => (
          <Card key={item.title} className="rounded-lg">
            <CardHeader className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground">
                <item.icon className="size-4" strokeWidth={1.75} />
                <CardTitle className="font-sans text-sm font-medium tracking-normal">
                  {item.title}
                  {item.live && (
                    <Badge variant="ok" className="ml-2 align-middle">
                      Live
                    </Badge>
                  )}
                </CardTitle>
              </div>
              <CardDescription className="mt-2">{item.body}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </div>
    </div>
  );
}

function HomeSkeleton() {
  return (
    <div className="space-y-8">
      <div className="space-y-3">
        <Skeleton className="h-3 w-28" />
        <Skeleton className="h-12 w-64" />
        <Skeleton className="h-16 w-full max-w-lg" />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Skeleton className="h-56 rounded-xl" />
        <Skeleton className="h-56 rounded-xl" />
      </div>
    </div>
  );
}
