import { useEffect, useState } from "react";
import { createFileRoute, Navigate } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  GROK_PROVIDERS,
  authEnabled,
  isTelegramMiniApp,
  signIn,
  signInWithTma,
} from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const [tma, setTma] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setTma(isTelegramMiniApp());
  }, []);

  useEffect(() => {
    if (!tma || user || isPending) return;
    let cancelled = false;
    (async () => {
      setBusy(true);
      const res = await signInWithTma();
      if (cancelled) return;
      setBusy(false);
      if (!res.ok) {
        setError(res.error);
        return;
      }
      window.location.href = "/";
    })();
    return () => {
      cancelled = true;
    };
  }, [tma, user, isPending]);

  if (isPending || (tma && busy && !error)) {
    return (
      <AppShell>
        <main className="mx-auto grid min-h-[calc(100dvh-4rem)] max-w-sm place-items-center px-4">
          <div className="w-full space-y-3">
            <Skeleton className="h-8 w-40" />
            <Skeleton className="h-11 w-full" />
            <p className="text-center text-sm text-muted-foreground">
              {tma ? "Signing in with Telegram…" : "Loading…"}
            </p>
          </div>
        </main>
      </AppShell>
    );
  }

  if (user) return <Navigate to="/" />;

  return (
    <AppShell>
      <main className="mx-auto grid min-h-[calc(100dvh-4rem)] max-w-sm place-items-center px-4 py-12">
        <div className="w-full space-y-6">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
              Sign in
            </p>
            <h1 className="mt-3 font-display text-3xl font-medium tracking-tight">
              Open your inbox
            </h1>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {tma
                ? "Continue with your Telegram account. Google/Apple are not available inside the Mini App."
                : "Your ideas stay attached to this account across devices."}
            </p>
          </div>
          {error && <p className="text-sm text-danger">{error}</p>}
          {tma ? (
            <Button
              type="button"
              className="w-full"
              disabled={busy}
              onClick={async () => {
                setBusy(true);
                setError(null);
                const res = await signInWithTma();
                setBusy(false);
                if (!res.ok) {
                  setError(res.error);
                  return;
                }
                window.location.href = "/";
              }}
            >
              {busy ? "Signing in…" : "Continue with Telegram"}
            </Button>
          ) : authEnabled ? (
            <div className="flex flex-col gap-2">
              {GROK_PROVIDERS.map((p) => (
                <Button
                  key={p.providerId}
                  type="button"
                  variant={p.providerId === "google" ? "default" : "secondary"}
                  onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                >
                  Continue with {p.label}
                </Button>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Sign-in is disabled.</p>
          )}
        </div>
      </main>
    </AppShell>
  );
}
