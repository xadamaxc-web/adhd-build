import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/webhook/telegram")({
  server: {
    handlers: {
      GET: () =>
        Response.json({
          ok: true,
          service: "my-adhd",
          endpoint: "/webhook/telegram",
        }),
      POST: async ({ request }) => {
        const { handleTelegramUpdate } = await import("@/lib/telegram/bot");
        const { insertLog } = await import("@/lib/adhd/logs");
        try {
          const update = await request.json();
          await handleTelegramUpdate(update);
          return Response.json({ ok: true });
        } catch (err) {
          await insertLog(
            "webhook_error",
            err instanceof Error ? err.message : "webhook failed",
          );
          return Response.json({ ok: true, ignored: true });
        }
      },
    },
  },
});
