import { useCallback, useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Lock, Shield } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { RoomNav } from "@/components/room-nav";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  banUser,
  cleanLogs,
  getAdminFlags,
  getAdminHealthDetail,
  getAdminLogs,
  getAdminOverview,
  getAdminSettings,
  getAdminUsers,
  saveAdminSetting,
  sendBroadcast,
  toggleFlag,
  toggleTrigger,
} from "@/lib/adhd/admin-client";
import type {
  AdminStats,
  FlagRow,
  LogRow,
  SettingRow,
  TriggerRow,
} from "@/lib/adhd/admin";
import type { UserRow } from "@/lib/adhd/types";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/admin")({ component: AdminPage });

type Tab = "overview" | "users" | "logs" | "flags" | "broadcast" | "ops";

function AdminPage() {
  const { user, isPending } = useCurrentUserState();
  const [tab, setTab] = useState<Tab>("overview");
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [flags, setFlags] = useState<FlagRow[]>([]);
  const [settings, setSettings] = useState<SettingRow[]>([]);
  const [triggers, setTriggers] = useState<TriggerRow[]>([]);
  const [broadcastMsg, setBroadcastMsg] = useState("");
  const [broadcastResult, setBroadcastResult] = useState<string | null>(null);
  const [healthDetail, setHealthDetail] = useState<{
    health: { ok: boolean; db: { ok: boolean; source: string }; auth: { enabled: boolean }; telegram: { botConfigured: boolean }; ai: { ready: boolean } };
    env: { botToken: boolean; xaiKey: boolean; ownerTelegram: boolean; tmaUrl: boolean };
  } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const loadOverview = useCallback(async () => {
    try {
      const res = await getAdminOverview();
      setIsAdmin(res.isAdmin);
      setStats(res.stats);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load");
      setIsAdmin(false);
    }
  }, []);

  useEffect(() => {
    if (user) void loadOverview();
  }, [user, loadOverview]);

  useEffect(() => {
    if (!isAdmin || !user) return;
    let cancelled = false;
    (async () => {
      try {
        if (tab === "users") {
          const rows = await getAdminUsers();
          if (!cancelled) setUsers(rows);
        } else if (tab === "logs") {
          const rows = await getAdminLogs();
          if (!cancelled) setLogs(rows);
        } else if (tab === "flags") {
          const rows = await getAdminFlags();
          if (!cancelled) setFlags(rows);
        } else if (tab === "ops") {
          const [ops, health] = await Promise.all([
            getAdminSettings(),
            getAdminHealthDetail(),
          ]);
          if (!cancelled) {
            setSettings(ops.settings);
            setTriggers(ops.triggers);
            setHealthDetail(health);
          }
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : "Load failed");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [tab, isAdmin, user]);

  async function handleBan(targetId: string, banned: boolean) {
    if (busy) return;
    setBusy(true);
    try {
      await banUser({ data: { userId: targetId, banned } });
      const rows = await getAdminUsers();
      setUsers(rows);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ban failed");
    } finally {
      setBusy(false);
    }
  }

  async function handleFlag(key: string, enabled: boolean) {
    if (busy) return;
    setBusy(true);
    try {
      await toggleFlag({ data: { key, enabled } });
      const rows = await getAdminFlags();
      setFlags(rows);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Flag failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6 sm:py-12">
        <div className="flex items-center gap-3">
          <Button asChild variant="secondary" size="sm">
            <Link to="/">
              <ArrowLeft className="size-3.5" />
              Inbox
            </Link>
          </Button>
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
              Session 14 · Admin complete
            </p>
            <h1 className="font-display text-2xl font-medium tracking-tight sm:text-3xl">
              Owner tools
            </h1>
          </div>
        </div>

        <RoomNav />

        {isPending ? (
          <Skeleton className="h-48 rounded-xl" />
        ) : !user ? (
          <RedirectToSignIn />
        ) : isAdmin === null ? (
          <Skeleton className="h-48 rounded-xl" />
        ) : !isAdmin ? (
          <Card className="max-w-lg">
            <CardHeader>
              <div className="mb-2 flex size-10 items-center justify-center rounded-md border border-border bg-card-elevated text-muted-foreground">
                <Lock className="size-4" strokeWidth={1.75} />
              </div>
              <CardTitle>Access denied</CardTitle>
              <CardDescription>
                This area is for owners and support admins only.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="secondary">
                <Link to="/">Back to inbox</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {error && (
              <p className="text-sm text-danger">{error}</p>
            )}

            <div className="flex flex-wrap gap-2">
              {(
                [
                  ["overview", "Overview"],
                  ["users", "Users"],
                  ["logs", "Logs"],
                  ["flags", "Flags"],
                  ["broadcast", "Broadcast"],
                  ["ops", "Ops"],
                ] as const
              ).map(([key, label]) => (
                <Button
                  key={key}
                  type="button"
                  size="sm"
                  variant={tab === key ? "default" : "secondary"}
                  onClick={() => setTab(key)}
                >
                  {label}
                </Button>
              ))}
            </div>

            {tab === "overview" && stats && (
              <div className="grid gap-3 sm:grid-cols-3">
                {(
                  [
                    ["Users", stats.users],
                    ["Thoughts", stats.thoughts],
                    ["Gold", stats.gold],
                    ["Raw", stats.raw],
                    ["Accounts", stats.accounts],
                    ["Logs (24h)", stats.logs24h],
                  ] as const
                ).map(([label, value]) => (
                  <Card key={label}>
                    <CardHeader className="p-4 pb-1">
                      <CardDescription>{label}</CardDescription>
                      <CardTitle className="font-display text-3xl tabular-nums">
                        {value}
                      </CardTitle>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            )}

            {tab === "users" && (
              <ul className="space-y-2">
                {users.length === 0 ? (
                  <Card className="border-dashed">
                    <CardContent className="py-8 text-center text-sm text-muted-foreground">
                      No users yet.
                    </CardContent>
                  </Card>
                ) : (
                  users.map((u) => (
                    <li key={u.user_id}>
                      <Card>
                        <CardContent className="flex flex-wrap items-center gap-3 p-4">
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <p className="font-medium">
                                {[u.first_name, u.last_name].filter(Boolean).join(" ") ||
                                  u.username ||
                                  u.user_id.slice(0, 12)}
                              </p>
                              {u.is_banned && <Badge variant="wait">banned</Badge>}
                              {u.is_premium && <Badge variant="ok">premium</Badge>}
                            </div>
                            <p className="mt-1 font-mono text-xs text-muted-foreground">
                              {u.telegram_id ? `tg:${u.telegram_id}` : u.user_id}
                              {u.last_active_at &&
                                ` · ${new Date(u.last_active_at).toLocaleString()}`}
                            </p>
                          </div>
                          <Button
                            type="button"
                            size="sm"
                            variant="secondary"
                            disabled={busy || u.user_id === user.id}
                            onClick={() => handleBan(u.user_id, !u.is_banned)}
                          >
                            {u.is_banned ? "Unban" : "Ban"}
                          </Button>
                        </CardContent>
                      </Card>
                    </li>
                  ))
                )}
              </ul>
            )}

            {tab === "logs" && (
              <ul className="space-y-2">
                {logs.length === 0 ? (
                  <Card className="border-dashed">
                    <CardContent className="py-8 text-center text-sm text-muted-foreground">
                      No logs yet.
                    </CardContent>
                  </Card>
                ) : (
                  logs.map((l) => (
                    <li key={l.id}>
                      <Card>
                        <CardContent className="p-4">
                          <div className="mb-1 flex flex-wrap items-center gap-2">
                            <Badge variant="outline">{l.type}</Badge>
                            <span className="font-mono text-xs text-muted-foreground">
                              {new Date(l.created_at).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-sm">{l.message}</p>
                        </CardContent>
                      </Card>
                    </li>
                  ))
                )}
              </ul>
            )}

            {tab === "flags" && (
              <ul className="space-y-2">
                {flags.map((f) => (
                  <li key={f.key}>
                    <Card>
                      <CardContent className="flex items-center justify-between gap-3 p-4">
                        <div>
                          <p className="font-medium">{f.key}</p>
                          <p className="font-mono text-xs text-muted-foreground">
                            {new Date(f.updated_at).toLocaleString()}
                          </p>
                        </div>
                        <Button
                          type="button"
                          size="sm"
                          variant={f.enabled ? "default" : "secondary"}
                          disabled={busy}
                          onClick={() => handleFlag(f.key, !f.enabled)}
                        >
                          {f.enabled ? "On" : "Off"}
                        </Button>
                      </CardContent>
                    </Card>
                  </li>
                ))}
              </ul>
            )}


            {tab === "broadcast" && (
              <Card className="max-w-xl">
                <CardHeader>
                  <CardTitle className="text-base">Broadcast</CardTitle>
                  <CardDescription>
                    Send a message to every non-banned user with a linked Telegram ID.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <textarea
                    value={broadcastMsg}
                    onChange={(e) => setBroadcastMsg(e.target.value)}
                    rows={5}
                    placeholder="Keep it short. This hits real users."
                    className="w-full resize-none rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    <Button
                      type="button"
                      disabled={busy || !broadcastMsg.trim()}
                      onClick={async () => {
                        setBusy(true);
                        setBroadcastResult(null);
                        try {
                          const res = await sendBroadcast({
                            data: { message: broadcastMsg.trim() },
                          });
                          if (!res.ok) {
                            setBroadcastResult(res.error);
                          } else {
                            setBroadcastResult(
                              `Sent ${res.sent}, failed ${res.failed}`,
                            );
                            setBroadcastMsg("");
                          }
                        } catch (err) {
                          setBroadcastResult(
                            err instanceof Error ? err.message : "Failed",
                          );
                        } finally {
                          setBusy(false);
                        }
                      }}
                    >
                      {busy ? "Sending…" : "Send broadcast"}
                    </Button>
                    {broadcastResult && (
                      <span className="text-sm text-muted-foreground">
                        {broadcastResult}
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {tab === "ops" && (
              <div className="space-y-6">
                <section className="space-y-3">
                  <h2 className="font-display text-lg font-medium tracking-tight">
                    API status
                  </h2>
                  {healthDetail ? (
                    <div className="grid gap-2 sm:grid-cols-2">
                      {(
                        [
                          ["Database", healthDetail.health.db.ok, healthDetail.health.db.source],
                          ["Auth", healthDetail.health.auth.enabled, healthDetail.health.auth.enabled ? "on" : "off"],
                          ["Telegram bot", healthDetail.env.botToken, healthDetail.health.telegram.botConfigured ? "token set" : "missing"],
                          ["xAI key", healthDetail.env.xaiKey, healthDetail.health.ai.ready ? "ready" : "missing"],
                          ["Owner TG", healthDetail.env.ownerTelegram, healthDetail.env.ownerTelegram ? "set" : "unset"],
                          ["TMA URL env", healthDetail.env.tmaUrl, healthDetail.env.tmaUrl ? "set" : "unset"],
                        ] as const
                      ).map(([label, ok, detail]) => (
                        <Card key={label}>
                          <CardContent className="flex items-center justify-between gap-2 p-4">
                            <div>
                              <p className="text-sm font-medium">{label}</p>
                              <p className="font-mono text-xs text-muted-foreground">
                                {detail}
                              </p>
                            </div>
                            <Badge variant={ok ? "ok" : "wait"}>
                              {ok ? "OK" : "—"}
                            </Badge>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <Skeleton className="h-24 rounded-xl" />
                  )}
                </section>

                <section className="space-y-3">
                  <h2 className="font-display text-lg font-medium tracking-tight">
                    Settings
                  </h2>
                  <ul className="space-y-2">
                    {settings.map((s) => (
                      <li key={s.key}>
                        <Card>
                          <CardContent className="flex flex-wrap items-center gap-2 p-4">
                            <span className="w-40 shrink-0 font-mono text-xs text-muted-foreground">
                              {s.key}
                            </span>
                            <input
                              defaultValue={s.value}
                              className="min-w-0 flex-1 rounded-lg border border-border bg-card-elevated px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                              onBlur={async (e) => {
                                const value = e.target.value;
                                if (value === s.value) return;
                                setBusy(true);
                                try {
                                  await saveAdminSetting({
                                    data: { key: s.key, value },
                                  });
                                  const ops = await getAdminSettings();
                                  setSettings(ops.settings);
                                } finally {
                                  setBusy(false);
                                }
                              }}
                            />
                          </CardContent>
                        </Card>
                      </li>
                    ))}
                  </ul>
                </section>

                <section className="space-y-3">
                  <h2 className="font-display text-lg font-medium tracking-tight">
                    Triggers
                  </h2>
                  <ul className="space-y-2">
                    {triggers.map((tr) => (
                      <li key={tr.key}>
                        <Card>
                          <CardContent className="flex items-center justify-between gap-3 p-4">
                            <div>
                              <p className="font-medium">{tr.key}</p>
                              <p className="text-xs text-muted-foreground">
                                every {tr.frequency_hours}h
                                {tr.last_run_at
                                  ? ` · last ${new Date(tr.last_run_at).toLocaleString()}`
                                  : " · never run"}
                              </p>
                            </div>
                            <Button
                              type="button"
                              size="sm"
                              variant={tr.enabled ? "default" : "secondary"}
                              disabled={busy}
                              onClick={async () => {
                                setBusy(true);
                                try {
                                  await toggleTrigger({
                                    data: { key: tr.key, enabled: !tr.enabled },
                                  });
                                  const ops = await getAdminSettings();
                                  setTriggers(ops.triggers);
                                } finally {
                                  setBusy(false);
                                }
                              }}
                            >
                              {tr.enabled ? "On" : "Off"}
                            </Button>
                          </CardContent>
                        </Card>
                      </li>
                    ))}
                  </ul>
                </section>

                <section className="space-y-3">
                  <h2 className="font-display text-lg font-medium tracking-tight">
                    Maintenance
                  </h2>
                  <Button
                    type="button"
                    variant="secondary"
                    disabled={busy}
                    onClick={async () => {
                      setBusy(true);
                      try {
                        const res = await cleanLogs({ data: { days: 14 } });
                        setError(null);
                        setBroadcastResult(`Deleted ${res.deleted} old logs`);
                      } catch (err) {
                        setError(
                          err instanceof Error ? err.message : "Clean failed",
                        );
                      } finally {
                        setBusy(false);
                      }
                    }}
                  >
                    Clean logs older than 14 days
                  </Button>
                </section>
              </div>
            )}

            <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Shield className="size-3.5" />
              Session 14 · broadcasts, ops, API status
            </p>
          </div>
        )}
      </main>
    </AppShell>
  );
}
