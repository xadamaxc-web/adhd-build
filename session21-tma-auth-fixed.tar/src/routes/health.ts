import { createFileRoute } from "@tanstack/react-router";

async function healthResponse() {
  const { buildHealth } = await import("@/lib/adhd/health.server");
  const body = await buildHealth();
  return Response.json(body, { status: body.ok ? 200 : 503 });
}

export const Route = createFileRoute("/health")({
  server: {
    handlers: {
      GET: healthResponse,
    },
  },
});
