import { useCallback, useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Sparkles } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { RoomNav } from "@/components/room-nav";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  freeSessions,
  generateQuestions,
  generateSessions,
  listMyPlans,
  type FreeSession,
} from "@/lib/adhd/play-client";
import type { IdeaPlanRow } from "@/lib/adhd/play";
import { listMyThoughts } from "@/lib/adhd/thoughts-client";
import { previewText } from "@/lib/adhd/format";
import type { ThoughtRow } from "@/lib/adhd/types";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/play")({ component: PlayPage });

type Step =
  | { kind: "pick" }
  | { kind: "questions"; thought: ThoughtRow; playId: number; questions: string[] }
  | {
      kind: "result";
      thought: ThoughtRow;
      generalPrompt: string;
      sessions: string[];
    }
  | { kind: "free_loading"; thought: ThoughtRow }
  | {
      kind: "free_result";
      thought: ThoughtRow;
      generalPrompt: string;
      sessions: FreeSession[];
    };

function PlayPage() {
  const { user, isPending } = useCurrentUserState();
  const [gold, setGold] = useState<ThoughtRow[] | null>(null);
  const [plans, setPlans] = useState<IdeaPlanRow[]>([]);
  const [step, setStep] = useState<Step>({ kind: "pick" });
  const [answers, setAnswers] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  function copyText(text: string) {
    void navigator.clipboard.writeText(text).then(() => {
      setToast("Copied");
      window.setTimeout(() => setToast(null), 1500);
    });
  }

  const load = useCallback(async () => {
    try {
      const [g, p] = await Promise.all([
        listMyThoughts({ data: { status: "gold" } }),
        listMyPlans(),
      ]);
      setGold(g);
      setPlans(p);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load");
    }
  }, []);

  useEffect(() => {
    if (user) load();
  }, [user, load]);

  async function startFree(tRow: ThoughtRow) {
    if (busy) return;
    setBusy(true);
    setError(null);
    setStep({ kind: "free_loading", thought: tRow });
    try {
      const res = await freeSessions({ data: { thoughtId: tRow.id } });
      if (!res.ok) {
        setError(res.error);
        setStep({ kind: "pick" });
        return;
      }
      setStep({
        kind: "free_result",
        thought: tRow,
        generalPrompt: res.generalPrompt,
        sessions: res.sessions,
      });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Free failed");
      setStep({ kind: "pick" });
    } finally {
      setBusy(false);
    }
  }

  async function startPlay(t: ThoughtRow) {
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await generateQuestions({
        data: { thoughtId: t.id, content: t.content },
      });
      if (!res.ok) {
        setError(res.error);
        return;
      }
      setAnswers(res.questions.map(() => ""));
      setStep({
        kind: "questions",
        thought: t,
        playId: res.playId,
        questions: res.questions,
      });
    } finally {
      setBusy(false);
    }
  }

  async function finishPlay() {
    if (step.kind !== "questions" || busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await generateSessions({
        data: {
          thoughtId: step.thought.id,
          playId: step.playId,
          content: step.thought.content,
          questions: step.questions,
          answers,
        },
      });
      if (!res.ok) {
        setError(res.error);
        return;
      }
      setStep({
        kind: "result",
        thought: step.thought,
        generalPrompt: res.generalPrompt,
        sessions: res.sessions,
      });
      await load();
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6 sm:py-12">
        <div className="mb-8 flex items-center gap-3">
          <Button asChild variant="secondary" size="sm">
            <Link to="/">
              <ArrowLeft className="size-3.5" />
              Inbox
            </Link>
          </Button>
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
              Session 8 · Play / Free
            </p>
            <h1 className="font-display text-2xl font-medium tracking-tight sm:text-3xl">
              Split an idea
            </h1>
          </div>
        
        </div>

        <RoomNav />

        <p className="mb-6 max-w-xl text-sm text-muted-foreground">
          Pick a gold idea. Grok asks a few clarifying questions, then breaks it
          into session-sized prompts you can actually finish.
        </p>

        {isPending ? (
          <Skeleton className="h-48 w-full rounded-xl" />
        ) : !user ? (
          <RedirectToSignIn />
        ) : (
          <div className="space-y-8">
            {error && (
              <Card className="border-danger/40">
                <CardContent className="py-4 text-sm text-danger">{error}</CardContent>
              </Card>
            )}
            {toast && <p className="text-sm text-muted-foreground">{toast}</p>}

            {step.kind === "pick" && (
              <section className="space-y-3">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Sparkles className="size-4" strokeWidth={1.75} />
                  <h2 className="font-display text-lg font-medium tracking-tight text-foreground">
                    Gold ideas
                  </h2>
                </div>
                {gold === null ? (
                  <Skeleton className="h-32 rounded-xl" />
                ) : gold.length === 0 ? (
                  <Card className="border-dashed">
                    <CardContent className="py-10 text-center text-sm text-muted-foreground">
                      No gold ideas yet. Capture something, swipe it to gold, then
                      come back.
                    </CardContent>
                  </Card>
                ) : (
                  <ul className="space-y-2">
                    {gold.map((t) => (
                      <li key={t.id}>
                        <Card>
                          <CardContent className="flex flex-wrap items-center gap-3 p-4">
                            <p className="min-w-0 flex-1 text-sm leading-relaxed">
                              {previewText(t.content, 160)}
                            </p>
                            <div className="flex shrink-0 gap-2">
                              <Button type="button" size="sm" variant="secondary" disabled={busy} onClick={() => void startFree(t)}>
                                Free
                              </Button>
                              <Button type="button" size="sm" disabled={busy} onClick={() => startPlay(t)}>
                                {busy ? "Thinking…" : "Play"}
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            )}

            {step.kind === "questions" && (
              <section className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Your idea</CardTitle>
                    <CardDescription className="whitespace-pre-wrap">
                      {step.thought.content}
                    </CardDescription>
                  </CardHeader>
                </Card>
                <div className="space-y-4">
                  {step.questions.map((q, i) => (
                    <div key={i} className="space-y-2">
                      <label className="text-sm font-medium">{q}</label>
                      <textarea
                        value={answers[i] ?? ""}
                        onChange={(e) => {
                          const next = [...answers];
                          next[i] = e.target.value;
                          setAnswers(next);
                        }}
                        rows={2}
                        className="w-full resize-none rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                        placeholder="Your answer…"
                      />
                    </div>
                  ))}
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    type="button"
                    disabled={busy}
                    onClick={finishPlay}
                  >
                    {busy ? "Building sessions…" : "Generate sessions"}
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    disabled={busy}
                    onClick={() => setStep({ kind: "pick" })}
                  >
                    Cancel
                  </Button>
                </div>
              </section>
            )}

            {step.kind === "result" && (
              <section className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Overall</CardTitle>
                    <CardDescription className="whitespace-pre-wrap text-foreground">
                      {step.generalPrompt}
                    </CardDescription>
                    <Button type="button" size="sm" variant="secondary" className="mt-2" onClick={() => copyText(step.generalPrompt)}>
                      Copy
                    </Button>
                  </CardHeader>
                </Card>
                <ol className="space-y-2">
                  {step.sessions.map((s, i) => (
                    <li key={i}>
                      <Card>
                        <CardContent className="flex gap-3 p-4">
                          <Badge variant="ok" className="h-fit shrink-0">
                            {i + 1}
                          </Badge>
                          <p className="min-w-0 flex-1 text-sm leading-relaxed whitespace-pre-wrap">
                            {s}
                          </p>
                          <Button type="button" size="sm" variant="secondary" className="shrink-0" onClick={() => copyText(s)}>
                            Copy
                          </Button>
                        </CardContent>
                      </Card>
                    </li>
                  ))}
                </ol>
                <Button type="button" variant="secondary" onClick={() => setStep({ kind: "pick" })}>
                  Play another
                </Button>
              </section>
            )}


            {step.kind === "free_loading" && (
              <section className="space-y-3">
                <Skeleton className="h-8 w-48 rounded-lg" />
                <Skeleton className="h-24 rounded-xl" />
                <p className="text-sm text-muted-foreground">Splitting into free-tier sessions…</p>
              </section>
            )}

            {step.kind === "free_result" && (
              <section className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Overall</CardTitle>
                    <CardDescription className="whitespace-pre-wrap text-foreground">
                      {step.generalPrompt}
                    </CardDescription>
                    <Button type="button" size="sm" variant="secondary" className="mt-2 w-fit" onClick={() => copyText(step.generalPrompt)}>
                      Copy
                    </Button>
                  </CardHeader>
                </Card>
                <ol className="space-y-2">
                  {step.sessions.map((s) => (
                    <li key={s.index}>
                      <Card>
                        <CardContent className="flex gap-3 p-4">
                          <Badge variant="ok" className="h-fit shrink-0">{s.index}</Badge>
                          <div className="min-w-0 flex-1">
                            <p className="text-xs uppercase text-muted-foreground">{s.provider}</p>
                            <p className="text-sm whitespace-pre-wrap">{s.prompt}</p>
                          </div>
                          <Button type="button" size="sm" variant="secondary" onClick={() => copyText(s.prompt)}>Copy</Button>
                        </CardContent>
                      </Card>
                    </li>
                  ))}
                </ol>
                <Button type="button" variant="secondary" onClick={() => setStep({ kind: "pick" })}>Back</Button>
              </section>
            )}

            {plans.length > 0 && step.kind === "pick" && (
              <section className="space-y-3">
                <h2 className="font-display text-lg font-medium tracking-tight">
                  Recent plans
                </h2>
                <ul className="space-y-2">
                  {plans.slice(0, 5).map((p) => {
                    let sessions: string[] = [];
                    try {
                      sessions = JSON.parse(p.sessions_json) as string[];
                    } catch {
                      /* ignore */
                    }
                    return (
                      <li key={p.id}>
                        <Card>
                          <CardContent className="p-4">
                            <p className="text-sm font-medium">
                              {p.general_prompt || "Plan"}
                            </p>
                            <p className="mt-1 text-xs text-muted-foreground">
                              {sessions.length} sessions ·{" "}
                              {new Date(p.created_at).toLocaleString()}
                            </p>
                          </CardContent>
                        </Card>
                      </li>
                    );
                  })}
                </ul>
              </section>
            )}
          </div>
        )}
      </main>
    </AppShell>
  );
}
