import { useCallback, useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Clock, KeyRound, Plus, Trash2 } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { RoomNav } from "@/components/room-nav";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  addAccount,
  listMyAccounts,
  removeAccount,
  useAccount,
} from "@/lib/adhd/accounts-client";
import {
  displayProvider,
  formatCountdown,
  formatUnlockClock,
} from "@/lib/adhd/format";
import type { AccountRow } from "@/lib/adhd/types";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/accounts")({ component: AccountsPage });

const PRESETS = [
  { provider: "claude", label: "Claude free", hours: 5 },
  { provider: "grok", label: "Grok free", hours: 2 },
  { provider: "chatgpt", label: "ChatGPT free", hours: 3 },
  { provider: "gemini", label: "Gemini free", hours: 4 },
];

function AccountsPage() {
  const { user, isPending } = useCurrentUserState();
  const [rows, setRows] = useState<AccountRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [now, setNow] = useState(() => new Date());
  const [customProvider, setCustomProvider] = useState("");
  const [customLabel, setCustomLabel] = useState("");
  const [customHours, setCustomHours] = useState(5);

  const load = useCallback(async () => {
    try {
      const list = await listMyAccounts();
      setRows(list);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load accounts");
    }
  }, []);

  useEffect(() => {
    if (user) load();
  }, [user, load]);

  // live countdown tick
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  async function handlePreset(p: (typeof PRESETS)[number]) {
    if (busy) return;
    setBusy(true);
    try {
      await addAccount({
        data: { provider: p.provider, label: p.label, cooldownHours: p.hours },
      });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not add account");
    } finally {
      setBusy(false);
    }
  }

  async function handleCustom(e: React.FormEvent) {
    e.preventDefault();
    if (!customProvider.trim() || busy) return;
    setBusy(true);
    try {
      await addAccount({
        data: {
          provider: customProvider.trim(),
          label: customLabel.trim() || customProvider.trim(),
          cooldownHours: customHours > 0 ? customHours : 5,
        },
      });
      setCustomProvider("");
      setCustomLabel("");
      setCustomHours(5);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not add account");
    } finally {
      setBusy(false);
    }
  }

  async function handleUse(id: number) {
    if (busy) return;
    setBusy(true);
    try {
      await useAccount({ data: { id } });
      await load();
    } finally {
      setBusy(false);
    }
  }

  async function handleRemove(id: number) {
    if (busy) return;
    setBusy(true);
    try {
      await removeAccount({ data: { id } });
      await load();
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6 sm:py-12">
        <div className="mb-8 flex items-center gap-3">
          <Button asChild variant="secondary" size="sm">
            <Link to="/">
              <ArrowLeft className="size-3.5" />
              Inbox
            </Link>
          </Button>
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground">
              Session 6 · Accounts
            </p>
            <h1 className="font-display text-2xl font-medium tracking-tight sm:text-3xl">
              Free-tier timers
            </h1>
          </div>
        
        </div>

        <RoomNav />

        {isPending ? (
          <div className="grid gap-4 sm:grid-cols-2">
            <Skeleton className="h-40 rounded-xl" />
            <Skeleton className="h-40 rounded-xl" />
          </div>
        ) : !user ? (
          <RedirectToSignIn />
        ) : (
          <div className="space-y-8">
            <p className="max-w-xl text-sm text-muted-foreground">
              Track when free Claude, Grok, ChatGPT, or any other account unlocks
              again. Hit <strong className="text-foreground">Used</strong> after
              you spend a turn — the cooldown starts automatically.
            </p>

            {error && (
              <Card className="border-danger/40">
                <CardContent className="py-4 text-sm text-danger">{error}</CardContent>
              </Card>
            )}

            {/* Live list */}
            <section className="space-y-3">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Clock className="size-4" strokeWidth={1.75} />
                <h2 className="font-display text-lg font-medium tracking-tight text-foreground">
                  Your accounts
                </h2>
              </div>

              {rows === null ? (
                <Skeleton className="h-32 rounded-xl" />
              ) : rows.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="py-10 text-center text-sm text-muted-foreground">
                    No timers yet. Add a free-tier account below.
                  </CardContent>
                </Card>
              ) : (
                <ul className="space-y-2">
                  {rows.map((a) => {
                    const unlocks = new Date(a.unlocks_at);
                    const ready = unlocks.getTime() <= now.getTime();
                    return (
                      <li key={a.id}>
                        <Card>
                          <CardContent className="flex flex-wrap items-center gap-3 p-4 sm:flex-nowrap">
                            <div className="min-w-0 flex-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <p className="font-medium">
                                  {displayProvider(a.provider)}
                                </p>
                                <Badge variant={ready ? "ok" : "wait"}>
                                  {ready ? "Ready" : formatCountdown(a.unlocks_at, now)}
                                </Badge>
                              </div>
                              <p className="mt-1 text-sm text-muted-foreground">
                                {a.label}
                                {!ready && (
                                  <span className="ml-2 font-mono text-xs">
                                    · {formatUnlockClock(a.unlocks_at)}
                                  </span>
                                )}
                              </p>
                              <p className="mt-0.5 text-xs text-muted-foreground">
                                Cooldown {a.cooldown_hours}h
                              </p>
                            </div>
                            <div className="flex shrink-0 gap-2">
                              <Button
                                type="button"
                                size="sm"
                                disabled={busy || !ready}
                                onClick={() => handleUse(a.id)}
                              >
                                Used
                              </Button>
                              <Button
                                type="button"
                                size="sm"
                                variant="secondary"
                                disabled={busy}
                                title="Remove"
                                onClick={() => handleRemove(a.id)}
                              >
                                <Trash2 className="size-3.5" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>

            {/* Add */}
            <section className="space-y-3">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Plus className="size-4" strokeWidth={1.75} />
                <h2 className="font-display text-lg font-medium tracking-tight text-foreground">
                  Add account
                </h2>
              </div>

              <div className="flex flex-wrap gap-2">
                {PRESETS.map((p) => (
                  <Button
                    key={p.provider}
                    type="button"
                    variant="secondary"
                    size="sm"
                    disabled={busy}
                    onClick={() => handlePreset(p)}
                  >
                    {p.label}
                    <span className="text-muted-foreground">· {p.hours}h</span>
                  </Button>
                ))}
              </div>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Custom</CardTitle>
                  <CardDescription>
                    Any provider + optional label and cooldown hours.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form
                    onSubmit={handleCustom}
                    className="grid gap-3 sm:grid-cols-[1fr_1fr_5rem_auto]"
                  >
                    <input
                      value={customProvider}
                      onChange={(e) => setCustomProvider(e.target.value)}
                      placeholder="Provider (claude, grok…)"
                      className="rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                      required
                    />
                    <input
                      value={customLabel}
                      onChange={(e) => setCustomLabel(e.target.value)}
                      placeholder="Label (optional)"
                      className="rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                    />
                    <input
                      type="number"
                      min={1}
                      max={168}
                      value={customHours}
                      onChange={(e) => setCustomHours(Number(e.target.value) || 5)}
                      className="rounded-lg border border-border bg-card-elevated px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                      title="Cooldown hours"
                    />
                    <Button type="submit" disabled={busy || !customProvider.trim()}>
                      Add
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </section>
          </div>
        )}
      </main>
    </AppShell>
  );
}
