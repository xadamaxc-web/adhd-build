import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/me")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const { resolveMe } = await import("@/lib/adhd/me.server");
          const me = await resolveMe();
          return Response.json(me);
        } catch (err) {
          const status =
            err && typeof err === "object" && "status" in err
              ? Number((err as { status: number }).status)
              : 500;
          if (status === 401) {
            return Response.json({ error: "Unauthorized" }, { status: 401 });
          }
          const message = err instanceof Error ? err.message : "Server error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
