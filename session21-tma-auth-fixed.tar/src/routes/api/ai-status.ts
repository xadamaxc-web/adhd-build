import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/ai-status")({
  server: {
    handlers: {
      GET: async () => {
        try {
          const { getSessionUser } = await import("@/lib/auth/verify.server");
          const session = await getSessionUser().catch(() => null);
          if (!session?.id) {
            return Response.json({ error: "Unauthorized" }, { status: 401 });
          }
          const { isUserAdmin } = await import("@/lib/adhd/admin");
          if (!(await isUserAdmin(session.id))) {
            return Response.json({ error: "Forbidden" }, { status: 403 });
          }
          const { probeProviders } = await import("@/lib/services/ai");
          const health = await probeProviders();
          return Response.json({
            groq: health.groq,
            cf: health.cf,
            gemini: health.gemini,
            openrouter: health.openrouter,
            xai: health.xai,
          });
        } catch (err) {
          const message = err instanceof Error ? err.message : "Server error";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
