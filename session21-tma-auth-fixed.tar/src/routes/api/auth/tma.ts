import { createFileRoute } from "@tanstack/react-router";
import {
  extractTmaInitData,
  sessionCookieHeader,
  signInWithTelegramInitData,
} from "@/lib/auth/tma.server";
import { TelegramAuthError } from "@/lib/telegram/auth";

export const Route = createFileRoute("/api/auth/tma")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          let initData = extractTmaInitData(request.headers);
          if (!initData) {
            const body = (await request.json().catch(() => null)) as {
              initData?: string;
            } | null;
            initData = body?.initData?.trim() || null;
          }
          if (!initData) {
            return Response.json(
              { error: "Missing initData (body or Authorization: tma …)" },
              { status: 400 },
            );
          }

          const result = await signInWithTelegramInitData(initData);
          const cookie = await sessionCookieHeader(
            result.sessionToken,
            result.expiresAt,
          );

          return new Response(
            JSON.stringify({
              ok: true,
              user: { id: result.userId, name: result.name },
              token: result.sessionToken,
            }),
            {
              status: 200,
              headers: {
                "Content-Type": "application/json",
                "Set-Cookie": cookie,
              },
            },
          );
        } catch (err) {
          if (err instanceof TelegramAuthError) {
            return Response.json({ error: err.message }, { status: 401 });
          }
          const message = err instanceof Error ? err.message : "TMA auth failed";
          return Response.json({ error: message }, { status: 500 });
        }
      },
    },
  },
});
