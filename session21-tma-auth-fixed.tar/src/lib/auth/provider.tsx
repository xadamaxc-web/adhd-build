import { useCallback, useEffect, useState, type ReactNode } from "react";
import { authClient, authEnabled, getTmaInitData, signInWithTma } from "./client";

/**
 * App-wide client provider mounted once in `src/routes/__root.tsx`.
 *
 * Inside a Telegram Mini App (signed initData present) and signed out, it signs
 * in via `/api/auth/tma`, then reloads so SSR + the client both see the session.
 * While that runs, children are NOT rendered, so the Google/Apple landing never
 * flashes. Outside Telegram it is a passthrough and the normal login is untouched.
 */
const TRIED_KEY = "tma-signin-tried";

function tried(v?: boolean): boolean {
  try {
    if (v === true) sessionStorage.setItem(TRIED_KEY, "1");
    else if (v === false) sessionStorage.removeItem(TRIED_KEY);
    return sessionStorage.getItem(TRIED_KEY) === "1";
  } catch {
    return false;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const { data, isPending } = authClient.useSession();
  const signedIn = Boolean(data?.user);
  const [tma, setTma] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => setTma(Boolean(getTmaInitData())), []);

  const run = useCallback(async () => {
    setError(null);
    tried(true);
    const res = await signInWithTma();
    if (res.ok) {
      window.location.reload();
      return;
    }
    tried(false);
    setError(res.error);
  }, []);

  useEffect(() => {
    if (!authEnabled || !tma || isPending) return;
    if (signedIn) {
      tried(false);
      return;
    }
    if (tried()) {
      // Signed in once already, reloaded, still no session: don't loop.
      setError("Signed in, but the session cookie was not recognised.");
      return;
    }
    void run();
  }, [tma, isPending, signedIn, run]);

  if (authEnabled && tma && !signedIn) {
    return (
      <div className="grid min-h-dvh place-items-center bg-background px-4 text-center text-sm text-muted-foreground">
        {error ? (
          <div className="space-y-3">
            <p>{error}</p>
            <button type="button" className="underline" onClick={() => void run()}>
              Retry
            </button>
          </div>
        ) : (
          "Signing in with Telegram…"
        )}
      </div>
    );
  }
  return <>{children}</>;
}
