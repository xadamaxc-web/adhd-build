import { createHmac, randomBytes } from "node:crypto";
import { getRequest } from "@tanstack/react-start/server";
import { env } from "@/lib/env.server";
import {
  TELEGRAM_INIT_DATA_HEADER,
  TelegramAuthError,
  verifyTelegramInitData,
} from "@/lib/telegram/auth";
import { upsertTelegramUser } from "@/lib/adhd/users";
import type { TelegramFrom } from "@/lib/adhd/types";

const SESSION_DAYS = 30;

export function extractTmaInitData(headers: Headers): string | null {
  const auth = headers.get("authorization") ?? headers.get("Authorization");
  if (auth?.toLowerCase().startsWith("tma ")) {
    return auth.slice(4).trim() || null;
  }
  const custom = headers.get(TELEGRAM_INIT_DATA_HEADER);
  if (custom?.trim()) return custom.trim();
  return null;
}

export async function verifyInitData(initData: string) {
  const botToken = env("BOT_TOKEN");
  if (!botToken) throw new TelegramAuthError("BOT_TOKEN is not configured");

  try {
    const mod = await import("@telegram-apps/init-data-node");
    const validate =
      (mod as { validate?: (d: string, t: string, o?: object) => void }).validate ??
      (mod as { default?: { validate?: (d: string, t: string, o?: object) => void } })
        .default?.validate;
    if (typeof validate === "function") {
      validate(initData, botToken, { expiresIn: 60 * 60 * 24 });
    }
  } catch (err) {
    if (err instanceof TelegramAuthError) throw err;
  }

  return verifyTelegramInitData(initData);
}

function telegramAuthUserId(telegramId: string | number): string {
  return `tg:${telegramId}`;
}

function syntheticEmail(telegramId: string | number): string {
  return `tg_${telegramId}@tma.local`;
}

export async function signInWithTelegramInitData(initData: string): Promise<{
  userId: string;
  sessionToken: string;
  expiresAt: Date;
  name: string;
}> {
  const verified = await verifyInitData(initData);
  const from: TelegramFrom = verified.user;
  const userId = telegramAuthUserId(from.id);
  const name =
    [from.first_name, from.last_name].filter(Boolean).join(" ").trim() ||
    from.username ||
    `Telegram ${from.id}`;
  const email = syntheticEmail(from.id);

  await upsertTelegramUser(from);

  const { getSql } = await import("@/lib/db");
  const sql = await getSql();
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  const sessionToken = randomBytes(32).toString("hex");
  const sessionId = randomBytes(16).toString("hex");

  await sql`
    insert into "user" (id, name, email, "emailVerified", "createdAt", "updatedAt")
    values (
      ${userId},
      ${name},
      ${email},
      true,
      ${now.toISOString()}::timestamptz,
      ${now.toISOString()}::timestamptz
    )
    on conflict (id) do update set
      name = excluded.name,
      "updatedAt" = ${now.toISOString()}::timestamptz
  `;

  const existingAcc = await sql<{ id: string }>`
    select id from account
    where "userId" = ${userId} and "providerId" = 'telegram'
    limit 1
  `;
  if (!existingAcc[0]) {
    const accountId = randomBytes(16).toString("hex");
    await sql`
      insert into account (
        id, "accountId", "providerId", "userId",
        "createdAt", "updatedAt"
      )
      values (
        ${accountId},
        ${String(from.id)},
        'telegram',
        ${userId},
        ${now.toISOString()}::timestamptz,
        ${now.toISOString()}::timestamptz
      )
    `;
  }

  try {
    await sql`
      delete from session where "userId" = ${userId} and "expiresAt" < now()
    `;
  } catch {
    /* ignore */
  }

  await sql`
    insert into session (
      id, "expiresAt", token, "createdAt", "updatedAt", "userId"
    )
    values (
      ${sessionId},
      ${expiresAt.toISOString()}::timestamptz,
      ${sessionToken},
      ${now.toISOString()}::timestamptz,
      ${now.toISOString()}::timestamptz,
      ${userId}
    )
  `;

  return { userId, sessionToken, expiresAt, name };
}

/**
 * Set-Cookie for the session, in the exact form Better Auth reads: the name from
 * `auth/server.ts` (`__Host-grok-auth.session_token`) and a value signed
 * `<token>.<base64 HMAC-SHA256(secret)>`. `__Host-` requires Secure + Path=/ and
 * no Domain, so none is set.
 */
export async function sessionCookieHeader(
  token: string,
  expiresAt: Date,
): Promise<string> {
  const { auth, SESSION_TOKEN_COOKIE } = await import("./server");
  const { secret } = await auth.$context;
  const signature = createHmac("sha256", secret).update(token).digest("base64");
  const value = encodeURIComponent(`${token}.${signature}`);
  return `${SESSION_TOKEN_COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Expires=${expiresAt.toUTCString()}`;
}

export async function tryTmaSessionFromRequest(
  headers: Headers,
): Promise<{ userId: string; sessionToken: string; expiresAt: Date } | null> {
  const initData = extractTmaInitData(headers);
  if (!initData) return null;
  try {
    const result = await signInWithTelegramInitData(initData);
    return {
      userId: result.userId,
      sessionToken: result.sessionToken,
      expiresAt: result.expiresAt,
    };
  } catch {
    return null;
  }
}

export async function tmaSignInFromCurrentRequest(): Promise<{
  userId: string;
  sessionToken: string;
  expiresAt: Date;
  name: string;
} | null> {
  const request = getRequest();
  if (!request) return null;
  const initData = extractTmaInitData(request.headers);
  if (!initData) return null;
  return signInWithTelegramInitData(initData);
}
