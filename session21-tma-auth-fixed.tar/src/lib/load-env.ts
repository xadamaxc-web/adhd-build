/**
 * Load `.env` into process.env before any other server module reads config.
 * Uses DOTENV_CONFIG_PATH if set, otherwise process.cwd() + "/.env".
 */
import { config as loadDotenv } from "dotenv";
import { resolve } from "node:path";

if (typeof process !== "undefined" && typeof window === "undefined") {
  const path =
    process.env.DOTENV_CONFIG_PATH?.trim() ||
    resolve(process.cwd(), ".env");
  loadDotenv({ path });
}
