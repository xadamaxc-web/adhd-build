import { getSetting } from "@/lib/adhd/settings";
import { env } from "@/lib/env.server";

function stripSlash(value: string): string {
  return value.trim().replace(/\/$/, "");
}

/** Absolute Mini App URL for Telegram web_app buttons, or null in local preview. */
export async function getTmaUrl(): Promise<string | null> {
  const fromEnv = env("TMA_URL");
  if (fromEnv) return stripSlash(fromEnv);

  const fromDb = await getSetting("tma_url");
  if (fromDb) return stripSlash(fromDb);

  const vercel = env("VERCEL_URL");
  if (vercel) {
    const host = vercel.startsWith("http") ? vercel : `https://${vercel}`;
    return `${stripSlash(host)}/app`;
  }
  return null;
}

export function tmaHref(base: string | null, startapp: string): string {
  if (!base) return `/app?startapp=${encodeURIComponent(startapp)}`;
  try {
    const url = new URL(base);
    url.searchParams.set("startapp", startapp);
    return url.toString();
  } catch {
    const join = base.includes("?") ? "&" : "?";
    return `${base}${join}startapp=${encodeURIComponent(startapp)}`;
  }
}

export function miniAppButton(label: string, startapp: string) {
  return { label, kind: "web_app" as const, startapp };
}
