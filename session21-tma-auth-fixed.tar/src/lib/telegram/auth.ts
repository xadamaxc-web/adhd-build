import { createHmac, timingSafeEqual } from "node:crypto";
import { env } from "@/lib/env.server";
import type { TelegramFrom } from "@/lib/adhd/types";

export const TELEGRAM_INIT_DATA_HEADER = "x-telegram-init-data";

const MAX_AUTH_AGE_SECONDS = 60 * 60 * 24;

export class TelegramAuthError extends Error {
  readonly status = 401;
  constructor(message = "Invalid Telegram init data") {
    super(message);
    this.name = "TelegramAuthError";
  }
}

export type VerifiedTelegramInit = {
  user: TelegramFrom;
  authDate: number;
  queryId?: string;
  startParam?: string;
};

function safeEqualHex(a: string, b: string): boolean {
  try {
    const left = Buffer.from(a, "hex");
    const right = Buffer.from(b, "hex");
    if (left.length !== right.length) return false;
    return timingSafeEqual(left, right);
  } catch {
    return false;
  }
}

/**
 * Verify Telegram Mini App initData via HMAC-SHA256 with BOT_TOKEN.
 * Spec: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 */
export function verifyTelegramInitData(initData: string): VerifiedTelegramInit {
  const botToken = env("BOT_TOKEN");
  if (!botToken) {
    throw new TelegramAuthError("BOT_TOKEN is not configured");
  }
  const trimmed = initData.trim();
  if (!trimmed) throw new TelegramAuthError();

  const params = new URLSearchParams(trimmed);
  const hash = params.get("hash");
  if (!hash) throw new TelegramAuthError();
  params.delete("hash");

  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");

  const secretKey = createHmac("sha256", "WebAppData").update(botToken).digest();
  const computed = createHmac("sha256", secretKey).update(dataCheckString).digest("hex");
  if (!safeEqualHex(computed, hash)) {
    throw new TelegramAuthError();
  }

  const authDateRaw = params.get("auth_date");
  const authDate = authDateRaw ? Number(authDateRaw) : NaN;
  if (!Number.isFinite(authDate)) throw new TelegramAuthError();
  const age = Date.now() / 1000 - authDate;
  if (age > MAX_AUTH_AGE_SECONDS || age < -60) {
    throw new TelegramAuthError("Telegram init data expired");
  }

  const userRaw = params.get("user");
  if (!userRaw) throw new TelegramAuthError("Telegram user missing");
  let parsed: unknown;
  try {
    parsed = JSON.parse(userRaw);
  } catch {
    throw new TelegramAuthError("Telegram user invalid");
  }
  if (!parsed || typeof parsed !== "object" || !("id" in parsed)) {
    throw new TelegramAuthError("Telegram user invalid");
  }
  const rec = parsed as Record<string, unknown>;
  const user: TelegramFrom = {
    id: Number(rec.id),
    first_name: String(rec.first_name ?? ""),
    last_name: typeof rec.last_name === "string" ? rec.last_name : undefined,
    username: typeof rec.username === "string" ? rec.username : undefined,
    language_code: typeof rec.language_code === "string" ? rec.language_code : undefined,
    is_premium: Boolean(rec.is_premium),
  };
  if (!Number.isFinite(user.id)) throw new TelegramAuthError("Telegram user invalid");

  return {
    user,
    authDate,
    queryId: params.get("query_id") ?? undefined,
    startParam: params.get("start_param") ?? undefined,
  };
}

export function readTelegramInitData(request: Request): string | null {
  const header = request.headers.get(TELEGRAM_INIT_DATA_HEADER);
  if (header?.trim()) return header.trim();
  const auth = request.headers.get("authorization");
  if (auth?.toLowerCase().startsWith("tma ")) return auth.slice(4).trim();
  return null;
}
