import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { miniAppButton } from "@/lib/telegram/tma";

export const recordCommand: CommandHandler = async (): Promise<BotReply[]> => {
  return [
    {
      text: "Send me your idea — text or voice.",
      buttons: [[miniAppButton("Record in Mini App", "record")]],
    },
  ];
};
