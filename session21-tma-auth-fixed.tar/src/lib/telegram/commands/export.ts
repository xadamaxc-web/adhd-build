import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";

export type ExportDoc = { filename: string; content: string };

export const exportCommand: CommandHandler = async (ctx): Promise<BotReply[]> => {
  const { isFlagEnabled } = await import("@/lib/adhd/flags");
  if (!(await isFlagEnabled("export"))) {
    return [{ text: "Export is currently disabled." }];
  }
  const { buildExportMarkdown } = await import("@/lib/adhd/export");
  const markdown = await buildExportMarkdown(ctx.user.user_id);
  const day = new Date().toISOString().slice(0, 10);
  const filename = `myadhd-export-${day}.md`;
  return [
    {
      text: `Export ready: ${filename}`,
      // document field consumed by bot.ts
      ...( { document: { filename, content: markdown } } as object ),
    },
  ];
};
