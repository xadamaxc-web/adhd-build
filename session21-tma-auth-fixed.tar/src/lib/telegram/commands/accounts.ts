import { listAccounts } from "@/lib/adhd/accounts";
import { displayProvider, formatCountdown } from "@/lib/adhd/format";
import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { miniAppButton } from "@/lib/telegram/tma";

export const accountsCommand: CommandHandler = async (ctx): Promise<BotReply[]> => {
  const rows = await listAccounts(ctx.user.user_id);
  if (rows.length === 0) {
    return [
      {
        text: "No timers yet. Add one in the Mini App, or /used claude free 3PM",
        buttons: [[miniAppButton("Open timers", "accounts")]],
      },
    ];
  }
  const now = new Date();
  const lines = rows.slice(0, 8).map((a) => {
    const ready = new Date(a.unlocks_at).getTime() <= now.getTime();
    const status = ready ? "ready" : formatCountdown(a.unlocks_at, now);
    return `• ${displayProvider(a.provider)} (${a.label}) — ${status}`;
  });
  return [
    {
      text: ["Your free-tier timers:", "", ...lines].join("\n"),
      buttons: [[miniAppButton("Open timers", "accounts")]],
    },
  ];
};
