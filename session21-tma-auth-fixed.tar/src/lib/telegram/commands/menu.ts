import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { miniAppButton } from "@/lib/telegram/tma";

export const menuCommand: CommandHandler = async (): Promise<BotReply[]> => {
  return [
    {
      text: "Your Mini App is ready.",
      buttons: [[miniAppButton("Open Mini App", "home")]],
    },
  ];
};
