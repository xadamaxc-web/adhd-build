import { countThoughts } from "@/lib/adhd/thoughts";
import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { miniAppButton } from "@/lib/telegram/tma";

export const reviewCommand: CommandHandler = async (ctx): Promise<BotReply[]> => {
  const n = await countThoughts(ctx.user.user_id, "raw");
  return [
    {
      text: [
        "Ready to sort the raw pile?",
        n === 0
          ? "Inbox is empty. Capture something first."
          : `${n} raw ${n === 1 ? "idea" : "ideas"} waiting. Swipe gold or trash.`,
      ].join("\n"),
      buttons: [[miniAppButton("Start Review", "review")]],
    },
  ];
};
