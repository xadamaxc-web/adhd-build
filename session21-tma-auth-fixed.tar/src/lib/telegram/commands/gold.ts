import { countThoughts } from "@/lib/adhd/thoughts";
import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { miniAppButton } from "@/lib/telegram/tma";

export const goldCommand: CommandHandler = async (ctx): Promise<BotReply[]> => {
  const n = await countThoughts(ctx.user.user_id, "gold");
  const noun = n === 1 ? "idea" : "ideas";
  return [
    {
      text:
        n === 0
          ? "Your gold pile is empty. Capture ideas, then swipe them to gold."
          : `You have ${n} gold ${noun}.`,
      buttons: [[miniAppButton("Open gold pile", "gold")]],
    },
  ];
};
