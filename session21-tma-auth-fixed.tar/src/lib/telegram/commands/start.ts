import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { miniAppButton } from "@/lib/telegram/tma";

export const WELCOME = [
  "Welcome to My ADHD.",
  "",
  "Send a thought any time — text or voice.",
  "They stay raw until you sort them. Capture now. Sort later.",
  "",
  "Try /inbox, /gold, /review, /accounts, /used, or /help.",
].join("\n");

export const startCommand: CommandHandler = async (): Promise<BotReply[]> => {
  return [
    {
      text: WELCOME,
      buttons: [
        [
          miniAppButton("Open inbox", "inbox"),
          miniAppButton("Timers", "accounts"),
        ],
      ],
    },
  ];
};
