import { countThoughts } from "@/lib/adhd/thoughts";
import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { miniAppButton } from "@/lib/telegram/tma";

export const inboxCommand: CommandHandler = async (ctx): Promise<BotReply[]> => {
  const n = await countThoughts(ctx.user.user_id, "raw");
  const noun = n === 1 ? "idea" : "ideas";
  return [
    {
      text: n === 0 ? "Your raw inbox is empty." : `You have ${n} raw ${noun}.`,
      buttons: [[miniAppButton("Open inbox", "inbox")]],
    },
  ];
};
