import { getSql } from "@/lib/db";
import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { parseUnlockTime } from "@/lib/telegram/parse-used";

export function parseRemindTime(raw: string, now = new Date()): Date | null {
  const s = raw.trim();
  if (!s) return null;
  const rel = s.match(/^in\s+(\d+)\s*(m|min|mins|h|hr|hrs|d|day|days)$/i);
  if (rel) {
    const n = Number(rel[1]);
    const unit = (rel[2] ?? "h").toLowerCase();
    if (!Number.isFinite(n) || n <= 0) return null;
    const ms = unit.startsWith("m")
      ? n * 60_000
      : unit.startsWith("d")
        ? n * 86_400_000
        : n * 3_600_000;
    return new Date(now.getTime() + ms);
  }
  const tom = s.match(/^tomorrow\s+(.+)$/i);
  if (tom) {
    const base = parseUnlockTime(tom[1]!.trim(), now);
    if (!base) return null;
    const t = new Date(base.getTime());
    const startTomorrow = new Date(now.getTime());
    startTomorrow.setHours(24, 0, 0, 0);
    if (t.getTime() < startTomorrow.getTime()) t.setDate(t.getDate() + 1);
    return t;
  }
  return parseUnlockTime(s, now);
}

export const remindCommand: CommandHandler = async (ctx): Promise<BotReply[]> => {
  const { isFlagEnabled } = await import("@/lib/adhd/flags");
  if (!(await isFlagEnabled("reminders"))) {
    return [{ text: "Reminders are currently disabled." }];
  }
  const parts = ctx.args.trim().split(/\s+/).filter(Boolean);
  if (parts.length < 2) {
    return [{
      text: "Usage: /remind <thought_id> <time>\nExamples: /remind 42 3PM · /remind 42 in 2h · /remind 42 tomorrow 9am",
    }];
  }
  const thoughtId = Number(parts[0]);
  if (!Number.isFinite(thoughtId) || thoughtId <= 0) {
    return [{ text: "thought_id must be a positive number." }];
  }
  const fireAt = parseRemindTime(parts.slice(1).join(" "));
  if (!fireAt) {
    return [{ text: 'Could not parse time. Try "3PM", "in 2h", or "tomorrow 9am".' }];
  }
  const sql = await getSql();
  const thoughts = await sql<{ id: number }>`
    select id from thoughts where id = ${thoughtId} and user_id = ${ctx.user.user_id} limit 1
  `;
  if (!thoughts[0]) return [{ text: "Thought not found (or not yours)." }];
  await sql`
    insert into reminders (user_id, thought_id, fire_at, fired)
    values (${ctx.user.user_id}, ${thoughtId}, ${fireAt.toISOString()}::timestamptz, false)
  `;
  return [{ text: `⏰ Reminder set for ${fireAt.toLocaleString()}` }];
};
