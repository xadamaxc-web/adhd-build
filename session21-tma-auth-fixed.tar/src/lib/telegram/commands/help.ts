import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { miniAppButton } from "@/lib/telegram/tma";

export const helpCommand: CommandHandler = async (): Promise<BotReply[]> => {
  return [
    {
      text: [
        "My ADHD — commands",
        "",
        "Just send text (or voice) to capture a thought.",
        "",
        "/inbox — raw count",
        "/gold — gold pile",
        "/review — start swipe",
        "/record — capture prompt",
        "/used <provider> <label> <time> — start cooldown",
        "  e.g. /used claude free 3PM",
        "/remind <thought_id> <time> — set a reminder",
        "  e.g. /remind 12 in 2h",
        "/export — download gold ideas as markdown",
        "/accounts — open timers",
        "/menu — mini app",
        "/help — this list",
      ].join("\n"),
      buttons: [
        [
          miniAppButton("Open inbox", "inbox"),
          miniAppButton("Timers", "accounts"),
        ],
      ],
    },
  ];
};
