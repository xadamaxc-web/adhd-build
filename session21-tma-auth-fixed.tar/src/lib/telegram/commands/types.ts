import type { BotReply, UserRow, VoicePayload } from "@/lib/adhd/types";

export type CommandContext = {
  user: UserRow;
  text: string;
  args: string;
  raw: string;
  replyToText?: string;
  voice?: VoicePayload;
};

export type CommandHandler = (ctx: CommandContext) => Promise<BotReply[]>;
