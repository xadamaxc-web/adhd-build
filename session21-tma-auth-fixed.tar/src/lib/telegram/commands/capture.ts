import { insertLog } from "@/lib/adhd/logs";
import { insertThought } from "@/lib/adhd/thoughts";
import type { BotReply, UserRow, VoicePayload } from "@/lib/adhd/types";
import { miniAppButton } from "@/lib/telegram/tma";

const INBOX_BUTTONS = [[miniAppButton("Open inbox", "inbox")]];

export async function captureText(user: UserRow, text: string): Promise<BotReply[]> {
  const content = text.trim();
  if (!content) {
    return [{ text: "Send a thought as text or voice." }];
  }
  await insertThought({
    userId: user.user_id,
    content,
    contentType: "text",
  });
  await insertLog("capture", "text thought saved", { user_id: user.user_id });
  return [
    {
      text: "Captured. It is in your raw inbox.",
      buttons: INBOX_BUTTONS,
    },
  ];
}

export async function captureVoice(
  user: UserRow,
  voice: VoicePayload,
): Promise<BotReply[]> {
  const duration =
    typeof voice.durationSec === "number" && voice.durationSec > 0
      ? ` (${voice.durationSec}s)`
      : "";

  let content = `Voice note${duration}`;
  let transcribed = false;

  const fileId = voice.fileId ?? voice.path;
  if (fileId) {
    try {
      const { downloadTelegramFile } = await import("@/lib/telegram/voice-file");
      const { transcribeAudio } = await import("@/lib/services/ai");
      const file = await downloadTelegramFile(fileId);
      if (file) {
        const result = await transcribeAudio(file.buffer, {
          filename: file.path.split("/").pop() ?? "voice.ogg",
          mimeType: file.mimeType,
        });
        if (result.ok && result.text) {
          content = result.text;
          transcribed = true;
        } else {
          content = `Voice note${duration} — (could not transcribe${result.ok ? "" : `: ${result.error}`})`;
        }
      } else {
        content = `Voice note${duration} — (could not download audio)`;
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "error";
      content = `Voice note${duration} — (transcription failed: ${msg})`;
      await insertLog("capture", "voice transcription failed", {
        user_id: user.user_id,
        error: msg,
      });
    }
  }

  await insertThought({
    userId: user.user_id,
    content,
    contentType: "voice",
    voicePath: voice.path,
  });
  await insertLog("capture", transcribed ? "voice transcribed" : "voice saved", {
    user_id: user.user_id,
    path: voice.path,
    transcribed,
  });

  return [
    {
      text: transcribed
        ? `Transcribed and saved:\n“${content.length > 280 ? content.slice(0, 277) + "…" : content}”`
        : "Voice saved to your raw inbox (transcription unavailable).",
      buttons: INBOX_BUTTONS,
    },
  ];
}
