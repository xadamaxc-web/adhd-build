import { upsertAccount } from "@/lib/adhd/accounts";
import { displayProvider } from "@/lib/adhd/format";
import type { BotReply } from "@/lib/adhd/types";
import type { CommandHandler } from "./types";
import { parseUnlockTime, parseUsedArgs } from "@/lib/telegram/parse-used";
import { miniAppButton } from "@/lib/telegram/tma";

export const usedCommand: CommandHandler = async (ctx): Promise<BotReply[]> => {
  const parsed = parseUsedArgs(ctx.args);
  if (!parsed) {
    return [
      {
        text: "Usage: /used <provider> <label> <time>\nExample: /used claude free 3PM",
      },
    ];
  }
  const unlocksAt = parseUnlockTime(parsed.timeRaw);
  if (!unlocksAt) {
    return [{ text: "Could not parse time. Try 3PM, 15:30, or 12AM." }];
  }
  // cooldown from now until unlock
  const hours = Math.max(
    1,
    Math.ceil((unlocksAt.getTime() - Date.now()) / (60 * 60 * 1000)),
  );
  const row = await upsertAccount({
    userId: ctx.user.user_id,
    provider: parsed.provider,
    label: parsed.label,
    unlocksAt,
    cooldownHours: hours,
  });
  return [
    {
      text: `${displayProvider(row.provider)} (${row.label}) locked until ${unlocksAt.toLocaleString()}.`,
      buttons: [[miniAppButton("Open timers", "accounts")]],
    },
  ];
};
