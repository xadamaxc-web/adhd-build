import { env } from "@/lib/env.server";

/**
 * Download a Telegram voice/audio file by file_id.
 * Uses getFile + file download path from the Bot API.
 */
export async function downloadTelegramFile(
  fileId: string,
): Promise<{ buffer: Buffer; path: string; mimeType: string } | null> {
  const token = env("BOT_TOKEN");
  if (!token || !fileId) return null;

  const metaRes = await fetch(
    `https://api.telegram.org/bot${token}/getFile?file_id=${encodeURIComponent(fileId)}`,
  );
  if (!metaRes.ok) return null;
  const meta = (await metaRes.json()) as {
    ok?: boolean;
    result?: { file_path?: string };
  };
  const filePath = meta.result?.file_path;
  if (!meta.ok || !filePath) return null;

  const fileRes = await fetch(
    `https://api.telegram.org/file/bot${token}/${filePath}`,
  );
  if (!fileRes.ok) return null;
  const ab = await fileRes.arrayBuffer();
  const buffer = Buffer.from(ab);

  // Telegram voice messages are typically OGG/Opus
  let mimeType = "audio/ogg";
  if (filePath.endsWith(".mp3")) mimeType = "audio/mpeg";
  else if (filePath.endsWith(".m4a") || filePath.endsWith(".mp4"))
    mimeType = "audio/mp4";
  else if (filePath.endsWith(".wav")) mimeType = "audio/wav";

  return { buffer, path: filePath, mimeType };
}
