import { Telegraf, Markup } from "telegraf";
import type { Update } from "telegraf/types";
import { env } from "@/lib/env.server";
import { insertLog } from "@/lib/adhd/logs";
import { isInQuietHours, upsertTelegramUser } from "@/lib/adhd/users";
import type { BotButton, BotReply, UserRow, VoicePayload } from "@/lib/adhd/types";
import type { CommandHandler } from "@/lib/telegram/commands/types";
import { startCommand, WELCOME } from "@/lib/telegram/commands/start";
import { captureText, captureVoice } from "@/lib/telegram/commands/capture";
import { goldCommand } from "@/lib/telegram/commands/gold";
import { inboxCommand } from "@/lib/telegram/commands/inbox";
import { reviewCommand } from "@/lib/telegram/commands/review";
import { recordCommand } from "@/lib/telegram/commands/record";
import { menuCommand } from "@/lib/telegram/commands/menu";
import { helpCommand } from "@/lib/telegram/commands/help";
import { accountsCommand } from "@/lib/telegram/commands/accounts";
import { usedCommand } from "@/lib/telegram/commands/used";
import { remindCommand } from "@/lib/telegram/commands/remind";
import { exportCommand } from "@/lib/telegram/commands/export";
import { getTmaUrl, tmaHref } from "@/lib/telegram/tma";

const COMMANDS: Record<string, CommandHandler> = {
  start: startCommand,
  help: helpCommand,
  menu: menuCommand,
  record: recordCommand,
  inbox: inboxCommand,
  gold: goldCommand,
  review: reviewCommand,
  accounts: accountsCommand,
  used: usedCommand,
  remind: remindCommand,
  export: exportCommand,
};

type GlobalBot = typeof globalThis & {
  __adhdBot__?: Telegraf;
  __adhdBotToken__?: string;
};

async function replyKeyboard(buttons: BotButton[][] | undefined) {
  if (!buttons?.length) return undefined;
  const base = await getTmaUrl();
  const rows = buttons.map((row) =>
    row.map((b) => {
      if (b.kind === "web_app") {
        return Markup.button.webApp(b.label, tmaHref(base, b.startapp ?? "home"));
      }
      return Markup.button.callback(b.label, b.command ?? "noop");
    }),
  );
  return Markup.inlineKeyboard(rows);
}

async function sendReplies(
  ctx: {
    reply: (text: string, extra?: object) => Promise<unknown>;
    replyWithDocument?: (doc: { source: Buffer; filename: string }, extra?: object) => Promise<unknown>;
  },
  replies: BotReply[],
) {
  for (const r of replies) {
    const extra = await replyKeyboard(r.buttons);
    if (r.document && ctx.replyWithDocument) {
      await ctx.replyWithDocument(
        {
          source: Buffer.from(r.document.content, "utf8"),
          filename: r.document.filename,
        },
        { caption: r.text, ...(extra ?? {}) },
      );
    } else {
      await ctx.reply(r.text, extra);
    }
  }
}

function parseCommand(text: string): { name: string; args: string } | null {
  const m = text.trim().match(/^\/([a-zA-Z0-9_]+)(?:@\w+)?(?:\s+([\s\S]*))?$/);
  if (!m) return null;
  return { name: (m[1] ?? "").toLowerCase(), args: (m[2] ?? "").trim() };
}

async function dispatchText(user: UserRow, text: string): Promise<BotReply[]> {
  if (isInQuietHours(user)) {
    // Still accept captures; only soft-ack
    const cmd = parseCommand(text);
    if (!cmd) {
      const replies = await captureText(user, text);
      return [
        {
          text: `${replies[0]?.text ?? "Captured."}\n(Quiet hours — muted pings.)`,
          buttons: replies[0]?.buttons,
        },
      ];
    }
  }

  const cmd = parseCommand(text);
  if (cmd) {
    const handler = COMMANDS[cmd.name];
    if (handler) {
      return handler({
        user,
        text,
        args: cmd.args,
        raw: text,
      });
    }
    return [{ text: `Unknown command /${cmd.name}. Try /help.` }];
  }

  return captureText(user, text);
}

function createBot(token: string): Telegraf {
  const bot = new Telegraf(token);

  bot.start(async (ctx) => {
    if (!ctx.from) return;
    const user = await upsertTelegramUser(ctx.from);
    await insertLog("bot", "user_start", {
      telegram_id: String(ctx.from.id),
      username: ctx.from.username ?? null,
    });

    const payload = (ctx.startPayload ?? "").trim();
    if (payload.startsWith("idea_")) {
      const parts = payload.split("_");
      // idea_{id}_{token}
      const id = Number(parts[1]);
      const token = parts.slice(2).join("_");
      if (Number.isFinite(id) && token) {
        const { getThoughtByInvite } = await import("@/lib/adhd/thoughts");
        const thought = await getThoughtByInvite(id, token);
        if (thought) {
          await ctx.reply(
            `Shared idea (read-only):\n\n${thought.content.slice(0, 3500)}`,
            Markup.inlineKeyboard([
              Markup.button.callback("Fork to my inbox", `fork:${id}:${token}`),
            ]),
          );
          return;
        }
        await ctx.reply("This invite link is invalid or expired.");
        return;
      }
    }

    const replies = await startCommand({
      user,
      text: "/start",
      args: payload,
      raw: "/start",
    });
    await sendReplies(ctx, replies.length ? replies : [{ text: WELCOME }]);
  });

  bot.action(/^fork:(\d+):(.+)$/, async (ctx) => {
    if (!ctx.from) return;
    const user = await upsertTelegramUser(ctx.from);
    const m = ctx.match;
    const id = Number(m[1]);
    const token = m[2] ?? "";
    try {
      const { getThoughtByInvite, insertThought } = await import("@/lib/adhd/thoughts");
      const { getSql } = await import("@/lib/db");
      const src = await getThoughtByInvite(id, token);
      if (!src) {
        await ctx.answerCbQuery("Invalid invite");
        return;
      }
      const row = await insertThought({
        userId: user.user_id,
        content: src.content,
        contentType: (src.content_type as "text" | "voice") || "text",
        voicePath: src.voice_path,
      });
      const sql = await getSql();
      await sql`
        update thoughts set forked_from = ${src.id}, updated_at = now()
        where id = ${row.id}
      `;
      await ctx.answerCbQuery("Forked");
      await ctx.reply("Copied into your raw inbox.");
    } catch (err) {
      await ctx.answerCbQuery("Failed");
      await insertLog(
        "bot_error",
        err instanceof Error ? err.message : "fork failed",
      );
    }
  });

  bot.on("text", async (ctx) => {
    if (!ctx.from || !ctx.message?.text) return;
    const user = await upsertTelegramUser(ctx.from);
    if (user.is_banned) {
      await ctx.reply("Your account is restricted.");
      return;
    }
    try {
      const replies = await dispatchText(user, ctx.message.text);
      await sendReplies(ctx, replies);
    } catch (err) {
      await insertLog(
        "bot_error",
        err instanceof Error ? err.message : "text handler failed",
        { telegram_id: String(ctx.from.id) },
      );
      await ctx.reply("Something went wrong. Try again or /help.");
    }
  });

  bot.on("voice", async (ctx) => {
    if (!ctx.from || !ctx.message?.voice) return;
    const user = await upsertTelegramUser(ctx.from);
    if (user.is_banned) {
      await ctx.reply("Your account is restricted.");
      return;
    }
    const voice = ctx.message.voice;
    const payload: VoicePayload = {
      fileId: voice.file_id,
      path: voice.file_id,
      durationSec: voice.duration,
    };
    try {
      const replies = await captureVoice(user, payload);
      await sendReplies(ctx, replies);
    } catch (err) {
      await insertLog(
        "bot_error",
        err instanceof Error ? err.message : "voice handler failed",
        { telegram_id: String(ctx.from.id) },
      );
      await ctx.reply("Could not save that voice note.");
    }
  });

  bot.command("help", async (ctx) => {
    if (!ctx.from) return;
    const user = await upsertTelegramUser(ctx.from);
    const replies = await helpCommand({
      user,
      text: "/help",
      args: "",
      raw: "/help",
    });
    await sendReplies(ctx, replies);
  });

  bot.catch(async (err, ctx) => {
    await insertLog("webhook_error", err instanceof Error ? err.message : "bot error", {
      update_id: ctx.update.update_id,
    });
  });

  return bot;
}

async function configureMenuButton(bot: Telegraf): Promise<void> {
  const tma = env("TMA_URL");
  if (!tma) {
    await insertLog("bot", "menu_button skip — TMA_URL missing", {});
    return;
  }
  const url = `${tma.replace(/\/$/, "")}?startapp=record`;
  try {
    await bot.telegram.setChatMenuButton({
      menuButton: {
        type: "web_app",
        text: "Open My ADHD",
        web_app: { url },
      },
    });
    await insertLog("bot", "menu_button set", { url });
  } catch (err) {
    await insertLog(
      "bot",
      "menu_button fail",
      { error: err instanceof Error ? err.message : "error" },
    );
  }
}

export function getBot(): Telegraf | null {
  const token = env("BOT_TOKEN");
  if (!token) return null;
  const g = globalThis as GlobalBot & { __adhdMenuConfigured__?: string };
  if (!g.__adhdBot__ || g.__adhdBotToken__ !== token) {
    g.__adhdBot__ = createBot(token);
    g.__adhdBotToken__ = token;
    g.__adhdMenuConfigured__ = undefined;
  }
  if (g.__adhdMenuConfigured__ !== token) {
    g.__adhdMenuConfigured__ = token;
    void configureMenuButton(g.__adhdBot__);
  }
  return g.__adhdBot__;
}

export async function handleTelegramUpdate(update: unknown): Promise<void> {
  const bot = getBot();
  if (!bot) {
    await insertLog("webhook_error", "BOT_TOKEN missing; update ignored", {
      has_update: Boolean(update),
    });
    return;
  }
  await bot.handleUpdate(update as Update);
}
