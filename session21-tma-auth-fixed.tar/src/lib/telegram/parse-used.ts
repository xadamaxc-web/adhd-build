export type ParsedUsed = {
  provider: string;
  label: string;
  timeRaw: string;
};

/**
 * /used <provider> <label> <time>
 * e.g. /used claude qwr@gmail.com 12AM
 *      /used grok work alt 3:30 PM
 */
export function parseUsedArgs(args: string): ParsedUsed | null {
  const parts = args.trim().split(/\s+/).filter(Boolean);
  if (parts.length < 3) return null;

  let timeRaw = parts[parts.length - 1] ?? "";
  let timeIndex = parts.length - 1;
  if (/^(AM|PM)$/i.test(timeRaw) && parts.length >= 4) {
    timeRaw = `${parts[parts.length - 2]}${timeRaw}`;
    timeIndex = parts.length - 2;
  }

  const provider = (parts[0] ?? "").toLowerCase();
  const label = parts.slice(1, timeIndex).join(" ").trim();
  if (!provider || !label || !timeRaw) return null;
  return { provider, label, timeRaw };
}

/**
 * Convert a clock string into the next occurrence from `now`.
 * "12AM" → next 00:00, "3:30PM" → next 15:30, "14:00" → next 14:00.
 */
export function parseUnlockTime(raw: string, now = new Date()): Date | null {
  const s = raw.trim().toUpperCase().replace(/\s+/g, "");
  if (!s) return null;

  let hour = 0;
  let minute = 0;

  const ampm = s.match(/^(\d{1,2})(?:[:.](\d{2}))?(AM|PM)$/);
  if (ampm) {
    hour = Number(ampm[1]);
    minute = ampm[2] ? Number(ampm[2]) : 0;
    const mer = ampm[3];
    if (!Number.isFinite(hour) || hour < 1 || hour > 12) return null;
    if (!Number.isFinite(minute) || minute > 59) return null;
    if (mer === "AM") {
      if (hour === 12) hour = 0;
    } else if (hour !== 12) {
      hour += 12;
    }
  } else {
    const h24 = s.match(/^(\d{1,2})(?:[:.](\d{2}))?$/);
    if (!h24) return null;
    hour = Number(h24[1]);
    minute = h24[2] ? Number(h24[2]) : 0;
    if (!Number.isFinite(hour) || hour > 23) return null;
    if (!Number.isFinite(minute) || minute > 59) return null;
  }

  const target = new Date(now.getTime());
  target.setMilliseconds(0);
  target.setSeconds(0);
  target.setHours(hour, minute, 0, 0);
  if (target.getTime() <= now.getTime()) {
    target.setDate(target.getDate() + 1);
  }
  return target;
}
