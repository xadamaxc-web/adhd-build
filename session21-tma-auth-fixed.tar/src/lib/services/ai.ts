import { insertLog } from "@/lib/adhd/logs";

export type AIResult =
  | { ok: true; text: string; provider?: string }
  | { ok: false; error: string };

export type TranscribeResult =
  | { ok: true; text: string; language?: string; duration?: number; provider?: string }
  | { ok: false; error: string };

const TIMEOUT_MS = 15_000;

type ChatOpts = {
  system?: string;
  maxTokens?: number;
  temperature?: number;
};

async function fetchWithTimeout(
  url: string,
  init: RequestInit,
  timeoutMs = TIMEOUT_MS,
): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function withRetry(
  label: string,
  fn: () => Promise<AIResult>,
): Promise<AIResult> {
  let last: AIResult = { ok: false, error: "not attempted" };
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      last = await fn();
      if (last.ok) return last;
      await insertLog("ai", `${label} fail attempt ${attempt + 1}`, {
        error: last.error,
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "error";
      last = { ok: false, error: msg };
      await insertLog("ai", `${label} exception attempt ${attempt + 1}`, {
        error: msg,
      });
    }
  }
  return last;
}

function extractOpenAIText(body: unknown): string | null {
  if (!body || typeof body !== "object") return null;
  const choices = (body as { choices?: unknown }).choices;
  if (!Array.isArray(choices) || choices.length === 0) return null;
  const msg = (choices[0] as { message?: { content?: unknown } })?.message;
  const content = msg?.content;
  if (typeof content === "string" && content.trim()) return content.trim();
  return null;
}

function validateChatText(text: string | null): text is string {
  return typeof text === "string" && text.trim().length > 0;
}

async function chatGroq(prompt: string, opts?: ChatOpts): Promise<AIResult> {
  const key = process.env.GROQ_API_KEY;
  if (!key) return { ok: false, error: "GROQ_API_KEY missing" };
  const messages: { role: string; content: string }[] = [];
  if (opts?.system) messages.push({ role: "system", content: opts.system });
  messages.push({ role: "user", content: prompt });
  const res = await fetchWithTimeout(
    "https://api.groq.com/openai/v1/chat/completions",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages,
        max_tokens: opts?.maxTokens ?? 1024,
        temperature: opts?.temperature ?? 0.7,
      }),
    },
  );
  if (!res.ok) return { ok: false, error: `groq ${res.status}` };
  const body = await res.json();
  const text = extractOpenAIText(body);
  if (!validateChatText(text)) return { ok: false, error: "groq invalid response shape" };
  return { ok: true, text, provider: "groq" };
}

async function chatCloudflare(prompt: string, opts?: ChatOpts): Promise<AIResult> {
  const account = process.env.CF_ACCOUNT_ID;
  const token = process.env.CF_API_TOKEN;
  if (!account || !token) return { ok: false, error: "CF_ACCOUNT_ID or CF_API_TOKEN missing" };
  const model = "@cf/meta/llama-3.1-8b-instruct";
  const url = `https://api.cloudflare.com/client/v4/accounts/${account}/ai/run/${model}`;
  const messages: { role: string; content: string }[] = [];
  if (opts?.system) messages.push({ role: "system", content: opts.system });
  messages.push({ role: "user", content: prompt });
  const res = await fetchWithTimeout(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ messages }),
  });
  if (!res.ok) return { ok: false, error: `cloudflare ${res.status}` };
  const body = (await res.json()) as { success?: boolean; result?: { response?: string } };
  const text = body?.result?.response?.trim();
  if (!body.success || !validateChatText(text ?? null)) {
    return { ok: false, error: "cloudflare invalid response shape" };
  }
  return { ok: true, text: text!, provider: "cloudflare" };
}

async function chatGemini(prompt: string, opts?: ChatOpts): Promise<AIResult> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return { ok: false, error: "GEMINI_API_KEY missing" };
  const model = "gemini-2.0-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
  const contents: { role: string; parts: { text: string }[] }[] = [];
  if (opts?.system) {
    contents.push({ role: "user", parts: [{ text: `System: ${opts.system}` }] });
  }
  contents.push({ role: "user", parts: [{ text: prompt }] });
  const res = await fetchWithTimeout(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents,
      generationConfig: {
        maxOutputTokens: opts?.maxTokens ?? 1024,
        temperature: opts?.temperature ?? 0.7,
      },
    }),
  });
  if (!res.ok) return { ok: false, error: `gemini ${res.status}` };
  const body = (await res.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  const text = body.candidates?.[0]?.content?.parts
    ?.map((p) => p.text ?? "")
    .join("")
    .trim();
  if (!validateChatText(text ?? null)) {
    return { ok: false, error: "gemini invalid response shape" };
  }
  return { ok: true, text: text!, provider: "gemini" };
}

const OPENROUTER_FREE_MODELS = [
  "meta-llama/llama-3.3-70b-instruct:free",
  "google/gemma-2-9b-it:free",
  "mistralai/mistral-7b-instruct:free",
  "qwen/qwen-2.5-7b-instruct:free",
];
let openRouterIndex = 0;

async function chatOpenRouter(prompt: string, opts?: ChatOpts): Promise<AIResult> {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) return { ok: false, error: "OPENROUTER_API_KEY missing" };
  const start = openRouterIndex % OPENROUTER_FREE_MODELS.length;
  let lastErr = "openrouter no model";
  for (let i = 0; i < OPENROUTER_FREE_MODELS.length; i++) {
    const model = OPENROUTER_FREE_MODELS[(start + i) % OPENROUTER_FREE_MODELS.length]!;
    const messages: { role: string; content: string }[] = [];
    if (opts?.system) messages.push({ role: "system", content: opts.system });
    messages.push({ role: "user", content: prompt });
    try {
      const res = await fetchWithTimeout("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`,
          "HTTP-Referer": "https://my-adhd.app",
          "X-Title": "My ADHD",
        },
        body: JSON.stringify({
          model,
          messages,
          max_tokens: opts?.maxTokens ?? 1024,
          temperature: opts?.temperature ?? 0.7,
        }),
      });
      if (!res.ok) {
        lastErr = `openrouter ${model} ${res.status}`;
        continue;
      }
      const body = await res.json();
      const text = extractOpenAIText(body);
      if (!validateChatText(text)) {
        lastErr = `openrouter ${model} invalid shape`;
        continue;
      }
      openRouterIndex = (start + i + 1) % OPENROUTER_FREE_MODELS.length;
      return { ok: true, text, provider: "openrouter" };
    } catch (err) {
      lastErr = err instanceof Error ? err.message : "openrouter error";
    }
  }
  return { ok: false, error: lastErr };
}

async function chatXai(prompt: string, opts?: ChatOpts): Promise<AIResult> {
  const key = process.env.XAI_API_KEY;
  if (!key) return { ok: false, error: "XAI_API_KEY missing" };
  const messages: { role: string; content: string }[] = [];
  if (opts?.system) messages.push({ role: "system", content: opts.system });
  messages.push({ role: "user", content: prompt });
  const res = await fetchWithTimeout("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      messages,
      max_tokens: opts?.maxTokens ?? 1024,
      temperature: opts?.temperature ?? 0.7,
    }),
  });
  if (!res.ok) return { ok: false, error: `xai ${res.status}` };
  const body = await res.json();
  const text = extractOpenAIText(body);
  if (!validateChatText(text)) return { ok: false, error: "xai invalid response shape" };
  return { ok: true, text, provider: "xai" };
}

export async function callAI(prompt: string, opts?: ChatOpts): Promise<AIResult> {
  const chain: { name: string; fn: () => Promise<AIResult> }[] = [
    { name: "groq", fn: () => chatGroq(prompt, opts) },
    { name: "cloudflare", fn: () => chatCloudflare(prompt, opts) },
    { name: "gemini", fn: () => chatGemini(prompt, opts) },
    { name: "openrouter", fn: () => chatOpenRouter(prompt, opts) },
    { name: "xai", fn: () => chatXai(prompt, opts) },
  ];
  for (const step of chain) {
    const result = await withRetry(step.name, step.fn);
    if (result.ok) {
      await insertLog("ai", "callAI ok", {
        provider: step.name,
        promptChars: prompt.length,
        outChars: result.text.length,
      });
      return result;
    }
  }
  await insertLog("ai", "callAI all providers failed", { promptChars: prompt.length });
  return { ok: false, error: "All AI providers failed" };
}

export function aiStatus() {
  const ready = Boolean(
    process.env.GROQ_API_KEY ||
      (process.env.CF_ACCOUNT_ID && process.env.CF_API_TOKEN) ||
      process.env.GEMINI_API_KEY ||
      process.env.OPENROUTER_API_KEY ||
      process.env.XAI_API_KEY,
  );
  return {
    stub: !ready,
    providers: ["groq", "cloudflare", "gemini", "openrouter", "xai"] as const,
    ready,
  };
}

export function parseJsonArray(text: string): unknown[] | null {
  const cleaned = text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  try {
    const parsed = JSON.parse(cleaned);
    return Array.isArray(parsed) ? parsed : null;
  } catch {
    const start = cleaned.indexOf("[");
    const end = cleaned.lastIndexOf("]");
    if (start >= 0 && end > start) {
      try {
        const parsed = JSON.parse(cleaned.slice(start, end + 1));
        return Array.isArray(parsed) ? parsed : null;
      } catch {
        return null;
      }
    }
    return null;
  }
}

async function sttGroq(
  audio: Buffer | Uint8Array,
  opts?: { filename?: string; mimeType?: string; language?: string },
): Promise<TranscribeResult> {
  const key = process.env.GROQ_API_KEY;
  if (!key) return { ok: false, error: "GROQ_API_KEY missing" };
  const filename = opts?.filename ?? "voice.ogg";
  const mimeType = opts?.mimeType ?? "audio/ogg";
  const form = new FormData();
  form.append("file", new Blob([audio], { type: mimeType }), filename);
  form.append("model", "whisper-large-v3");
  form.append("response_format", "json");
  if (opts?.language) form.append("language", opts.language);
  const res = await fetchWithTimeout(
    "https://api.groq.com/openai/v1/audio/transcriptions",
    { method: "POST", headers: { Authorization: `Bearer ${key}` }, body: form },
  );
  if (!res.ok) return { ok: false, error: `groq stt ${res.status}` };
  const body = (await res.json()) as { text?: string };
  const text = (body.text ?? "").trim();
  if (!text) return { ok: false, error: "groq stt empty" };
  return { ok: true, text, provider: "groq" };
}

async function sttGemini(
  audio: Buffer | Uint8Array,
  opts?: { filename?: string; mimeType?: string; language?: string },
): Promise<TranscribeResult> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return { ok: false, error: "GEMINI_API_KEY missing" };
  const mimeType = opts?.mimeType ?? "audio/ogg";
  const b64 = Buffer.from(audio).toString("base64");
  const model = "gemini-2.0-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
  const res = await fetchWithTimeout(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [
        {
          role: "user",
          parts: [
            { text: "Transcribe this audio to plain text only. No commentary." },
            { inline_data: { mime_type: mimeType, data: b64 } },
          ],
        },
      ],
    }),
  });
  if (!res.ok) return { ok: false, error: `gemini stt ${res.status}` };
  const body = (await res.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  const text = body.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("").trim();
  if (!text) return { ok: false, error: "gemini stt empty" };
  return { ok: true, text, provider: "gemini" };
}

export async function transcribeAudio(
  audio: Buffer | Uint8Array,
  opts?: { filename?: string; mimeType?: string; language?: string },
): Promise<TranscribeResult> {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const r = await sttGroq(audio, opts);
      if (r.ok) {
        await insertLog("ai", "transcribe ok", { provider: "groq", chars: r.text.length });
        return r;
      }
      await insertLog("ai", `transcribe groq fail attempt ${attempt + 1}`, { error: r.error });
    } catch (err) {
      await insertLog("ai", `transcribe groq exception attempt ${attempt + 1}`, {
        error: err instanceof Error ? err.message : "error",
      });
    }
  }
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const r = await sttGemini(audio, opts);
      if (r.ok) {
        await insertLog("ai", "transcribe ok", { provider: "gemini", chars: r.text.length });
        return r;
      }
      await insertLog("ai", `transcribe gemini fail attempt ${attempt + 1}`, { error: r.error });
    } catch (err) {
      await insertLog("ai", `transcribe gemini exception attempt ${attempt + 1}`, {
        error: err instanceof Error ? err.message : "error",
      });
    }
  }
  await insertLog("ai", "transcribe all providers failed", { bytes: audio.byteLength });
  return { ok: false, error: "Transcription failed" };
}

export type ProviderHealth = "ok" | "fail" | "skip";

export async function probeProviders(): Promise<{
  groq: ProviderHealth;
  cf: ProviderHealth;
  gemini: ProviderHealth;
  openrouter: ProviderHealth;
  xai: ProviderHealth;
}> {
  const probe = async (
    name: string,
    hasCreds: boolean,
    fn: () => Promise<AIResult>,
  ): Promise<ProviderHealth> => {
    if (!hasCreds) return "skip";
    try {
      const r = await withRetry(name, fn);
      return r.ok ? "ok" : "fail";
    } catch {
      return "fail";
    }
  };
  const ping = "Reply with exactly: ok";
  const [groq, cf, gemini, openrouter, xai] = await Promise.all([
    probe("groq", Boolean(process.env.GROQ_API_KEY), () =>
      chatGroq(ping, { maxTokens: 8, temperature: 0 }),
    ),
    probe(
      "cloudflare",
      Boolean(process.env.CF_ACCOUNT_ID && process.env.CF_API_TOKEN),
      () => chatCloudflare(ping, { maxTokens: 8, temperature: 0 }),
    ),
    probe("gemini", Boolean(process.env.GEMINI_API_KEY), () =>
      chatGemini(ping, { maxTokens: 8, temperature: 0 }),
    ),
    probe("openrouter", Boolean(process.env.OPENROUTER_API_KEY), () =>
      chatOpenRouter(ping, { maxTokens: 8, temperature: 0 }),
    ),
    probe("xai", Boolean(process.env.XAI_API_KEY), () =>
      chatXai(ping, { maxTokens: 8, temperature: 0 }),
    ),
  ]);
  return { groq, cf, gemini, openrouter, xai };
}
