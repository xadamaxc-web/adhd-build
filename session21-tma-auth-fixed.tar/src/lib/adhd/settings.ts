import { getSql } from "@/lib/db";

export async function getSetting(key: string): Promise<string> {
  const sql = await getSql();
  const rows = await sql<{ value: string }>`
    select value from settings where key = ${key} limit 1
  `;
  return rows[0]?.value ?? "";
}
