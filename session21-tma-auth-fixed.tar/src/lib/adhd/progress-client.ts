import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type { ProgressLogRow } from "./progress";
import type { UserRow } from "./types";

export const addProgress = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<ProgressLogRow> => {
    const { insertProgress, setThoughtNextStep } = await import("./progress");
    const body = data as {
      thoughtId: number;
      content: string;
      context?: string;
      nextStep?: string;
    };
    if (!body?.thoughtId || !body?.content?.trim()) {
      throw new Error("thoughtId and content required");
    }
    const row = await insertProgress({
      userId: context.userId,
      thoughtId: body.thoughtId,
      content: body.content.trim(),
      context: body.context ?? null,
    });
    if (body.nextStep != null) {
      await setThoughtNextStep(
        context.userId,
        body.thoughtId,
        body.nextStep.trim() || null,
      );
    }
    return row;
  });

export const listMyProgress = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<ProgressLogRow[]> => {
    const { listProgress } = await import("./progress");
    const thoughtId = (data as { thoughtId?: number } | undefined)?.thoughtId;
    return listProgress(context.userId, thoughtId);
  });

export const saveQuietHours = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<UserRow> => {
    const { updateQuietHours } = await import("./users");
    const body = data as { start?: string | null; end?: string | null };
    const start = body?.start?.trim() || null;
    const end = body?.end?.trim() || null;
    return updateQuietHours(context.userId, start, end);
  });
