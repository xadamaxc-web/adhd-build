import { getSql } from "@/lib/db";

export async function isFlagEnabled(key: string): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ enabled: boolean }>`
    select enabled from feature_flags where key = ${key} limit 1
  `;
  if (!rows[0]) return true; // default on if missing
  return Boolean(rows[0].enabled);
}
