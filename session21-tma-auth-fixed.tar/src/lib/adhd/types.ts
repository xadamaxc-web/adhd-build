export type UserRow = {
  id: number;
  user_id: string;
  telegram_id: string | null;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  language_code: string | null;
  is_premium: boolean;
  is_banned: boolean;
  quiet_hours_start: string | null;
  quiet_hours_end: string | null;
  last_active_at: string | null;
  created_at: string;
  updated_at: string;
};

export type ThoughtRow = {
  id: number;
  user_id: string;
  content: string;
  content_type: string;
  voice_path: string | null;
  status: string;
  next_step: string | null;
  invite_token: string | null;
  invited_username: string | null;
  forked_from: number | null;
  created_at: string;
  updated_at: string;
};

export type AccountRow = {
  id: number;
  user_id: string;
  provider: string;
  label: string;
  unlocks_at: string;
  cooldown_hours: number;
  notified: number;
  created_at: string;
  updated_at: string;
};

export type TelegramFrom = {
  id: number;
  is_bot?: boolean;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
};

export type BotButton = {
  label: string;
  kind: "web_app" | "command";
  startapp?: string;
  command?: string;
};

export type BotReply = {
  text: string;
  buttons?: BotButton[][];
  document?: { filename: string; content: string };
};

export type VoicePayload = {
  fileId?: string;
  path: string;
  durationSec?: number;
};

export type HealthPayload = {
  ok: boolean;
  service: string;
  time: string;
  db: {
    ok: boolean;
    source: "neon" | "pglite";
  };
  auth: {
    enabled: boolean;
  };
  telegram: {
    botConfigured: boolean;
    webhook: "ready";
  };
  ai: {
    stub: boolean;
    ready: boolean;
  };
};
