import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type { UserRow } from "./types";

export const getMe = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<UserRow> => {
    const { getSql } = await import("@/lib/db");
    const { upsertSessionUser, linkTelegramToUser } = await import("@/lib/adhd/users");
    const { UnauthorizedError } = await import("@/lib/auth/verify.server");
    const { getRequest } = await import("@tanstack/react-start/server");
    const { readTelegramInitData, TelegramAuthError, verifyTelegramInitData } =
      await import("@/lib/telegram/auth");

    const request = getRequest();
    const initData = request ? readTelegramInitData(request) : null;
    if (initData) {
      try {
        const verified = verifyTelegramInitData(initData);
        await upsertSessionUser({ userId: context.userId });
        return linkTelegramToUser(context.userId, verified.user);
      } catch (err) {
        if (err instanceof TelegramAuthError) throw new UnauthorizedError();
        throw err;
      }
    }

    const sql = await getSql();
    const authRows = await sql<{ name: string; email: string }>`
      select name, email from "user" where id = ${context.userId} limit 1
    `;
    const authUser = authRows[0];
    let firstName: string | null = null;
    let lastName: string | null = null;
    const name = authUser?.name?.trim() ?? "";
    if (name) {
      const [first, ...rest] = name.split(/\s+/);
      firstName = first ?? null;
      lastName = rest.length ? rest.join(" ") : null;
    }
    const username = authUser?.email?.split("@")[0] ?? null;

    return upsertSessionUser({
      userId: context.userId,
      firstName,
      lastName,
      username,
    });
  });
