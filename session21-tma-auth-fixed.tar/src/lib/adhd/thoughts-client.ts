import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type { ThoughtRow } from "./types";

export const listMyThoughts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<ThoughtRow[]> => {
    const { listThoughts } = await import("./thoughts");
    const status = (data as { status?: string } | undefined)?.status;
    return listThoughts(context.userId, status);
  });

export const captureThought = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<ThoughtRow> => {
    const { insertThought } = await import("./thoughts");
    const { insertLog } = await import("./logs");
    const body = data as { content: string };
    const content = (body?.content ?? "").trim();
    if (!content) throw new Error("Empty thought");
    const row = await insertThought({
      userId: context.userId,
      content,
      contentType: "text",
    });
    await insertLog("capture", "web text thought saved", { user_id: context.userId });
    return row;
  });

export const setThoughtStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<ThoughtRow | null> => {
    const { updateThoughtStatus } = await import("./thoughts");
    const body = data as { id: number; status: "raw" | "gold" | "trash" };
    if (!body?.id || !body?.status) throw new Error("id and status required");
    return updateThoughtStatus(context.userId, body.id, body.status);
  });

export const captureVoiceThought = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(
    async ({
      context,
      data,
    }): Promise<
      | { ok: true; thought: ThoughtRow; transcribed: boolean }
      | { ok: false; error: string }
    > => {
      const body = data as {
        audioBase64: string;
        mimeType?: string;
        durationSec?: number;
      };
      if (!body?.audioBase64) {
        return { ok: false, error: "audioBase64 required" };
      }

      const { insertThought } = await import("./thoughts");
      const { insertLog } = await import("./logs");
      const { transcribeAudio } = await import("@/lib/services/ai");

      let binary: Buffer;
      try {
        binary = Buffer.from(body.audioBase64, "base64");
      } catch {
        return { ok: false, error: "Invalid base64 audio" };
      }
      if (binary.byteLength < 100) {
        return { ok: false, error: "Audio too short" };
      }
      if (binary.byteLength > 15 * 1024 * 1024) {
        return { ok: false, error: "Audio too large (max 15MB)" };
      }

      const mimeType = body.mimeType ?? "audio/webm";
      const ext = mimeType.includes("ogg")
        ? "ogg"
        : mimeType.includes("mp4") || mimeType.includes("m4a")
          ? "m4a"
          : mimeType.includes("wav")
            ? "wav"
            : "webm";

      const result = await transcribeAudio(binary, {
        filename: `web-voice.${ext}`,
        mimeType,
      });

      const duration =
        typeof body.durationSec === "number" && body.durationSec > 0
          ? ` (${Math.round(body.durationSec)}s)`
          : "";

      let content: string;
      let transcribed = false;
      if (result.ok && result.text) {
        content = result.text;
        transcribed = true;
      } else {
        content = `Voice note${duration} — (could not transcribe${result.ok ? "" : `: ${result.error}`})`;
      }

      const row = await insertThought({
        userId: context.userId,
        content,
        contentType: "voice",
        voicePath: `web:${Date.now()}.${ext}`,
      });
      await insertLog("capture", transcribed ? "web voice transcribed" : "web voice saved", {
        user_id: context.userId,
        transcribed,
        bytes: binary.byteLength,
      });

      return { ok: true, thought: row, transcribed };
    },
  );

export const setThoughtNextStepFn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: boolean }> => {
    const { setThoughtNextStep } = await import("./progress");
    const body = data as { id: number; nextStep: string | null };
    if (!body?.id) throw new Error("id required");
    await setThoughtNextStep(context.userId, body.id, body.nextStep);
    return { ok: true };
  });

export const exportMarkdown = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<{ markdown: string; filename: string }> => {
    const { isFlagEnabled } = await import("./flags");
    if (!(await isFlagEnabled("export"))) {
      throw new Error("Export is disabled");
    }
    const { buildExportMarkdown } = await import("./export");
    const markdown = await buildExportMarkdown(context.userId);
    const day = new Date().toISOString().slice(0, 10);
    return { markdown, filename: `myadhd-export-${day}.md` };
  });

export const inviteCollaborator = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(
    async ({
      context,
      data,
    }): Promise<{ ok: true; link: string } | { ok: false; error: string }> => {
      const { isFlagEnabled } = await import("./flags");
      if (!(await isFlagEnabled("collaborator_invite"))) {
        return { ok: false, error: "Invites disabled" };
      }
      const body = data as { thoughtId: number; username: string };
      if (!body?.thoughtId || !body?.username?.trim()) {
        return { ok: false, error: "thoughtId and username required" };
      }
      const { randomBytes } = await import("node:crypto");
      const token = randomBytes(16).toString("hex");
      const { setInvite } = await import("./thoughts");
      const row = await setInvite(
        context.userId,
        body.thoughtId,
        token,
        body.username.trim().replace(/^@/, ""),
      );
      if (!row) return { ok: false, error: "Thought not found" };
      const { env } = await import("@/lib/env.server");
      const botUser = env("BOT_USERNAME") || "MyADHDBot";
      const link = `https://t.me/${botUser}?start=idea_${row.id}_${token}`;
      return { ok: true, link };
    },
  );

export const forkInvitedThought = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(
    async ({
      context,
      data,
    }): Promise<{ ok: true; id: number } | { ok: false; error: string }> => {
      const body = data as { thoughtId: number; token: string };
      if (!body?.thoughtId || !body?.token) {
        return { ok: false, error: "thoughtId and token required" };
      }
      const { getThoughtByInvite, insertThought } = await import("./thoughts");
      const { getSql } = await import("@/lib/db");
      const src = await getThoughtByInvite(body.thoughtId, body.token);
      if (!src) return { ok: false, error: "Invalid invite" };
      const row = await insertThought({
        userId: context.userId,
        content: src.content,
        contentType: (src.content_type as "text" | "voice") || "text",
        voicePath: src.voice_path,
      });
      const sql = await getSql();
      await sql`
        update thoughts set forked_from = ${src.id}, updated_at = now()
        where id = ${row.id}
      `;
      return { ok: true, id: row.id };
    },
  );

export const mergeThoughts = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(
    async ({
      context,
      data,
    }): Promise<
      | { ok: true; id: number; content: string }
      | { ok: false; error: string }
    > => {
      const { isFlagEnabled } = await import("./flags");
      if (!(await isFlagEnabled("idea_merge"))) {
        return { ok: false, error: "Merge is disabled" };
      }
      const body = data as { idA: number; idB: number };
      if (!body?.idA || !body?.idB || body.idA === body.idB) {
        return { ok: false, error: "Two distinct thought ids required" };
      }
      const { getThoughtById, insertThought, updateThoughtStatus } = await import(
        "./thoughts"
      );
      const a = await getThoughtById(context.userId, body.idA);
      const b = await getThoughtById(context.userId, body.idB);
      if (!a || !b) return { ok: false, error: "Thought not found" };
      if (a.status !== "raw" || b.status !== "raw") {
        return { ok: false, error: "Only raw thoughts can be merged" };
      }

      const { callAI } = await import("@/lib/services/ai");
      const result = await callAI(
        `Merge these two ideas into one coherent gold-quality idea. Return ONLY JSON: { "title": string, "content": string }\n\nIdea A:\n${a.content}\n\nIdea B:\n${b.content}`,
        {
          system: "You merge ADHD idea capture notes. Reply with valid JSON only.",
          maxTokens: 800,
          temperature: 0.5,
        },
      );
      if (!result.ok) return { ok: false, error: result.error };

      let title = "";
      let content = result.text;
      try {
        const cleaned = result.text
          .replace(/^```(?:json)?\s*/i, "")
          .replace(/\s*```$/i, "")
          .trim();
        const start = cleaned.indexOf("{");
        const end = cleaned.lastIndexOf("}");
        const parsed = JSON.parse(
          start >= 0 && end > start ? cleaned.slice(start, end + 1) : cleaned,
        ) as { title?: string; content?: string };
        title = (parsed.title ?? "").trim();
        content = (parsed.content ?? content).trim();
      } catch {
        /* use raw text */
      }
      const merged = title ? `${title}\n\n${content}` : content;
      const row = await insertThought({
        userId: context.userId,
        content: merged,
        contentType: "text",
      });
      await updateThoughtStatus(context.userId, row.id, "gold");
      await updateThoughtStatus(context.userId, body.idA, "trash");
      await updateThoughtStatus(context.userId, body.idB, "trash");
      return { ok: true, id: row.id, content: merged };
    },
  );
