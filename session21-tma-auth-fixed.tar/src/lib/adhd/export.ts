import { getSql } from "@/lib/db";

export async function buildExportMarkdown(userId: string): Promise<string> {
  const sql = await getSql();
  const gold = await sql<{
    id: number;
    content: string;
    next_step: string | null;
    created_at: string;
  }>`
    select id, content, next_step, created_at::text as created_at
    from thoughts
    where user_id = ${userId} and status = 'gold'
    order by created_at desc
  `;

  const lines: string[] = [
    "# My ADHD export",
    "",
    `Generated: ${new Date().toISOString()}`,
    "",
  ];

  for (const t of gold) {
    lines.push(`## Idea #${t.id}`);
    lines.push("");
    lines.push(t.content);
    lines.push("");
    if (t.next_step) {
      lines.push(`**Next step:** ${t.next_step}`);
      lines.push("");
    }
    lines.push(`_Captured: ${t.created_at}_`);
    lines.push("");

    const plans = await sql<{
      general_prompt: string | null;
      sessions_json: string;
      created_at: string;
    }>`
      select general_prompt, sessions_json, created_at::text as created_at
      from idea_plans
      where user_id = ${userId} and thought_id = ${t.id}
      order by created_at desc
    `;
    for (const p of plans) {
      lines.push("### Plan");
      if (p.general_prompt) {
        lines.push("");
        lines.push(p.general_prompt);
      }
      lines.push("");
      try {
        const sessions = JSON.parse(p.sessions_json) as unknown;
        if (Array.isArray(sessions)) {
          sessions.forEach((s, i) => {
            if (typeof s === "string") {
              lines.push(`${i + 1}. ${s}`);
            } else if (s && typeof s === "object" && "prompt" in s) {
              const o = s as { index?: number; provider?: string; prompt: string };
              lines.push(
                `${o.index ?? i + 1}. [${o.provider ?? "ai"}] ${o.prompt}`,
              );
            }
          });
        }
      } catch {
        lines.push(p.sessions_json);
      }
      lines.push("");
    }

    const logs = await sql<{ content: string; created_at: string }>`
      select content, created_at::text as created_at
      from progress_logs
      where user_id = ${userId} and thought_id = ${t.id}
      order by created_at desc
    `;
    if (logs.length) {
      lines.push("### Progress");
      lines.push("");
      for (const l of logs) {
        lines.push(`- (${l.created_at}) ${l.content}`);
      }
      lines.push("");
    }
    lines.push("---");
    lines.push("");
  }

  if (gold.length === 0) {
    lines.push("_No gold ideas yet._");
    lines.push("");
  }

  return lines.join("\n");
}
