import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type { AdminStats, FlagRow, LogRow } from "./admin";
import type { UserRow } from "./types";

async function requireAdmin(userId: string) {
  const { isUserAdmin } = await import("./admin");
  if (!(await isUserAdmin(userId))) {
    throw new Error("Forbidden");
  }
}

export const getAdminOverview = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(
    async ({
      context,
    }): Promise<{ stats: AdminStats; isAdmin: boolean }> => {
      const { isUserAdmin, getAdminStats } = await import("./admin");
      const isAdmin = await isUserAdmin(context.userId);
      if (!isAdmin) return { stats: {
        users: 0, thoughts: 0, gold: 0, raw: 0, accounts: 0, logs24h: 0,
      }, isAdmin: false };
      return { stats: await getAdminStats(), isAdmin: true };
    },
  );

export const getAdminUsers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<UserRow[]> => {
    await requireAdmin(context.userId);
    const { listUsers } = await import("./admin");
    return listUsers();
  });

export const banUser = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: boolean }> => {
    await requireAdmin(context.userId);
    const { setUserBanned } = await import("./admin");
    const body = data as { userId: string; banned: boolean };
    const ok = await setUserBanned(context.userId, body.userId, body.banned);
    return { ok };
  });

export const getAdminLogs = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<LogRow[]> => {
    await requireAdmin(context.userId);
    const { listLogs } = await import("./admin");
    const type = (data as { type?: string } | undefined)?.type;
    return listLogs(80, type);
  });

export const getAdminFlags = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<FlagRow[]> => {
    await requireAdmin(context.userId);
    const { listFlags } = await import("./admin");
    return listFlags();
  });

export const toggleFlag = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: boolean }> => {
    await requireAdmin(context.userId);
    const { setFlag } = await import("./admin");
    const body = data as { key: string; enabled: boolean };
    const ok = await setFlag(context.userId, body.key, body.enabled);
    return { ok };
  });

export const getAdminSettings = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const { listSettings, listTriggers } = await import("./admin");
    const [settings, triggers] = await Promise.all([
      listSettings(),
      listTriggers(),
    ]);
    return { settings, triggers };
  });

export const saveAdminSetting = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: boolean }> => {
    await requireAdmin(context.userId);
    const { setSetting } = await import("./admin");
    const body = data as { key: string; value: string };
    const ok = await setSetting(context.userId, body.key, body.value ?? "");
    return { ok };
  });

export const toggleTrigger = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ ok: boolean }> => {
    await requireAdmin(context.userId);
    const { setTriggerEnabled } = await import("./admin");
    const body = data as { key: string; enabled: boolean };
    const ok = await setTriggerEnabled(context.userId, body.key, body.enabled);
    return { ok };
  });

export const cleanLogs = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<{ deleted: number }> => {
    await requireAdmin(context.userId);
    const { cleanOldLogs } = await import("./admin");
    const days = (data as { days?: number } | undefined)?.days ?? 14;
    const deleted = await cleanOldLogs(context.userId, days);
    return { deleted };
  });

export const sendBroadcast = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(
    async ({
      context,
      data,
    }): Promise<{ ok: true; sent: number; failed: number } | { ok: false; error: string }> => {
      await requireAdmin(context.userId);
      const body = data as { message: string };
      const message = (body?.message ?? "").trim();
      if (!message) return { ok: false, error: "Message required" };
      if (message.length > 3500) return { ok: false, error: "Message too long" };

      const { listBroadcastTargets, recordBroadcastLog } = await import("./admin");
      const { getBot } = await import("@/lib/telegram/bot");
      const bot = getBot();
      if (!bot) return { ok: false, error: "BOT_TOKEN not configured" };

      const targets = await listBroadcastTargets();
      let sent = 0;
      let failed = 0;
      for (const tgId of targets) {
        try {
          await bot.telegram.sendMessage(tgId, message);
          sent += 1;
        } catch {
          failed += 1;
        }
      }
      await recordBroadcastLog(context.userId, message, sent, failed);
      return { ok: true, sent, failed };
    },
  );

export const getAdminHealthDetail = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const { buildHealth } = await import("./health.server");
    const health = await buildHealth();
    const { env } = await import("@/lib/env.server");
    return {
      health,
      env: {
        botToken: Boolean(env("BOT_TOKEN")),
        xaiKey: Boolean(process.env.XAI_API_KEY),
        ownerTelegram: Boolean(env("OWNER_TELEGRAM_ID")),
        tmaUrl: Boolean(env("TMA_URL")),
      },
    };
  });
