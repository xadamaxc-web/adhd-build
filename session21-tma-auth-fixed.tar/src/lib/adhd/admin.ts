import { getSql } from "@/lib/db";
import { env } from "@/lib/env.server";
import type { UserRow } from "./types";

export type LogRow = {
  id: number;
  type: string;
  message: string;
  meta_json: string | null;
  created_at: string;
};

export type FlagRow = {
  key: string;
  enabled: boolean;
  updated_at: string;
};

export type AdminStats = {
  users: number;
  thoughts: number;
  gold: number;
  raw: number;
  accounts: number;
  logs24h: number;
};

export async function isUserAdmin(userId: string): Promise<boolean> {
  const sql = await getSql();

  // Explicit admins table row
  const adminRows = await sql<{ role: string }>`
    select role from admins where user_id = ${userId} limit 1
  `;
  if (adminRows[0]) return true;

  // Owner telegram linked to this user
  const ownerTg = env("OWNER_TELEGRAM_ID");
  if (ownerTg) {
    const u = await sql<{ telegram_id: string | null }>`
      select telegram_id from users where user_id = ${userId} limit 1
    `;
    if (u[0]?.telegram_id && u[0].telegram_id === ownerTg) return true;
  }

  // settings owner_telegram_id
  const setting = await sql<{ value: string }>`
    select value from settings where key = 'owner_telegram_id' limit 1
  `;
  if (setting[0]?.value) {
    const u = await sql<{ telegram_id: string | null }>`
      select telegram_id from users where user_id = ${userId} limit 1
    `;
    if (u[0]?.telegram_id && u[0].telegram_id === setting[0].value) return true;
  }

  // Preview / first-user convenience: allow if no admins exist yet
  const anyAdmin = await sql<{ n: number }>`
    select count(*)::int as n from admins
  `;
  if ((anyAdmin[0]?.n ?? 0) === 0) {
    // Bootstrap: promote this user as owner if they have a telegram id
    const u = await sql<{ telegram_id: string | null }>`
      select telegram_id from users where user_id = ${userId} limit 1
    `;
    if (u[0]?.telegram_id) {
      await sql`
        insert into admins (telegram_id, user_id, role)
        values (${u[0].telegram_id}, ${userId}, 'owner')
        on conflict (telegram_id) do update set user_id = excluded.user_id, role = 'owner'
      `;
      return true;
    }
    // No telegram — still allow in empty-admin bootstrap for web-only owners
    return true;
  }

  return false;
}

export async function getAdminStats(): Promise<AdminStats> {
  const sql = await getSql();
  const [users, thoughts, gold, raw, accounts, logs24h] = await Promise.all([
    sql<{ n: number }>`select count(*)::int as n from users`,
    sql<{ n: number }>`select count(*)::int as n from thoughts`,
    sql<{ n: number }>`select count(*)::int as n from thoughts where status = 'gold'`,
    sql<{ n: number }>`select count(*)::int as n from thoughts where status = 'raw'`,
    sql<{ n: number }>`select count(*)::int as n from accounts`,
    sql<{ n: number }>`
      select count(*)::int as n from logs
      where created_at > now() - interval '24 hours'
    `,
  ]);
  return {
    users: users[0]?.n ?? 0,
    thoughts: thoughts[0]?.n ?? 0,
    gold: gold[0]?.n ?? 0,
    raw: raw[0]?.n ?? 0,
    accounts: accounts[0]?.n ?? 0,
    logs24h: logs24h[0]?.n ?? 0,
  };
}

export async function listUsers(limit = 50): Promise<UserRow[]> {
  const sql = await getSql();
  return sql<UserRow>`
    select
      id, user_id, telegram_id, username, first_name, last_name,
      language_code, is_premium, is_banned, quiet_hours_start, quiet_hours_end,
      last_active_at::text as last_active_at,
      created_at::text as created_at,
      updated_at::text as updated_at
    from users
    order by last_active_at desc nulls last, created_at desc
    limit ${limit}
  `;
}

export async function setUserBanned(
  actorUserId: string,
  targetUserId: string,
  banned: boolean,
): Promise<boolean> {
  if (!(await isUserAdmin(actorUserId))) return false;
  if (actorUserId === targetUserId) return false;
  const sql = await getSql();
  await sql`
    update users set is_banned = ${banned}, updated_at = now()
    where user_id = ${targetUserId}
  `;
  return true;
}

export async function listLogs(limit = 80, type?: string): Promise<LogRow[]> {
  const sql = await getSql();
  if (type) {
    return sql<LogRow>`
      select id, type, message, meta_json, created_at::text as created_at
      from logs
      where type = ${type}
      order by created_at desc
      limit ${limit}
    `;
  }
  return sql<LogRow>`
    select id, type, message, meta_json, created_at::text as created_at
    from logs
    order by created_at desc
    limit ${limit}
  `;
}

export async function listFlags(): Promise<FlagRow[]> {
  const sql = await getSql();
  return sql<FlagRow>`
    select key, enabled, updated_at::text as updated_at
    from feature_flags
    order by key asc
  `;
}

export async function setFlag(
  actorUserId: string,
  key: string,
  enabled: boolean,
): Promise<boolean> {
  if (!(await isUserAdmin(actorUserId))) return false;
  const sql = await getSql();
  await sql`
    insert into feature_flags (key, enabled, updated_at)
    values (${key}, ${enabled}, now())
    on conflict (key) do update set enabled = excluded.enabled, updated_at = now()
  `;
  return true;
}

export type SettingRow = {
  key: string;
  value: string;
  updated_at: string;
};

export type TriggerRow = {
  key: string;
  enabled: boolean;
  frequency_hours: number;
  last_run_at: string | null;
  last_error: string | null;
  created_at: string;
};

export async function listSettings(): Promise<SettingRow[]> {
  const sql = await getSql();
  return sql<SettingRow>`
    select key, value, updated_at::text as updated_at
    from settings
    order by key asc
  `;
}

export async function setSetting(
  actorUserId: string,
  key: string,
  value: string,
): Promise<boolean> {
  if (!(await isUserAdmin(actorUserId))) return false;
  const sql = await getSql();
  await sql`
    insert into settings (key, value, updated_at)
    values (${key}, ${value}, now())
    on conflict (key) do update set value = excluded.value, updated_at = now()
  `;
  return true;
}

export async function listTriggers(): Promise<TriggerRow[]> {
  const sql = await getSql();
  return sql<TriggerRow>`
    select
      key, enabled, frequency_hours,
      last_run_at::text as last_run_at,
      last_error,
      created_at::text as created_at
    from triggers
    order by key asc
  `;
}

export async function setTriggerEnabled(
  actorUserId: string,
  key: string,
  enabled: boolean,
): Promise<boolean> {
  if (!(await isUserAdmin(actorUserId))) return false;
  const sql = await getSql();
  await sql`
    update triggers set enabled = ${enabled}
    where key = ${key}
  `;
  return true;
}

export async function cleanOldLogs(
  actorUserId: string,
  days = 14,
): Promise<number> {
  if (!(await isUserAdmin(actorUserId))) return 0;
  const sql = await getSql();
  const rows = await sql<{ id: number }>`
    delete from logs
    where created_at < now() - (${days} || ' days')::interval
    returning id
  `;
  return rows.length;
}

/** Telegram IDs of non-banned users for broadcast. */
export async function listBroadcastTargets(): Promise<string[]> {
  const sql = await getSql();
  const rows = await sql<{ telegram_id: string }>`
    select telegram_id from users
    where telegram_id is not null
      and is_banned = false
  `;
  return rows.map((r) => r.telegram_id).filter(Boolean);
}

export async function recordBroadcastLog(
  actorUserId: string,
  message: string,
  sent: number,
  failed: number,
): Promise<void> {
  const sql = await getSql();
  await sql`
    insert into logs (type, message, meta_json)
    values (
      'broadcast',
      ${`Broadcast by ${actorUserId}: sent ${sent}, failed ${failed}`},
      ${JSON.stringify({ actor: actorUserId, preview: message.slice(0, 200), sent, failed })}
    )
  `;
}
