import { getSql } from "@/lib/db";

export type IdeaPlayRow = {
  id: number;
  thought_id: number;
  user_id: string;
  questions_json: string;
  answers_json: string | null;
  generated_prompt: string | null;
  created_at: string;
};

export type IdeaPlanRow = {
  id: number;
  thought_id: number;
  user_id: string;
  general_prompt: string | null;
  sessions_json: string;
  created_at: string;
};

export async function insertPlay(input: {
  userId: string;
  thoughtId: number;
  questions: string[];
}): Promise<IdeaPlayRow> {
  const sql = await getSql();
  const rows = await sql<IdeaPlayRow>`
    insert into idea_plays (thought_id, user_id, questions_json)
    values (
      ${input.thoughtId},
      ${input.userId},
      ${JSON.stringify(input.questions)}
    )
    returning
      id, thought_id, user_id, questions_json, answers_json, generated_prompt,
      created_at::text as created_at
  `;
  const row = rows[0];
  if (!row) throw new Error("Failed to save play");
  return row;
}

export async function completePlay(input: {
  userId: string;
  playId: number;
  answers: string[];
  generatedPrompt: string;
}): Promise<IdeaPlayRow | null> {
  const sql = await getSql();
  const rows = await sql<IdeaPlayRow>`
    update idea_plays set
      answers_json = ${JSON.stringify(input.answers)},
      generated_prompt = ${input.generatedPrompt}
    where id = ${input.playId} and user_id = ${input.userId}
    returning
      id, thought_id, user_id, questions_json, answers_json, generated_prompt,
      created_at::text as created_at
  `;
  return rows[0] ?? null;
}

export async function insertPlan(input: {
  userId: string;
  thoughtId: number;
  generalPrompt: string;
  sessions: string[];
}): Promise<IdeaPlanRow> {
  const sql = await getSql();
  const rows = await sql<IdeaPlanRow>`
    insert into idea_plans (thought_id, user_id, general_prompt, sessions_json)
    values (
      ${input.thoughtId},
      ${input.userId},
      ${input.generalPrompt},
      ${JSON.stringify(input.sessions)}
    )
    returning
      id, thought_id, user_id, general_prompt, sessions_json,
      created_at::text as created_at
  `;
  const row = rows[0];
  if (!row) throw new Error("Failed to save plan");
  return row;
}

export async function listPlansForUser(userId: string): Promise<IdeaPlanRow[]> {
  const sql = await getSql();
  return sql<IdeaPlanRow>`
    select
      id, thought_id, user_id, general_prompt, sessions_json,
      created_at::text as created_at
    from idea_plans
    where user_id = ${userId}
    order by created_at desc
    limit 20
  `;
}

export async function getLatestPlayForThought(
  userId: string,
  thoughtId: number,
): Promise<IdeaPlayRow | null> {
  const sql = await getSql();
  const rows = await sql<IdeaPlayRow>`
    select
      id, thought_id, user_id, questions_json, answers_json, generated_prompt,
      created_at::text as created_at
    from idea_plays
    where user_id = ${userId} and thought_id = ${thoughtId}
    order by created_at desc
    limit 1
  `;
  return rows[0] ?? null;
}
