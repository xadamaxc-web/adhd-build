import { getSql } from "@/lib/db";
import type { ThoughtRow } from "./types";

const RETURNING = `
  id, user_id, content, content_type, voice_path, status, next_step,
  invite_token, invited_username, forked_from,
  created_at::text as created_at,
  updated_at::text as updated_at
`;

export async function insertThought(input: {
  userId: string;
  content: string;
  contentType: "text" | "voice";
  voicePath?: string | null;
}): Promise<ThoughtRow> {
  const sql = await getSql();
  const rows = await sql<ThoughtRow>`
    insert into thoughts (user_id, content, content_type, voice_path, status, updated_at)
    values (
      ${input.userId},
      ${input.content},
      ${input.contentType},
      ${input.voicePath ?? null},
      'raw',
      now()
    )
    returning
      id, user_id, content, content_type, voice_path, status, next_step,
      invite_token, invited_username, forked_from,
      created_at::text as created_at,
      updated_at::text as updated_at
  `;
  const row = rows[0];
  if (!row) throw new Error("Failed to save thought");
  return row;
}

export async function listThoughts(
  userId: string,
  status?: string,
): Promise<ThoughtRow[]> {
  const sql = await getSql();
  if (status) {
    return sql<ThoughtRow>`
      select
        id, user_id, content, content_type, voice_path, status, next_step,
        invite_token, invited_username, forked_from,
        created_at::text as created_at,
        updated_at::text as updated_at
      from thoughts
      where user_id = ${userId} and status = ${status}
      order by created_at desc
    `;
  }
  return sql<ThoughtRow>`
    select
      id, user_id, content, content_type, voice_path, status, next_step,
      invite_token, invited_username, forked_from,
      created_at::text as created_at,
      updated_at::text as updated_at
    from thoughts
    where user_id = ${userId}
    order by created_at desc
  `;
}

export async function countThoughts(userId: string, status: string): Promise<number> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`
    select count(*)::int as n from thoughts
    where user_id = ${userId} and status = ${status}
  `;
  return rows[0]?.n ?? 0;
}

export async function findLatestThought(userId: string): Promise<ThoughtRow | null> {
  const sql = await getSql();
  const rows = await sql<ThoughtRow>`
    select
      id, user_id, content, content_type, voice_path, status, next_step,
      invite_token, invited_username, forked_from,
      created_at::text as created_at,
      updated_at::text as updated_at
    from thoughts
    where user_id = ${userId}
    order by created_at desc
    limit 1
  `;
  return rows[0] ?? null;
}

export async function findThoughtByContent(
  userId: string,
  content: string,
): Promise<ThoughtRow | null> {
  const sql = await getSql();
  const rows = await sql<ThoughtRow>`
    select
      id, user_id, content, content_type, voice_path, status, next_step,
      invite_token, invited_username, forked_from,
      created_at::text as created_at,
      updated_at::text as updated_at
    from thoughts
    where user_id = ${userId} and content = ${content}
    order by created_at desc
    limit 1
  `;
  return rows[0] ?? null;
}

export async function updateThoughtStatus(
  userId: string,
  thoughtId: number,
  status: "raw" | "gold" | "trash",
): Promise<ThoughtRow | null> {
  const sql = await getSql();
  const rows = await sql<ThoughtRow>`
    update thoughts
    set status = ${status}, updated_at = now()
    where id = ${thoughtId} and user_id = ${userId}
    returning
      id, user_id, content, content_type, voice_path, status, next_step,
      invite_token, invited_username, forked_from,
      created_at::text as created_at,
      updated_at::text as updated_at
  `;
  return rows[0] ?? null;
}

export async function deleteThought(
  userId: string,
  thoughtId: number,
): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ id: number }>`
    delete from thoughts
    where id = ${thoughtId} and user_id = ${userId}
    returning id
  `;
  return rows.length > 0;
}

export async function getThoughtById(
  userId: string,
  id: number,
): Promise<ThoughtRow | null> {
  const sql = await getSql();
  const r = await sql<ThoughtRow>`
    select
      id, user_id, content, content_type, voice_path, status, next_step,
      invite_token, invited_username, forked_from,
      created_at::text as created_at,
      updated_at::text as updated_at
    from thoughts
    where id = ${id} and user_id = ${userId}
    limit 1
  `;
  return r[0] ?? null;
}

export async function getThoughtByInvite(
  id: number,
  token: string,
): Promise<ThoughtRow | null> {
  const sql = await getSql();
  const r = await sql<ThoughtRow>`
    select
      id, user_id, content, content_type, voice_path, status, next_step,
      invite_token, invited_username, forked_from,
      created_at::text as created_at,
      updated_at::text as updated_at
    from thoughts
    where id = ${id} and invite_token = ${token}
    limit 1
  `;
  return r[0] ?? null;
}

export async function setInvite(
  userId: string,
  thoughtId: number,
  token: string,
  username: string,
): Promise<ThoughtRow | null> {
  const sql = await getSql();
  const r = await sql<ThoughtRow>`
    update thoughts set
      invite_token = ${token},
      invited_username = ${username},
      updated_at = now()
    where id = ${thoughtId} and user_id = ${userId}
    returning
      id, user_id, content, content_type, voice_path, status, next_step,
      invite_token, invited_username, forked_from,
      created_at::text as created_at,
      updated_at::text as updated_at
  `;
  return r[0] ?? null;
}
