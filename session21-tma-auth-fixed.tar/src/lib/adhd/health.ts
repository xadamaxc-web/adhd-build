import { createServerFn } from "@tanstack/react-start";
import type { HealthPayload } from "./types";

export const getHealth = createServerFn({ method: "GET" }).handler(
  async (): Promise<HealthPayload> => {
    const { buildHealth } = await import("./health.server");
    return buildHealth();
  },
);
