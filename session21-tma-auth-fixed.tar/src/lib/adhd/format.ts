const PROVIDER_LABELS: Record<string, string> = {
  claude: "Claude",
  grok: "Grok",
  kimi: "Kimi",
  gpt: "GPT",
  chatgpt: "GPT",
  openai: "GPT",
};

export function displayProvider(provider: string): string {
  const key = provider.trim().toLowerCase();
  if (PROVIDER_LABELS[key]) return PROVIDER_LABELS[key];
  if (!key) return "Account";
  return key.slice(0, 1).toUpperCase() + key.slice(1);
}

export function maskLabel(label: string): string {
  const at = label.indexOf("@");
  if (at <= 0) return label;
  const user = label.slice(0, at);
  const domain = label.slice(at);
  const keep = Math.min(3, user.length);
  return `${user.slice(0, keep)}***${domain}`;
}

function pad(n: number): string {
  return n.toString().padStart(2, "0");
}

export function formatCountdown(unlocksAt: Date | string, now = new Date()): string {
  const target = unlocksAt instanceof Date ? unlocksAt : new Date(unlocksAt);
  if (Number.isNaN(target.getTime())) return "unknown";
  const ms = target.getTime() - now.getTime();
  if (ms <= 0) return "unlocked now";
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

export function formatUnlockClock(unlocksAt: Date | string): string {
  const target = unlocksAt instanceof Date ? unlocksAt : new Date(unlocksAt);
  if (Number.isNaN(target.getTime())) return "";
  return target.toLocaleString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function formatThoughtTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function previewText(content: string, max = 140): string {
  const trimmed = content.replace(/\s+/g, " ").trim();
  if (trimmed.length <= max) return trimmed;
  return `${trimmed.slice(0, max - 1)}…`;
}
