import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type { IdeaPlanRow, IdeaPlayRow } from "./play";

export const generateQuestions = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(
    async ({
      context,
      data,
    }): Promise<
      | { ok: true; playId: number; questions: string[] }
      | { ok: false; error: string }
    > => {
      const body = data as { thoughtId: number; content: string };
      if (!body?.thoughtId || !body?.content?.trim()) {
        return { ok: false, error: "thoughtId and content required" };
      }

      const { callAI, parseJsonArray } = await import("@/lib/services/ai");
      const { insertPlay } = await import("./play");

      const system = `You help people with ADHD turn a raw idea into clear next steps.
Reply with ONLY a JSON array of 3 short clarifying questions (strings). No markdown, no intro.`;

      const result = await callAI(
        `Idea:\n${body.content.trim()}\n\nWrite 3 clarifying questions that would help turn this into a concrete plan.`,
        { system, maxTokens: 400, temperature: 0.6 },
      );

      if (!result.ok) return { ok: false, error: result.error };

      let questions = parseJsonArray(result.text)?.filter(
        (q): q is string => typeof q === "string" && q.trim().length > 0,
      );

      if (!questions || questions.length === 0) {
        // fallback: split lines that look like questions
        questions = result.text
          .split("\n")
          .map((l) => l.replace(/^\d+[.)]\s*/, "").trim())
          .filter((l) => l.endsWith("?") || l.length > 12)
          .slice(0, 3);
      }

      if (!questions || questions.length === 0) {
        return { ok: false, error: "Could not parse questions from AI" };
      }

      const play = await insertPlay({
        userId: context.userId,
        thoughtId: body.thoughtId,
        questions,
      });

      return { ok: true, playId: play.id, questions };
    },
  );

export const generateSessions = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(
    async ({
      context,
      data,
    }): Promise<
      | {
          ok: true;
          planId: number;
          generalPrompt: string;
          sessions: string[];
        }
      | { ok: false; error: string }
    > => {
      const body = data as {
        thoughtId: number;
        playId: number;
        content: string;
        questions: string[];
        answers: string[];
      };
      if (!body?.thoughtId || !body?.playId || !body?.content) {
        return { ok: false, error: "missing fields" };
      }

      const { callAI, parseJsonArray } = await import("@/lib/services/ai");
      const { completePlay, insertPlan } = await import("./play");

      const qa = (body.questions || [])
        .map((q, i) => `Q: ${q}\nA: ${(body.answers || [])[i] ?? "(no answer)"}`)
        .join("\n\n");

      const system = `You help people with ADHD break ideas into small, finishable sessions.
Reply with ONLY a JSON object: { "general": "one overall prompt", "sessions": ["session 1 prompt", "session 2 prompt", ...] }
Aim for 3–5 sessions. Each session should be doable in 25–45 minutes. No markdown fences.`;

      const result = await callAI(
        `Idea:\n${body.content.trim()}\n\nClarifying Q&A:\n${qa}\n\nProduce a general prompt and session-sized prompts.`,
        { system, maxTokens: 900, temperature: 0.65 },
      );

      if (!result.ok) return { ok: false, error: result.error };

      let general = "";
      let sessions: string[] = [];

      try {
        const cleaned = result.text
          .replace(/^```(?:json)?\s*/i, "")
          .replace(/\s*```$/i, "")
          .trim();
        const obj = JSON.parse(cleaned) as {
          general?: string;
          sessions?: unknown;
        };
        general = typeof obj.general === "string" ? obj.general : "";
        if (Array.isArray(obj.sessions)) {
          sessions = obj.sessions.filter((s): s is string => typeof s === "string");
        }
      } catch {
        const arr = parseJsonArray(result.text);
        if (arr && arr.every((x) => typeof x === "string")) {
          sessions = arr as string[];
          general = sessions[0] ?? body.content;
        }
      }

      if (sessions.length === 0) {
        return { ok: false, error: "Could not parse sessions from AI" };
      }
      if (!general) general = `Work through: ${body.content.slice(0, 120)}`;

      await completePlay({
        userId: context.userId,
        playId: body.playId,
        answers: body.answers || [],
        generatedPrompt: general,
      });

      const plan = await insertPlan({
        userId: context.userId,
        thoughtId: body.thoughtId,
        generalPrompt: general,
        sessions,
      });

      return {
        ok: true,
        planId: plan.id,
        generalPrompt: general,
        sessions,
      };
    },
  );

export const listMyPlans = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<IdeaPlanRow[]> => {
    const { listPlansForUser } = await import("./play");
    return listPlansForUser(context.userId);
  });

export type FreeSession = {
  index: number;
  provider: string;
  prompt: string;
};

export const freeSessions = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(
    async ({
      context,
      data,
    }): Promise<
      | {
          ok: true;
          planId: number;
          generalPrompt: string;
          sessions: FreeSession[];
        }
      | { ok: false; error: string }
    > => {
      const body = data as { thoughtId: number };
      if (!body?.thoughtId) return { ok: false, error: "thoughtId required" };

      const { listThoughts } = await import("./thoughts");
      const { getLatestPlayForThought, insertPlan } = await import("./play");
      const { callAI } = await import("@/lib/services/ai");

      const thoughts = await listThoughts(context.userId);
      const thought = thoughts.find((t) => t.id === body.thoughtId);
      if (!thought) return { ok: false, error: "Thought not found" };

      const play = await getLatestPlayForThought(context.userId, body.thoughtId);
      let answers: string[] = [];
      if (play?.answers_json) {
        try {
          answers = JSON.parse(play.answers_json) as string[];
        } catch {
          answers = [];
        }
      }
      const generated = play?.generated_prompt ?? "";

      const system = `You plan ADHD-friendly work sessions. Reply with ONLY valid JSON, no markdown.`;
      const userPrompt = `Idea: ${thought.content}
User answers: ${JSON.stringify(answers)}
Prior prompt: ${generated}

Divide into minimum number of sessions where each session fits inside one Claude free-tier window (~5 hours focused work). Each session self-contained, starts from previous output. Suggest provider per session: claude (reasoning), grok (real-time), kimi (long docs).
Return JSON: { "general_prompt": string, "sessions": [{ "index": number, "provider": string, "prompt": string }] }`;

      const result = await callAI(userPrompt, {
        system,
        maxTokens: 2000,
        temperature: 0.5,
      });
      if (!result.ok) return { ok: false, error: result.error };

      let parsed: {
        general_prompt?: string;
        sessions?: FreeSession[];
      } | null = null;
      try {
        const cleaned = result.text
          .replace(/^```(?:json)?\s*/i, "")
          .replace(/\s*```$/i, "")
          .trim();
        const start = cleaned.indexOf("{");
        const end = cleaned.lastIndexOf("}");
        parsed = JSON.parse(
          start >= 0 && end > start ? cleaned.slice(start, end + 1) : cleaned,
        ) as typeof parsed;
      } catch {
        return { ok: false, error: "Could not parse AI JSON" };
      }

      const generalPrompt = (parsed?.general_prompt ?? "").trim();
      const sessions = (parsed?.sessions ?? []).filter(
        (s) => s && typeof s.prompt === "string" && s.prompt.trim(),
      );
      if (!generalPrompt || sessions.length === 0) {
        return { ok: false, error: "AI returned empty plan" };
      }

      const normalized = sessions.map((s, i) => ({
        index: typeof s.index === "number" ? s.index : i + 1,
        provider: String(s.provider || "claude"),
        prompt: String(s.prompt).trim(),
      }));

      const plan = await insertPlan({
        userId: context.userId,
        thoughtId: body.thoughtId,
        generalPrompt,
        sessions: normalized.map((s) => `[${s.provider}] ${s.prompt}`),
      });

      const { getSql } = await import("@/lib/db");
      const sql = await getSql();
      await sql`
        update idea_plans
        set sessions_json = ${JSON.stringify(normalized)}
        where id = ${plan.id}
      `;

      return {
        ok: true,
        planId: plan.id,
        generalPrompt,
        sessions: normalized,
      };
    },
  );
