import { getSql } from "@/lib/db";
import type { AccountRow } from "./types";

export async function upsertAccount(input: {
  userId: string;
  provider: string;
  label: string;
  unlocksAt: Date;
  cooldownHours?: number;
}): Promise<AccountRow> {
  const sql = await getSql();
  const unlockIso = input.unlocksAt.toISOString();
  const cooldown = input.cooldownHours ?? 5;

  const existing = await sql<AccountRow>`
    select
      id, user_id, provider, label,
      unlocks_at::text as unlocks_at,
      cooldown_hours, notified,
      created_at::text as created_at,
      updated_at::text as updated_at
    from accounts
    where user_id = ${input.userId}
      and lower(provider) = ${input.provider.toLowerCase()}
      and lower(label) = ${input.label.toLowerCase()}
    limit 1
  `;

  if (existing[0]) {
    await sql`
      update accounts set
        unlocks_at = ${unlockIso}::timestamptz,
        cooldown_hours = ${cooldown},
        notified = 0,
        updated_at = now()
      where id = ${existing[0].id} and user_id = ${input.userId}
    `;
    const rows = await sql<AccountRow>`
      select
        id, user_id, provider, label,
        unlocks_at::text as unlocks_at,
        cooldown_hours, notified,
        created_at::text as created_at,
        updated_at::text as updated_at
      from accounts
      where id = ${existing[0].id} and user_id = ${input.userId}
      limit 1
    `;
    const row = rows[0];
    if (!row) throw new Error("Failed to update account");
    return row;
  }

  const rows = await sql<AccountRow>`
    insert into accounts (
      user_id, provider, label, unlocks_at, cooldown_hours, notified, updated_at
    )
    values (
      ${input.userId},
      ${input.provider.toLowerCase()},
      ${input.label},
      ${unlockIso}::timestamptz,
      ${cooldown},
      0,
      now()
    )
    returning
      id, user_id, provider, label,
      unlocks_at::text as unlocks_at,
      cooldown_hours, notified,
      created_at::text as created_at,
      updated_at::text as updated_at
  `;
  const row = rows[0];
  if (!row) throw new Error("Failed to save account");
  return row;
}

export async function listAccounts(userId: string): Promise<AccountRow[]> {
  const sql = await getSql();
  return sql<AccountRow>`
    select
      id, user_id, provider, label,
      unlocks_at::text as unlocks_at,
      cooldown_hours, notified,
      created_at::text as created_at,
      updated_at::text as updated_at
    from accounts
    where user_id = ${userId}
    order by unlocks_at asc
  `;
}

export async function markAccountUsed(
  userId: string,
  accountId: number,
): Promise<AccountRow | null> {
  const sql = await getSql();
  const rows = await sql<AccountRow>`
    select
      id, user_id, provider, label,
      unlocks_at::text as unlocks_at,
      cooldown_hours, notified,
      created_at::text as created_at,
      updated_at::text as updated_at
    from accounts
    where id = ${accountId} and user_id = ${userId}
    limit 1
  `;
  const current = rows[0];
  if (!current) return null;

  const hours = current.cooldown_hours || 5;
  const unlocksAt = new Date(Date.now() + hours * 60 * 60 * 1000);

  await sql`
    update accounts set
      unlocks_at = ${unlocksAt.toISOString()}::timestamptz,
      notified = 0,
      updated_at = now()
    where id = ${accountId} and user_id = ${userId}
  `;

  const updated = await sql<AccountRow>`
    select
      id, user_id, provider, label,
      unlocks_at::text as unlocks_at,
      cooldown_hours, notified,
      created_at::text as created_at,
      updated_at::text as updated_at
    from accounts
    where id = ${accountId} and user_id = ${userId}
    limit 1
  `;
  return updated[0] ?? null;
}

export async function deleteAccount(
  userId: string,
  accountId: number,
): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ id: number }>`
    delete from accounts
    where id = ${accountId} and user_id = ${userId}
    returning id
  `;
  return rows.length > 0;
}
