import { getSql } from "@/lib/db";
import { env } from "@/lib/env.server";
import type { TelegramFrom, UserRow } from "./types";

function telegramUserId(telegramId: string | number): string {
  return `tg:${telegramId}`;
}

export async function getUserByUserId(userId: string): Promise<UserRow | null> {
  const sql = await getSql();
  const rows = await sql<UserRow>`
    select
      id, user_id, telegram_id, username, first_name, last_name,
      language_code, is_premium, is_banned, quiet_hours_start, quiet_hours_end,
      last_active_at::text as last_active_at,
      created_at::text as created_at,
      updated_at::text as updated_at
    from users
    where user_id = ${userId}
    limit 1
  `;
  return rows[0] ?? null;
}

export async function upsertSessionUser(input: {
  userId: string;
  firstName?: string | null;
  lastName?: string | null;
  username?: string | null;
}): Promise<UserRow> {
  const sql = await getSql();
  const firstName = input.firstName?.trim() || null;
  const lastName = input.lastName?.trim() || null;
  const username = input.username?.trim() || null;
  await sql`
    insert into users (user_id, first_name, last_name, username, last_active_at, updated_at)
    values (${input.userId}, ${firstName}, ${lastName}, ${username}, now(), now())
    on conflict (user_id) do update set
      first_name = coalesce(excluded.first_name, users.first_name),
      last_name = coalesce(excluded.last_name, users.last_name),
      username = coalesce(excluded.username, users.username),
      last_active_at = now(),
      updated_at = now()
  `;
  const row = await getUserByUserId(input.userId);
  if (!row) throw new Error("Failed to upsert user");
  return row;
}

export async function upsertTelegramUser(from: TelegramFrom): Promise<UserRow> {
  const sql = await getSql();
  const telegramId = String(from.id);
  const userId = telegramUserId(telegramId);
  const username = from.username ?? null;
  const firstName = from.first_name ?? null;
  const lastName = from.last_name ?? null;
  const language = from.language_code ?? null;
  const isPremium = Boolean(from.is_premium);

  const existingByTelegram = await sql<UserRow>`
    select
      id, user_id, telegram_id, username, first_name, last_name,
      language_code, is_premium, is_banned, quiet_hours_start, quiet_hours_end,
      last_active_at::text as last_active_at,
      created_at::text as created_at,
      updated_at::text as updated_at
    from users
    where telegram_id = ${telegramId}
    limit 1
  `;

  if (existingByTelegram[0]) {
    await sql`
      update users set
        username = coalesce(${username}, username),
        first_name = coalesce(${firstName}, first_name),
        last_name = coalesce(${lastName}, last_name),
        language_code = coalesce(${language}, language_code),
        is_premium = ${isPremium},
        last_active_at = now(),
        updated_at = now()
      where telegram_id = ${telegramId}
    `;
    const row = await getUserByUserId(existingByTelegram[0].user_id);
    if (!row) throw new Error("Failed to update telegram user");
    await maybePromoteOwner(telegramId, row.user_id);
    return row;
  }

  await sql`
    insert into users (
      user_id, telegram_id, username, first_name, last_name,
      language_code, is_premium, last_active_at, updated_at
    )
    values (
      ${userId}, ${telegramId}, ${username}, ${firstName}, ${lastName},
      ${language}, ${isPremium}, now(), now()
    )
    on conflict (user_id) do update set
      telegram_id = excluded.telegram_id,
      username = coalesce(excluded.username, users.username),
      first_name = coalesce(excluded.first_name, users.first_name),
      last_name = coalesce(excluded.last_name, users.last_name),
      language_code = coalesce(excluded.language_code, users.language_code),
      is_premium = excluded.is_premium,
      last_active_at = now(),
      updated_at = now()
  `;

  const row = await getUserByUserId(userId);
  if (!row) throw new Error("Failed to upsert telegram user");
  await maybePromoteOwner(telegramId, row.user_id);
  return row;
}

export async function linkTelegramToUser(
  userId: string,
  from: TelegramFrom,
): Promise<UserRow> {
  const sql = await getSql();
  const telegramId = String(from.id);
  await sql`
    update users set
      telegram_id = ${telegramId},
      username = coalesce(${from.username ?? null}, username),
      first_name = coalesce(${from.first_name ?? null}, first_name),
      last_name = coalesce(${from.last_name ?? null}, last_name),
      language_code = coalesce(${from.language_code ?? null}, language_code),
      is_premium = ${Boolean(from.is_premium)},
      last_active_at = now(),
      updated_at = now()
    where user_id = ${userId}
  `;
  await maybePromoteOwner(telegramId, userId);
  const row = await getUserByUserId(userId);
  if (!row) throw new Error("Failed to link telegram user");
  return row;
}

async function maybePromoteOwner(telegramId: string, userId: string): Promise<void> {
  const owner = env("OWNER_TELEGRAM_ID");
  if (!owner || owner !== telegramId) return;
  const sql = await getSql();
  await sql`
    insert into admins (telegram_id, user_id, role)
    values (${telegramId}, ${userId}, 'owner')
    on conflict (telegram_id) do update set
      user_id = excluded.user_id,
      role = 'owner'
  `;
  await sql`
    insert into settings (key, value, updated_at)
    values ('owner_telegram_id', ${telegramId}, now())
    on conflict (key) do update set value = excluded.value, updated_at = now()
  `;
}

export async function updateQuietHours(
  userId: string,
  start: string | null,
  end: string | null,
): Promise<UserRow> {
  const sql = await getSql();
  await sql`
    update users set
      quiet_hours_start = ${start},
      quiet_hours_end = ${end},
      updated_at = now()
    where user_id = ${userId}
  `;
  const row = await getUserByUserId(userId);
  if (!row) throw new Error("Failed to update quiet hours");
  return row;
}

/** True when local time falls inside the user's quiet window (supports overnight). */
export function isInQuietHours(
  user: { quiet_hours_start: string | null; quiet_hours_end: string | null },
  now = new Date(),
): boolean {
  const start = user.quiet_hours_start?.trim();
  const end = user.quiet_hours_end?.trim();
  if (!start || !end) return false;

  const parse = (s: string): number | null => {
    const m = s.match(/^(\d{1,2}):(\d{2})$/);
    if (!m) return null;
    const h = Number(m[1]);
    const min = Number(m[2]);
    if (!Number.isFinite(h) || h > 23 || !Number.isFinite(min) || min > 59) return null;
    return h * 60 + min;
  };

  const sMin = parse(start);
  const eMin = parse(end);
  if (sMin == null || eMin == null) return false;

  const nowMin = now.getHours() * 60 + now.getMinutes();
  if (sMin === eMin) return true; // full day quiet
  if (sMin < eMin) return nowMin >= sMin && nowMin < eMin;
  // overnight window e.g. 22:00–07:00
  return nowMin >= sMin || nowMin < eMin;
}
