import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type { AccountRow } from "./types";

export const listMyAccounts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<AccountRow[]> => {
    const { listAccounts } = await import("./accounts");
    return listAccounts(context.userId);
  });

export const addAccount = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<AccountRow> => {
    const { upsertAccount } = await import("./accounts");
    const body = data as {
      provider: string;
      label: string;
      cooldownHours?: number;
    };
    const provider = (body?.provider ?? "").trim();
    const label = (body?.label ?? "").trim() || provider;
    if (!provider) throw new Error("Provider is required");
    const hours = body?.cooldownHours && body.cooldownHours > 0 ? body.cooldownHours : 5;
    // Start unlocked so the user can mark used immediately
    const unlocksAt = new Date();
    return upsertAccount({
      userId: context.userId,
      provider,
      label,
      unlocksAt,
      cooldownHours: hours,
    });
  });

export const useAccount = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<AccountRow | null> => {
    const { markAccountUsed } = await import("./accounts");
    const body = data as { id: number };
    if (!body?.id) throw new Error("id required");
    return markAccountUsed(context.userId, body.id);
  });

export const removeAccount = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<boolean> => {
    const { deleteAccount } = await import("./accounts");
    const body = data as { id: number };
    if (!body?.id) throw new Error("id required");
    return deleteAccount(context.userId, body.id);
  });
