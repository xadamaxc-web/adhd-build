import { getSql } from "@/lib/db";

export async function insertLog(
  type: string,
  message: string,
  meta?: Record<string, unknown>,
): Promise<void> {
  const sql = await getSql();
  const metaJson = meta ? JSON.stringify(meta) : null;
  await sql`
    insert into logs (type, message, meta_json)
    values (${type}, ${message}, ${metaJson})
  `;
}
