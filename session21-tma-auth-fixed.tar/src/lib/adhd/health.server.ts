import { dbSource, getSql } from "@/lib/db";
import { env } from "@/lib/env.server";
import { authConfigured } from "@/lib/auth/verify.server";
import type { HealthPayload } from "./types";

export async function buildHealth(): Promise<HealthPayload> {
  let dbOk = false;
  try {
    const sql = await getSql();
    await sql`select 1 as ok`;
    dbOk = true;
  } catch {
    dbOk = false;
  }

  return {
    ok: dbOk,
    service: "my-adhd",
    time: new Date().toISOString(),
    db: {
      ok: dbOk,
      source: dbSource,
    },
    auth: {
      enabled: authConfigured,
    },
    telegram: {
      botConfigured: Boolean(env("BOT_TOKEN")),
      webhook: "ready",
    },
    ai: (() => {
      const ready = Boolean(process.env.XAI_API_KEY);
      return { stub: !ready, ready };
    })(),
  };
}
