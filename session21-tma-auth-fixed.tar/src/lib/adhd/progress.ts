import { getSql } from "@/lib/db";

export type ProgressLogRow = {
  id: number;
  thought_id: number;
  user_id: string;
  content: string;
  context: string | null;
  created_at: string;
};

export async function insertProgress(input: {
  userId: string;
  thoughtId: number;
  content: string;
  context?: string | null;
}): Promise<ProgressLogRow> {
  const sql = await getSql();
  const rows = await sql<ProgressLogRow>`
    insert into progress_logs (thought_id, user_id, content, context)
    values (
      ${input.thoughtId},
      ${input.userId},
      ${input.content},
      ${input.context ?? null}
    )
    returning
      id, thought_id, user_id, content, context,
      created_at::text as created_at
  `;
  const row = rows[0];
  if (!row) throw new Error("Failed to save progress");
  return row;
}

export async function listProgress(
  userId: string,
  thoughtId?: number,
): Promise<ProgressLogRow[]> {
  const sql = await getSql();
  if (thoughtId != null) {
    return sql<ProgressLogRow>`
      select
        id, thought_id, user_id, content, context,
        created_at::text as created_at
      from progress_logs
      where user_id = ${userId} and thought_id = ${thoughtId}
      order by created_at desc
      limit 50
    `;
  }
  return sql<ProgressLogRow>`
    select
      id, thought_id, user_id, content, context,
      created_at::text as created_at
    from progress_logs
    where user_id = ${userId}
    order by created_at desc
    limit 50
  `;
}

export async function setThoughtNextStep(
  userId: string,
  thoughtId: number,
  nextStep: string | null,
): Promise<void> {
  const sql = await getSql();
  await sql`
    update thoughts
    set next_step = ${nextStep}, updated_at = now()
    where id = ${thoughtId} and user_id = ${userId}
  `;
}
