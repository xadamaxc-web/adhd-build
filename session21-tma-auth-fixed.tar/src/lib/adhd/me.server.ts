import { getRequest } from "@tanstack/react-start/server";
import { getSql } from "@/lib/db";
import { getSessionUser, UnauthorizedError } from "@/lib/auth/verify.server";
import {
  linkTelegramToUser,
  upsertSessionUser,
  upsertTelegramUser,
} from "@/lib/adhd/users";
import type { UserRow } from "@/lib/adhd/types";
import {
  readTelegramInitData,
  TelegramAuthError,
  verifyTelegramInitData,
} from "@/lib/telegram/auth";

function splitName(name: string | null | undefined): {
  firstName: string | null;
  lastName: string | null;
} {
  const trimmed = name?.trim() ?? "";
  if (!trimmed) return { firstName: null, lastName: null };
  const [first, ...rest] = trimmed.split(/\s+/);
  return { firstName: first ?? null, lastName: rest.length ? rest.join(" ") : null };
}

export async function resolveMe(bearerToken?: string): Promise<UserRow> {
  const request = getRequest();
  const initData = request ? readTelegramInitData(request) : null;
  const session = await getSessionUser(bearerToken);

  if (initData) {
    try {
      const verified = verifyTelegramInitData(initData);
      if (session) {
        await upsertSessionUser({
          userId: session.id,
          firstName: verified.user.first_name,
          lastName: verified.user.last_name ?? null,
          username: verified.user.username ?? null,
        });
        return linkTelegramToUser(session.id, verified.user);
      }
      return upsertTelegramUser(verified.user);
    } catch (err) {
      if (err instanceof TelegramAuthError) throw new UnauthorizedError();
      throw err;
    }
  }

  if (!session) throw new UnauthorizedError();

  const sql = await getSql();
  const authRows = await sql<{ name: string; email: string }>`
    select name, email from "user" where id = ${session.id} limit 1
  `;
  const names = splitName(authRows[0]?.name);
  const username = authRows[0]?.email?.split("@")[0] ?? null;

  return upsertSessionUser({
    userId: session.id,
    firstName: names.firstName,
    lastName: names.lastName,
    username,
  });
}
