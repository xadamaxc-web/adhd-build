import { Markup } from "telegraf";
import { getSql } from "@/lib/db";
import { insertLog } from "@/lib/adhd/logs";
import { isInQuietHours } from "@/lib/adhd/users";
import { getBot } from "@/lib/telegram/bot";
import { getTmaUrl, tmaHref } from "@/lib/telegram/tma";

const TICK_MS = 60_000;
type G = typeof globalThis & {
  __adhdCronStarted__?: boolean;
  __adhdCronTimer__?: ReturnType<typeof setInterval>;
};

type QuietUser = {
  user_id: string;
  telegram_id: string | null;
  quiet_hours_start: string | null;
  quiet_hours_end: string | null;
};

async function loadUser(userId: string): Promise<QuietUser | null> {
  const sql = await getSql();
  const rows = await sql<QuietUser>`
    select user_id, telegram_id, quiet_hours_start, quiet_hours_end
    from users where user_id = ${userId} limit 1
  `;
  return rows[0] ?? null;
}

async function canMessage(userId: string): Promise<string | null> {
  const user = await loadUser(userId);
  if (!user?.telegram_id) return null;
  if (isInQuietHours(user)) return null;
  return user.telegram_id;
}

async function send(telegramId: string, text: string, extra?: object): Promise<boolean> {
  const bot = getBot();
  if (!bot) return false;
  try {
    await bot.telegram.sendMessage(telegramId, text, extra);
    return true;
  } catch {
    return false;
  }
}

function preview(content: string, max = 80): string {
  const t = content.replace(/\s+/g, " ").trim();
  return t.length <= max ? t : `${t.slice(0, max - 1)}…`;
}

async function jobUnlockPing(): Promise<void> {
  const sql = await getSql();
  const rows = await sql<{ id: number; user_id: string; provider: string; label: string }>`
    select id, user_id, provider, label from accounts
    where unlocks_at <= now() and notified = 0 limit 50
  `;
  let count = 0;
  for (const row of rows) {
    const tg = await canMessage(row.user_id);
    if (!tg) continue;
    if (!(await send(tg, `🔓 ${row.provider} ${row.label} should be unlocked now.`))) continue;
    await sql`update accounts set notified = 1, updated_at = now() where id = ${row.id}`;
    count += 1;
  }
  if (count > 0) await insertLog("trigger_fire", "unlock_ping", { count });
  await sql`update triggers set last_run_at = now(), last_error = null where key = 'unlock_ping'`;
}

async function jobCustomReminder(): Promise<void> {
  const sql = await getSql();
  const rows = await sql<{ id: number; user_id: string; thought_id: number }>`
    select id, user_id, thought_id from reminders
    where fire_at <= now() and fired = false limit 50
  `;
  let count = 0;
  for (const row of rows) {
    const tg = await canMessage(row.user_id);
    if (!tg) continue;
    const thoughts = await sql<{ content: string }>`
      select content from thoughts where id = ${row.thought_id} and user_id = ${row.user_id} limit 1
    `;
    const content = thoughts[0]?.content ?? "(idea)";
    if (!(await send(tg, `⏰ Reminder: ${preview(content)}`))) continue;
    await sql`update reminders set fired = true where id = ${row.id}`;
    count += 1;
  }
  if (count > 0) await insertLog("trigger_fire", "custom_reminder", { count });
}

async function jobWeeklyReview(now: Date): Promise<void> {
  if (now.getDay() !== 0) return;
  const sql = await getSql();
  const trig = await sql<{ last_run_at: string | null }>`
    select last_run_at::text as last_run_at from triggers where key = 'weekly_review' limit 1
  `;
  const last = trig[0]?.last_run_at ? new Date(trig[0].last_run_at) : null;
  if (last && now.getTime() - last.getTime() < 6 * 24 * 60 * 60 * 1000) return;

  const users = await sql<{ user_id: string; telegram_id: string }>`
    select distinct u.user_id, u.telegram_id
    from users u
    inner join thoughts t on t.user_id = u.user_id and t.status = 'gold'
    where u.telegram_id is not null and u.is_banned = false
  `;
  const base = await getTmaUrl();
  const reviewUrl = tmaHref(base, "review");
  let count = 0;
  for (const u of users) {
    const user = await loadUser(u.user_id);
    if (user && isInQuietHours(user)) continue;
    const extra = Markup.inlineKeyboard([Markup.button.webApp("Start Review", reviewUrl)]);
    if (await send(u.telegram_id, "Your gold pile this week — ready to review?", extra)) {
      count += 1;
    }
  }
  await sql`update triggers set last_run_at = now(), last_error = null where key = 'weekly_review'`;
  await insertLog("trigger_fire", "weekly_review", { count });
}

async function jobIdleNudge(): Promise<void> {
  const sql = await getSql();
  const candidates = await sql<{ user_id: string; telegram_id: string }>`
    select u.user_id, u.telegram_id from users u
    where u.telegram_id is not null and u.is_banned = false
      and not exists (
        select 1 from thoughts t
        where t.user_id = u.user_id and t.created_at > now() - interval '7 days'
      )
  `;
  let count = 0;
  for (const u of candidates) {
    const tg = await canMessage(u.user_id);
    if (!tg) continue;
    const recent = await sql<{ n: number }>`
      select count(*)::int as n from logs
      where type = 'trigger_fire' and message = 'idle_nudge'
        and meta_json like ${'%"user_id":"' + u.user_id + '"%'}
        and created_at > now() - interval '7 days'
    `;
    if ((recent[0]?.n ?? 0) > 0) continue;
    if (!(await send(tg, "Haven't heard from you. Any ideas floating around?"))) continue;
    await insertLog("trigger_fire", "idle_nudge", { user_id: u.user_id, count: 1 });
    count += 1;
  }
  await sql`update triggers set last_run_at = now(), last_error = null where key = 'idle_nudge'`;
  if (count > 0) await insertLog("trigger_fire", "idle_nudge", { count });
}

async function jobProgressCheck(): Promise<void> {
  const sql = await getSql();
  const rows = await sql<{ id: number; user_id: string; content: string }>`
    select t.id, t.user_id, t.content from thoughts t
    where t.status = 'gold'
      and t.next_step is not null and t.next_step <> ''
      and not exists (
        select 1 from progress_logs p
        where p.thought_id = t.id and p.created_at > now() - interval '14 days'
      )
    limit 40
  `;
  let count = 0;
  for (const row of rows) {
    const tg = await canMessage(row.user_id);
    if (!tg) continue;
    const recent = await sql<{ n: number }>`
      select count(*)::int as n from logs
      where type = 'trigger_fire' and message = 'progress_check'
        and meta_json like ${'%"thought_id":' + String(row.id) + '%'}
        and created_at > now() - interval '14 days'
    `;
    if ((recent[0]?.n ?? 0) > 0) continue;
    if (
      !(await send(
        tg,
        `You marked '${preview(row.content, 60)}' as gold. Still into it?`,
      ))
    ) {
      continue;
    }
    await insertLog("trigger_fire", "progress_check", {
      user_id: row.user_id,
      thought_id: row.id,
      count: 1,
    });
    count += 1;
  }
  await sql`update triggers set last_run_at = now(), last_error = null where key = 'progress_check'`;
  if (count > 0) await insertLog("trigger_fire", "progress_check", { count });
}


async function jobSystemAlert(): Promise<void> {
  const sql = await getSql();
  const owner = await sql<{ value: string }>`
    select value from settings where key = 'owner_telegram_id' limit 1
  `;
  const ownerTg = owner[0]?.value || process.env.OWNER_TELEGRAM_ID;
  if (!ownerTg) return;

  // recent AI failures not yet alerted
  const fails = await sql<{ id: number; message: string; meta_json: string | null }>`
    select id, message, meta_json from logs
    where type = 'ai'
      and (message like '%fail%' or message like '%all providers failed%' or message like '%exception%')
      and created_at > now() - interval '2 minutes'
    order by created_at desc
    limit 5
  `;
  const webhookFails = await sql<{ id: number; message: string }>`
    select id, message from logs
    where type in ('webhook_error', 'bot_error')
      and created_at > now() - interval '2 minutes'
    limit 5
  `;

  const bot = getBot();
  if (!bot) return;

  for (const f of [...fails, ...webhookFails]) {
    const already = await sql<{ n: number }>`
      select count(*)::int as n from logs
      where type = 'trigger_fire' and message = 'system_alert'
        and meta_json like ${'%"log_id":' + String(f.id) + '%'}
    `;
    if ((already[0]?.n ?? 0) > 0) continue;
    try {
      await bot.telegram.sendMessage(
        ownerTg,
        `⚠ system_alert: ${f.message}`.slice(0, 500),
      );
      await insertLog("trigger_fire", "system_alert", { log_id: f.id, count: 1 });
    } catch {
      /* ignore */
    }
  }

  await sql`update triggers set last_run_at = now(), last_error = null where key = 'system_alert'`;
}

async function tick(): Promise<void> {
  const now = new Date();
  const jobs: { key: string; fn: () => Promise<void> }[] = [
    { key: "unlock_ping", fn: jobUnlockPing },
    { key: "custom_reminder", fn: jobCustomReminder },
    { key: "weekly_review", fn: () => jobWeeklyReview(now) },
    { key: "idle_nudge", fn: jobIdleNudge },
    { key: "progress_check", fn: jobProgressCheck },
    { key: "system_alert", fn: jobSystemAlert },
  ];
  for (const job of jobs) {
    try {
      await job.fn();
    } catch (err) {
      const msg = err instanceof Error ? err.message : "job error";
      try {
        await insertLog("trigger_fire", job.key, { error: msg });
        const sql = await getSql();
        await sql`update triggers set last_error = ${msg} where key = ${job.key}`;
      } catch {
        /* ignore */
      }
    }
  }
}

export function startCronWorker(): void {
  if (typeof window !== "undefined") return;
  const g = globalThis as G;
  if (g.__adhdCronStarted__) return;
  g.__adhdCronStarted__ = true;
  setTimeout(() => void tick(), 5_000);
  g.__adhdCronTimer__ = setInterval(() => void tick(), TICK_MS);
}
