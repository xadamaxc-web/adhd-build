export function AppMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={className}
      aria-hidden="true"
      fill="none"
    >
      <rect x="5" y="8" width="18" height="16" rx="3" className="stroke-border" strokeWidth="1.4" />
      <rect x="9" y="6" width="18" height="16" rx="3" className="fill-card-elevated stroke-foreground/70" strokeWidth="1.4" />
      <path
        d="M13 12.5h10M13 16h7"
        className="stroke-muted-foreground"
        strokeWidth="1.4"
        strokeLinecap="round"
      />
    </svg>
  );
}
