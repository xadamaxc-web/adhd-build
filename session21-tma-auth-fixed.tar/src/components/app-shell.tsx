import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { AppMark } from "@/components/app-mark";
import { Skeleton } from "@/components/ui/skeleton";

function AuthSlot() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return <Skeleton className="h-8 w-28 rounded-full" />;
  }
  if (!user) {
    return (
      <Link
        to="/login"
        className="inline-flex h-11 items-center rounded-md px-3 text-sm text-muted-foreground transition-colors duration-150 hover:text-foreground"
      >
        Sign in
      </Link>
    );
  }
  return <UserButton />;
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-dvh">
      <div aria-hidden className="hero-wash pointer-events-none absolute inset-x-0 top-0 h-64" />
      <header className="relative z-10 border-b border-border">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link to="/" className="flex items-center gap-2.5">
            <AppMark className="size-8" />
            <span className="font-display text-lg font-medium tracking-tight">
              My ADHD
            </span>
          </Link>
          <AuthSlot />
        </div>
      </header>
      <div className="relative z-10">{children}</div>
    </div>
  );
}
