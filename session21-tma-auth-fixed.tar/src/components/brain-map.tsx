import { useMemo, useState } from "react";
import { Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { ThoughtRow } from "@/lib/adhd/types";
import { previewText } from "@/lib/adhd/format";

type Props = {
  thoughts: ThoughtRow[];
  onSelect?: (t: ThoughtRow) => void;
};

type Node = {
  thought: ThoughtRow;
  x: number; // 0–100 %
  y: number;
  r: number; // radius weight
  layer: "core" | "mid" | "outer";
};

function hashAngle(id: number): number {
  // stable pseudo-random angle from id
  const s = Math.sin(id * 12.9898) * 43758.5453;
  return (s - Math.floor(s)) * Math.PI * 2;
}

function layout(thoughts: ThoughtRow[]): Node[] {
  const gold = thoughts.filter((t) => t.status === "gold");
  const raw = thoughts.filter((t) => t.status === "raw");
  // ignore trash on the map
  const nodes: Node[] = [];

  gold.forEach((t, i) => {
    const angle = hashAngle(t.id) + i * 0.4;
    const dist = 12 + (i % 3) * 6; // close to center
    nodes.push({
      thought: t,
      x: 50 + Math.cos(angle) * dist,
      y: 50 + Math.sin(angle) * dist,
      r: 1.15,
      layer: "core",
    });
  });

  raw.forEach((t, i) => {
    const angle = hashAngle(t.id + 97) + i * 0.55;
    const dist = 32 + (i % 5) * 8; // farther out
    nodes.push({
      thought: t,
      x: 50 + Math.cos(angle) * dist,
      y: 50 + Math.sin(angle) * dist,
      r: 0.9,
      layer: dist > 42 ? "outer" : "mid",
    });
  });

  return nodes;
}

export function BrainMap({ thoughts, onSelect }: Props) {
  const [activeId, setActiveId] = useState<number | null>(null);
  const nodes = useMemo(() => layout(thoughts), [thoughts]);
  const active = nodes.find((n) => n.thought.id === activeId)?.thought;

  if (thoughts.length === 0) {
    return (
      <div className="flex h-80 flex-col items-center justify-center rounded-xl border border-dashed border-border text-center text-sm text-muted-foreground">
        <p>No ideas on the map yet.</p>
        <p className="mt-1">Capture thoughts and mark some gold — they pull to the center.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div
        className="relative mx-auto aspect-square w-full max-w-lg overflow-hidden rounded-xl border border-border bg-card"
        style={{
          backgroundImage:
            "radial-gradient(circle at 50% 50%, color-mix(in oklab, var(--color-foreground) 6%, transparent) 0%, transparent 55%)",
        }}
      >
        {/* orbit rings */}
        <div
          aria-hidden
          className="pointer-events-none absolute left-1/2 top-1/2 size-[28%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-border/60"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute left-1/2 top-1/2 size-[55%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-border/40"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute left-1/2 top-1/2 size-[82%] -translate-x-1/2 -translate-y-1/2 rounded-full border border-border/25"
        />
        {/* core glow */}
        <div
          aria-hidden
          className="pointer-events-none absolute left-1/2 top-1/2 size-16 -translate-x-1/2 -translate-y-1/2 rounded-full bg-ok/10"
        />

        {nodes.map((n) => {
          const isGold = n.thought.status === "gold";
          const isActive = n.thought.id === activeId;
          return (
            <button
              key={n.thought.id}
              type="button"
              onClick={() => {
                setActiveId(n.thought.id);
                onSelect?.(n.thought);
              }}
              className="absolute -translate-x-1/2 -translate-y-1/2 rounded-full border text-left transition-transform duration-150 ease-smooth-out hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70"
              style={{
                left: `${n.x}%`,
                top: `${n.y}%`,
                width: `${isGold ? 4.2 : 3.4}rem`,
                height: `${isGold ? 4.2 : 3.4}rem`,
                transform: `translate(-50%, -50%) scale(${isActive ? 1.15 : n.r})`,
                zIndex: isActive ? 20 : isGold ? 10 : 5,
                background: isGold
                  ? "color-mix(in oklab, var(--color-ok) 22%, var(--color-card))"
                  : "var(--color-card-elevated)",
                borderColor: isGold
                  ? "color-mix(in oklab, var(--color-ok) 50%, var(--color-border))"
                  : "var(--color-border)",
                boxShadow: isActive
                  ? "0 0 0 2px color-mix(in oklab, var(--color-primary) 40%, transparent)"
                  : undefined,
              }}
              title={previewText(n.thought.content, 80)}
            >
              <span className="flex h-full items-center justify-center p-1.5">
                {isGold ? (
                  <Star className="size-3.5 text-ok" strokeWidth={1.75} />
                ) : (
                  <span className="line-clamp-3 text-center text-[9px] leading-tight text-muted-foreground">
                    {previewText(n.thought.content, 36)}
                  </span>
                )}
              </span>
            </button>
          );
        })}
      </div>

      {/* detail panel */}
      {active ? (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="mb-2 flex flex-wrap items-center gap-2">
            <Badge variant={active.status === "gold" ? "ok" : "wait"}>
              {active.status}
            </Badge>
            <span className="font-mono text-xs text-muted-foreground">
              {new Date(active.created_at).toLocaleString()}
            </span>
          </div>
          <p className="whitespace-pre-wrap text-sm leading-relaxed">{active.content}</p>
          <div className="mt-3">
            <Button type="button" size="sm" variant="secondary" onClick={() => setActiveId(null)}>
              Close
            </Button>
          </div>
        </div>
      ) : (
        <p className="text-center text-xs text-muted-foreground">
          Gold ideas sit near the center · tap a node to read it
        </p>
      )}
    </div>
  );
}
