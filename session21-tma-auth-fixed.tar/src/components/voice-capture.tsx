import { useEffect, useRef, useState } from "react";
import { Mic, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { captureVoiceThought } from "@/lib/adhd/thoughts-client";

type Props = {
  onCaptured: () => void;
  disabled?: boolean;
};

type Phase = "idle" | "recording" | "uploading";

export function VoiceCapture({ onCaptured, disabled }: Props) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [error, setError] = useState<string | null>(null);
  const [seconds, setSeconds] = useState(0);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const startedAt = useRef(0);
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      mediaRef.current?.stream.getTracks().forEach((t) => t.stop());
    };
  }, []);

  async function start() {
    setError(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setError("Microphone not supported in this browser.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mime =
        MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
          ? "audio/webm;codecs=opus"
          : MediaRecorder.isTypeSupported("audio/webm")
            ? "audio/webm"
            : "";
      const recorder = mime
        ? new MediaRecorder(stream, { mimeType: mime })
        : new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        void upload(recorder.mimeType || "audio/webm");
      };
      mediaRef.current = recorder;
      startedAt.current = Date.now();
      setSeconds(0);
      timerRef.current = window.setInterval(() => {
        setSeconds(Math.floor((Date.now() - startedAt.current) / 1000));
      }, 250);
      recorder.start(250);
      setPhase("recording");
    } catch {
      setError("Microphone permission denied.");
    }
  }

  function stop() {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    const rec = mediaRef.current;
    if (rec && rec.state !== "inactive") {
      rec.stop();
    }
    setPhase("uploading");
  }

  async function upload(mimeType: string) {
    try {
      const blob = new Blob(chunksRef.current, { type: mimeType });
      if (blob.size < 200) {
        setError("Recording too short.");
        setPhase("idle");
        return;
      }
      const buffer = await blob.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = "";
      for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(bytes[i]!);
      }
      const audioBase64 = btoa(binary);
      const durationSec = Math.max(1, Math.round((Date.now() - startedAt.current) / 1000));

      const res = await captureVoiceThought({
        data: { audioBase64, mimeType, durationSec },
      });
      if (!res.ok) {
        setError(res.error);
        setPhase("idle");
        return;
      }
      setPhase("idle");
      setSeconds(0);
      onCaptured();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
      setPhase("idle");
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      {phase === "idle" && (
        <Button
          type="button"
          size="sm"
          variant="secondary"
          disabled={disabled}
          onClick={() => void start()}
        >
          <Mic className="size-3.5" />
          Voice
        </Button>
      )}
      {phase === "recording" && (
        <Button type="button" size="sm" variant="default" onClick={stop}>
          <Square className="size-3.5" />
          Stop · {seconds}s
        </Button>
      )}
      {phase === "uploading" && (
        <Button type="button" size="sm" variant="secondary" disabled>
          Transcribing…
        </Button>
      )}
      {error && <span className="text-xs text-danger">{error}</span>}
    </div>
  );
}
