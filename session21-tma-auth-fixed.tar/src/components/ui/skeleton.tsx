import { cn } from "@/lib/utils";

function Skeleton({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      className={cn("animate-pulse rounded-md bg-card-elevated", className)}
      {...props}
    />
  );
}

export { Skeleton };
