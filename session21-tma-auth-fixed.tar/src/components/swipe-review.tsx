import { useCallback, useEffect, useRef, useState } from "react";
import { Star, Trash2, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ThoughtRow } from "@/lib/adhd/types";
import { setThoughtStatus } from "@/lib/adhd/thoughts-client";

type Props = {
  thoughts: ThoughtRow[];
  onDone: () => void;
  onChanged: () => void;
};

const SWIPE_THRESHOLD = 100;
const ROTATE_FACTOR = 0.08;

export function SwipeReview({ thoughts, onDone, onChanged }: Props) {
  const [stack, setStack] = useState<ThoughtRow[]>(thoughts);
  const [dragX, setDragX] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [exiting, setExiting] = useState<"left" | "right" | null>(null);
  const startX = useRef(0);
  const currentX = useRef(0);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setStack(thoughts);
  }, [thoughts]);

  const top = stack[0];

  const commit = useCallback(
    async (direction: "left" | "right") => {
      if (!top || exiting) return;
      setExiting(direction);
      const status = direction === "right" ? "gold" : "trash";
      try {
        await setThoughtStatus({ data: { id: top.id, status } });
        onChanged();
      } catch {
        // still advance the stack so the user isn't stuck
      }
      // wait for exit animation
      window.setTimeout(() => {
        setStack((prev) => prev.slice(1));
        setDragX(0);
        setExiting(null);
      }, 220);
    },
    [top, exiting, onChanged],
  );

  const onPointerDown = (e: React.PointerEvent) => {
    if (exiting || !top) return;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    startX.current = e.clientX;
    currentX.current = e.clientX;
    setDragging(true);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragging || exiting) return;
    currentX.current = e.clientX;
    setDragX(currentX.current - startX.current);
  };

  const onPointerUp = () => {
    if (!dragging || exiting) return;
    setDragging(false);
    const dx = currentX.current - startX.current;
    if (dx > SWIPE_THRESHOLD) commit("right");
    else if (dx < -SWIPE_THRESHOLD) commit("left");
    else setDragX(0);
  };

  // keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!top || exiting) return;
      if (e.key === "ArrowRight" || e.key === "g") {
        e.preventDefault();
        commit("right");
      } else if (e.key === "ArrowLeft" || e.key === "t") {
        e.preventDefault();
        commit("left");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [top, exiting, commit]);

  if (stack.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 py-16 text-center">
        <p className="font-display text-2xl font-medium tracking-tight">
          Stack clear
        </p>
        <p className="max-w-sm text-sm text-muted-foreground">
          Nothing left to sort. Capture more ideas, or check your gold pile.
        </p>
        <Button type="button" onClick={onDone}>
          Back to inbox
        </Button>
      </div>
    );
  }

  const rotate = dragX * ROTATE_FACTOR;
  const opacityGold = Math.min(1, Math.max(0, dragX / SWIPE_THRESHOLD));
  const opacityTrash = Math.min(1, Math.max(0, -dragX / SWIPE_THRESHOLD));

  const exitTransform =
    exiting === "right"
      ? "translateX(120%) rotate(18deg)"
      : exiting === "left"
        ? "translateX(-120%) rotate(-18deg)"
        : undefined;

  return (
    <div className="mx-auto flex w-full max-w-md flex-col gap-6">
      <div className="relative h-[320px] w-full touch-none select-none sm:h-[360px]">
        {/* next card peek */}
        {stack[1] && (
          <div
            aria-hidden
            className="absolute inset-0 scale-[0.96] rounded-xl border border-border bg-card opacity-60"
          />
        )}

        <div
          ref={cardRef}
          role="group"
          aria-label="Swipe card"
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
          className="absolute inset-0 cursor-grab rounded-xl border border-border bg-card shadow-lg active:cursor-grabbing"
          style={{
            transform: exitTransform
              ? exitTransform
              : `translateX(${dragX}px) rotate(${rotate}deg)`,
            transition: dragging || exiting ? undefined : "transform 180ms var(--ease-smooth-out)",
            opacity: exiting ? 0 : 1,
          }}
        >
          {/* gold overlay */}
          <div
            className="pointer-events-none absolute inset-0 flex items-start justify-end rounded-xl bg-ok/20 p-5"
            style={{ opacity: opacityGold }}
          >
            <span className="inline-flex items-center gap-1.5 rounded-md border border-ok/40 bg-ok/20 px-3 py-1.5 text-sm font-medium text-ok">
              <Star className="size-4" /> Gold
            </span>
          </div>
          {/* trash overlay */}
          <div
            className="pointer-events-none absolute inset-0 flex items-start justify-start rounded-xl bg-danger/20 p-5"
            style={{ opacity: opacityTrash }}
          >
            <span className="inline-flex items-center gap-1.5 rounded-md border border-danger/40 bg-danger/20 px-3 py-1.5 text-sm font-medium text-danger">
              <Trash2 className="size-4" /> Trash
            </span>
          </div>

          <div className="flex h-full flex-col p-6">
            <p className="flex-1 overflow-y-auto whitespace-pre-wrap text-base leading-relaxed">
              {top.content}
            </p>
            <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground">
              <span className="font-mono">
                {new Date(top.created_at).toLocaleDateString()}
              </span>
              <span className="uppercase tracking-wider">{top.status}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-3">
        <Button
          type="button"
          variant="secondary"
          size="lg"
          className="min-w-[7rem]"
          onClick={() => commit("left")}
          disabled={!!exiting}
        >
          <Trash2 className="size-4" />
          Trash
        </Button>
        <Button
          type="button"
          variant="secondary"
          size="icon"
          title="Skip for now"
          onClick={() => {
            setStack((prev) => [...prev.slice(1), prev[0]!]);
            setDragX(0);
          }}
          disabled={!!exiting || stack.length < 2}
        >
          <Undo2 className="size-4" />
        </Button>
        <Button
          type="button"
          size="lg"
          className="min-w-[7rem]"
          onClick={() => commit("right")}
          disabled={!!exiting}
        >
          <Star className="size-4" />
          Gold
        </Button>
      </div>

      <p className="text-center text-xs text-muted-foreground">
        Swipe or use ← / → · {stack.length} left
      </p>
    </div>
  );
}
