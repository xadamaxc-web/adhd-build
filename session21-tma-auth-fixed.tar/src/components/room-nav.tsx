import { Link, useRouterState } from "@tanstack/react-router";
import {
  Brain,
  Clock,
  Inbox,
  KeyRound,
  Settings,
  Shield,
  Sparkles,
  Star,
} from "lucide-react";
import { cn } from "@/lib/utils";

const ROOMS = [
  { to: "/", label: "Inbox", icon: Inbox },
  { to: "/review", label: "Swipe", icon: Star },
  { to: "/workspace", label: "Map", icon: Brain },
  { to: "/accounts", label: "Timers", icon: KeyRound },
  { to: "/play", label: "Play", icon: Sparkles },
  { to: "/progress", label: "Progress", icon: Clock },
  { to: "/settings", label: "Settings", icon: Settings },
  { to: "/admin", label: "Admin", icon: Shield },
] as const;

export function RoomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <nav
      aria-label="Rooms"
      className="flex flex-wrap gap-1.5 border-b border-border pb-3"
    >
      {ROOMS.map((r) => {
        const active =
          r.to === "/"
            ? pathname === "/"
            : pathname === r.to || pathname.startsWith(`${r.to}/`);
        const Icon = r.icon;
        return (
          <Link
            key={r.to}
            to={r.to}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-medium transition-colors",
              active
                ? "bg-card-elevated text-foreground"
                : "text-muted-foreground hover:bg-card hover:text-foreground",
            )}
          >
            <Icon className="size-3.5" strokeWidth={1.75} />
            {r.label}
          </Link>
        );
      })}
    </nav>
  );
}
